using System.Text.RegularExpressions;
using Microsoft.Extensions.FileProviders;

namespace Xignux.Juridico.Inmuebles.Web.Services;

public sealed class IconCatalogService
{
    private readonly IFileProvider _webRoot;
    private readonly ILogger<IconCatalogService> _logger;
    private IReadOnlyList<string>? _cache;
    private DateTimeOffset _lastRead = DateTimeOffset.MinValue;

    // Ajusta la ruta si tu archivo se llama distinto
    private const string IconsCssPath = "xignuxfont/xignuxfont.css";

    public IconCatalogService(IWebHostEnvironment env, ILogger<IconCatalogService> logger)
    {
        _webRoot = env.WebRootFileProvider;
        _logger  = logger;
    }

    public async Task<IReadOnlyList<string>> GetAllAsync(bool forceReload = false, CancellationToken ct = default)
    {
        // Cache simple (se rehace si el archivo cambia o si se pide forceReload)
        var file = _webRoot.GetFileInfo(IconsCssPath);
        if (!file.Exists)
        {
            _logger.LogWarning("No se encontró {Path} en wwwroot.", IconsCssPath);
            return Array.Empty<string>();
        }

        // Si hay cache y el archivo no ha cambiado, úsala
        if (!forceReload && _cache is not null && file.LastModified <= _lastRead)
            return _cache;

        using var stream = file.CreateReadStream();
        using var reader = new StreamReader(stream);
        var css = await reader.ReadToEndAsync();

        // Busca cualquier selector que arranque con .xig-icon-<nombre>
        // Captura el nombre de la clase sin el punto ni pseudo-elementos
        // Ejemplos que cubre:
        // .xig-icon-empresa::before { ... }
        // .xig-icon-empresa:before  { ... }
        // .xig-icon-empresa, .xig-icon-otra { ... }
        var rx = new Regex(@"\.icon-([a-zA-Z0-9_-]+)", RegexOptions.Multiline);

        var names = rx.Matches(css)
                      .Select(m => m.Groups[1].Value)
                      .Distinct(StringComparer.OrdinalIgnoreCase)
                      .OrderBy(n => n, StringComparer.OrdinalIgnoreCase)
                      .ToArray();

        _cache    = names;
        _lastRead = file.LastModified;
        return _cache;
    }
}
