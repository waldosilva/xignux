using Microsoft.JSInterop;

namespace Xignux.Juridico.Inmuebles.Web.Services;


public sealed class SweetAlertService : ISweetAlertService, IAsyncDisposable
{
    private readonly IJSRuntime _js;
    private IJSObjectReference? _module;

    public SweetAlertService(IJSRuntime js) => _js = js;

    private async ValueTask<IJSObjectReference> ModuleAsync()
        => _module ??= await _js.InvokeAsync<IJSObjectReference>("import", "./js/swal.js");

    public async Task<bool> ConfirmAsync(string title, string text, string confirmText = "Sí", string cancelText = "No")
        => await (await ModuleAsync()).InvokeAsync<bool>("confirm", title, text, confirmText, cancelText);

    public async Task AlertAsync(string title, string text = "", string icon = "info")
        => await (await ModuleAsync()).InvokeVoidAsync("alert", title, text, icon);

    public async Task ToastAsync(string message, string icon)
        => await (await ModuleAsync()).InvokeVoidAsync("toast", message, icon);

    public async ValueTask DisposeAsync()
    {
        if (_module is not null) await _module.DisposeAsync();
    }
}
