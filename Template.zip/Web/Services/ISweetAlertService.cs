namespace Xignux.Juridico.Inmuebles.Web.Services;

public interface ISweetAlertService
{
    
    Task<bool> ConfirmAsync(string title, string text,
        string confirmText = "Eliminar", string cancelText = "Cancelar");
    Task AlertAsync(string title, string text = "", string icon = "info");
    Task ToastAsync(string message, string icon = "success");

}