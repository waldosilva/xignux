namespace Xignux.Juridico.Inmuebles.Web.Services;

public interface IBlobStorageService
{
    // Sube usando la clave completa dentro del contenedor (ej. "views/2025/09/18/file.jpg")
    Task<string> UploadAsync(string blobKey, Stream data, string contentType, CancellationToken ct = default);

    // Borra por clave dentro del contenedor (útil si ya conoces el blobKey)
    Task<bool> DeleteIfExistsAsync(string blobKey, CancellationToken ct = default);

    // Genera SAS de solo lectura a partir de una URL pública o con SAS
    Task<string> GetReadOnlySasUrlAsync(string blobUrl, TimeSpan duracion, CancellationToken ct = default);

    // Borra directamente a partir de la URL (evita errores con prefijos/rutas)
    Task<bool> DeleteByUrlIfExistsAsync(string blobUrl, CancellationToken ct = default);
}

