using Microsoft.AspNetCore.Components;

namespace Xignux.Juridico.Inmuebles.Web.Features.Configuracion.Pages;

public partial class Roles : ComponentBase
{
}