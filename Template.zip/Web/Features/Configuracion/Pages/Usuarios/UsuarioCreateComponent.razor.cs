using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Response;
using Xignux.Juridico.Inmuebles.Web.Common.Security;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Empresas;
using Xignux.Juridico.Inmuebles.Web.Contracts.Configuracion.Roles;
using Xignux.Juridico.Inmuebles.Web.Contracts.Configuracion.Usuarios;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Features.Configuracion.Pages.Usuarios;

public partial class UsuarioCreateComponent : ComponentBase
{
    [Parameter] public EventCallback OnSaved { get; set; }
    [Parameter] public EventCallback OnCancel { get; set; }
    [CascadingParameter] private Task<AuthenticationState> AuthState { get; set; } = default!;

    [Inject] private IUsuarioService Service { get; set; } = default!;
    [Inject] private ICrudService<EmpresaCreateDto, EmpresaReadDto, EmpresaUpdateDto, int> ServiceEmpresa { get; set; } = default!;
    [Inject] private ICrudService<RolCreateDto, RolReadDto, RolUpdateDto, int> ServiceRol { get; set; } = default!;
    
    [Inject] private ISweetAlertService Swal { get; set; } = default!;
    
    protected PageFilter Filter { get; set; } = new();

    public UsuarioCreateDto Model { get; set; } = new();

    private bool _saving;
    private bool _disposed;
    private List<EmpresaReadDto> _empresas = new();
    private List<RolReadDto> _roles = new();

    protected override async Task OnInitializedAsync()
    {
        await CargarRolesAsync();
        await CargarEmpresasAsync();
    }
    
    private async Task CargarRolesAsync()
    {
        try
        {
            Filter = new PageFilter
            {
                Page = 1,
                PageSize = 500,
                SortBy = "RolId",
                SortDir = "ASC",
                Search = string.Empty,
                ColumnFilters = new Dictionary<string, string>
                {
                    ["Activo"] = "true"   // <-- así se agrega un par clave/valor
                }
            };

            var paged = await ServiceRol.GetPagedAsync(Filter);

            _roles = paged?.Payload?.Items?.ToList() ?? new List<RolReadDto>();

            if (Model.RolId == 0 && _roles.Count == 1)
                Model.RolId = _roles[0].RolId;
        }
        catch (Exception ex)
        {
            try { if (!_disposed) await Swal.ToastAsync($"No fue posible cargar países: {ex.Message}", "warning"); } catch { }
        }
    }

    private async Task CargarEmpresasAsync()
    {
        try
        {
            Filter = new PageFilter
            {
                Page = 1,
                PageSize = 500,
                SortBy = "EmpresaId",
                SortDir = "ASC",
                Search = string.Empty,
                ColumnFilters = new Dictionary<string, string>
                {
                    ["Activo"] = "true"   // <-- así se agrega un par clave/valor
                }
            };

            var paged = await ServiceEmpresa.GetPagedAsync(Filter);

            _empresas = paged?.Payload?.Items?.ToList() ?? new List<EmpresaReadDto>();

            if (Model.EmpresaId == 0 && _empresas.Count == 1)
                Model.EmpresaId = _empresas[0].EmpresaId;
        }
        catch (Exception ex)
        {
            try { if (!_disposed) await Swal.ToastAsync($"No fue posible cargar estados: {ex.Message}", "warning"); } catch { }
        }
    }


    public void Dispose() => _disposed = true;

    private async Task SaveAsync()
    {
        if (_saving) return;
        _saving = true;

        if (!_disposed)
        {
            await InvokeAsync(StateHasChanged);
            await Task.Yield();
        }

        bool success = false;

        try
        {
            if (Model.EmpresaId == 0)
                throw new InvalidOperationException("Selecciona un estado.");

            var user = (await AuthState).User;
            var alias = user.GetEmailLocalPart();
            Model.CreadoPor = string.IsNullOrWhiteSpace(alias) ? "sistema" : alias;

            var id = await Service.CreateAsync(Model);

            if (id != 0)
            {
                success = true;
                if (!_disposed) { try { await Swal.ToastAsync($"Se ha registrado un nuevo Usuario con el ID {id}"); } catch { } }
            }
            else
            {
                if (!_disposed) { try { await Swal.AlertAsync("Error", "No se pudo crear el Usuario.", "error"); } catch { } }
            }
        }
        catch (Exception ex)
        {
            try { if (!_disposed) await Swal.AlertAsync("Error", ex.Message, "error"); } catch { }
        }
        finally
        {
            _saving = false;
            if (!_disposed) await InvokeAsync(StateHasChanged);
        }

        if (success)
        {
            await OnSaved.InvokeAsync();
        }
    }

    private async Task Cancel()
    {
        if (_saving) return;
        await OnCancel.InvokeAsync();
    }
}