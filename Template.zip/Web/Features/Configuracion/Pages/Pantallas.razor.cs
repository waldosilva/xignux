using Microsoft.AspNetCore.Components;

namespace Xignux.Juridico.Inmuebles.Web.Features.Configuracion.Pages;

public partial class Pantallas : ComponentBase
{
}