using Microsoft.AspNetCore.Components;

namespace Xignux.Juridico.Inmuebles.Web.Features.Catalogos.Pages;

public partial class Catalogos : ComponentBase
{
}