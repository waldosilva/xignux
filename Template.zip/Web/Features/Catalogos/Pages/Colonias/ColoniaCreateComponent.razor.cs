using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Response;
using Xignux.Juridico.Inmuebles.Web.Common.Security;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Colonias;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Estados;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Municipios;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Paises;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Features.Catalogos.Pages.Colonias;

public partial class ColoniaCreateComponent : ComponentBase
{
    [Parameter] public EventCallback OnSaved { get; set; }
    [Parameter] public EventCallback OnCancel { get; set; }
    [CascadingParameter] private Task<AuthenticationState> AuthState { get; set; } = default!;

    [Inject] private ICrudService<PaisCreateDto, PaisReadDto, PaisUpdateDto, int> ServicePais { get; set; } = default!;

    [Inject]
    private ICrudService<EstadoCreateDto, EstadoReadDto, EstadoUpdateDto, int> ServiceEstado { get; set; } = default!;

    [Inject]
    private ICrudService<MunicipioCreateDto, MunicipioReadDto, MunicipioUpdateDto, int> ServiceMunicipio { get; set; } =
        default!;

    [Inject]
    private ICrudService<ColoniaCreateDto, ColoniaReadDto, ColoniaUpdateDto, int> Service { get; set; } = default!;

    [Inject] private ISweetAlertService Swal { get; set; } = default!;

    public ColoniaCreateDto Model { get; set; } = new();
    protected PageFilter Filter { get; set; } = new();

    private bool _saving;
    private bool _disposed;

    private List<PaisReadDto> _paises = new();
    private List<EstadoReadDto> _estados = new();
    private List<MunicipioReadDto> _municipios = new();

    public void Dispose() => _disposed = true;

    protected override async Task OnInitializedAsync()
    {
        await CargarPaisesAsync();

        if (Model.PaisId > 0)
            await CargarEstadosAsync(Model.PaisId);

        if (Model.EstadoId > 0)
            await CargarMunicipiosAsync(Model.EstadoId);
    }

    private async Task CargarPaisesAsync()
    {
        try
        {
            Filter = new PageFilter
            {
                Page = 1,
                PageSize = 250,
                SortBy = "PaisId",
                SortDir = "ASC",
                Search = string.Empty,
                ColumnFilters = new Dictionary<string, string>
                {
                    ["Activo"] = "true"
                }
            };

            var paged = await ServicePais.GetPagedAsync(Filter);
            _paises = paged?.Payload?.Items?.ToList() ?? new List<PaisReadDto>();

            if (Model.PaisId == 0 && _paises.Count == 1)
                Model.PaisId = _paises[0].PaisId;
        }
        catch (Exception ex)
        {
            try
            {
                if (!_disposed) await Swal.ToastAsync($"No fue posible cargar países: {ex.Message}", "warning");
            }
            catch
            {
            }
        }
    }

    private async Task CargarEstadosAsync(int paisId)
    {
        try
        {
            if (paisId <= 0)
            {
                _estados.Clear();
                return;
            }

            Filter = new PageFilter
            {
                Page = 1,
                PageSize = 100,
                SortBy = "EstadoId",
                SortDir = "ASC",
                Search = string.Empty,
                ColumnFilters = new Dictionary<string, string>
                {
                    ["Activo"] = "true",
                    // <-- filtro por país
                    ["PaisId"] = paisId.ToString()
                }
            };

            var paged = await ServiceEstado.GetPagedAsync(Filter);
            _estados = paged?.Payload?.Items?.ToList() ?? new List<EstadoReadDto>();

            if (Model.EstadoId == 0 && _estados.Count == 1)
                Model.EstadoId = _estados[0].EstadoId;
        }
        catch (Exception ex)
        {
            try
            {
                if (!_disposed) await Swal.ToastAsync($"No fue posible cargar estados: {ex.Message}", "warning");
            }
            catch
            {
            }
        }
    }

    private async Task CargarMunicipiosAsync(int estadoId)
    {
        try
        {
            if (estadoId <= 0)
            {
                _municipios.Clear();
                return;
            }

            Filter = new PageFilter
            {
                Page = 1,
                PageSize = 1000,
                SortBy = "MunicipioId",
                SortDir = "ASC",
                Search = string.Empty,
                ColumnFilters = new Dictionary<string, string>
                {
                    ["Activo"] = "true",
                    // <-- filtro por estado
                    ["EstadoId"] = estadoId.ToString()
                }
            };

            var paged = await ServiceMunicipio.GetPagedAsync(Filter);
            _municipios = paged?.Payload?.Items?.ToList() ?? new List<MunicipioReadDto>();

            if (Model.MunicipioId == 0 && _municipios.Count == 1)
                Model.MunicipioId = _municipios[0].MunicipioId;
        }
        catch (Exception ex)
        {
            try
            {
                if (!_disposed) await Swal.ToastAsync($"No fue posible cargar municipios: {ex.Message}", "warning");
            }
            catch
            {
            }
        }
    }

    // =============== Handlers de cambio ===============

    private async Task OnPaisChanged(int newPaisId)
    {
        // Actualiza modelo y limpia dependencias
        Model.PaisId = newPaisId;
        Model.EstadoId = 0;
        Model.MunicipioId = 0;
        Model.Codigo = null;
        Model.CodigoPostal = null;
        Model.Descripcion = null;

        _estados.Clear();
        _municipios.Clear();

        await CargarEstadosAsync(newPaisId);

        if (!_disposed)
            await InvokeAsync(StateHasChanged);
    }

    private async Task OnEstadoChanged(int newEstadoId)
    {
        Model.EstadoId = newEstadoId;
        Model.MunicipioId = 0;
        Model.Codigo = null;
        Model.CodigoPostal = null;
        Model.Descripcion = null;

        _municipios.Clear();

        await CargarMunicipiosAsync(newEstadoId);

        if (!_disposed)
            await InvokeAsync(StateHasChanged);
    }

    // =============== Guardar / Cancelar (sin cambios) ===============
    private async Task SaveAsync()
    {
        if (_saving) return;
        _saving = true;

        if (!_disposed)
        {
            await InvokeAsync(StateHasChanged);
            await Task.Yield();
        }

        bool success = false;

        try
        {
            var user = (await AuthState).User;
            var alias = user.GetEmailLocalPart();
            Model.CreadoPor = string.IsNullOrWhiteSpace(alias) ? "sistema" : alias;

            var id = await Service.CreateAsync(Model);

            if (id != 0)
            {
                success = true;
                if (!_disposed)
                {
                    try
                    {
                        await Swal.ToastAsync($"Se ha registrado una nueva colonia con el ID {id}");
                    }
                    catch
                    {
                    }
                }
            }
            else
            {
                if (!_disposed)
                {
                    try
                    {
                        await Swal.AlertAsync("Error", "No se pudo crear la colonia.", "error");
                    }
                    catch
                    {
                    }
                }
            }
        }
        catch (Exception ex)
        {
            try
            {
                if (!_disposed) await Swal.AlertAsync("Error", ex.Message, "error");
            }
            catch
            {
            }
        }
        finally
        {
            _saving = false;
            if (!_disposed) await InvokeAsync(StateHasChanged);
        }

        if (success)
            await OnSaved.InvokeAsync();
    }

    private async Task Cancel()
    {
        if (_saving) return;
        await OnCancel.InvokeAsync();
    }
}