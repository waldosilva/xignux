using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Response;
using Xignux.Juridico.Inmuebles.Web.Common.Security;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Colonias;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Estados;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Municipios;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Paises;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Features.Catalogos.Pages.Colonias;

public partial class ColoniaUpdateComponent : ComponentBase, IDisposable
{
    [Parameter] public int Id { get; set; }

    [Parameter] public EventCallback OnSaved { get; set; }
    [Parameter] public EventCallback OnCancel { get; set; }

    [CascadingParameter] private Task<AuthenticationState> AuthState { get; set; } = default!;

    [Inject] private ICrudService<PaisCreateDto, PaisReadDto, PaisUpdateDto, int> ServicePais { get; set; } = default!;

    [Inject]
    private ICrudService<EstadoCreateDto, EstadoReadDto, EstadoUpdateDto, int> ServiceEstado { get; set; } = default!;

    [Inject]
    private ICrudService<MunicipioCreateDto, MunicipioReadDto, MunicipioUpdateDto, int> ServiceMunicipio { get; set; } =
        default!;

    [Inject]
    private ICrudService<ColoniaCreateDto, ColoniaReadDto, ColoniaUpdateDto, int> Service { get; set; } = default!;

    [Inject] private ISweetAlertService Swal { get; set; } = default!;

    public ColoniaUpdateDto Model { get; set; } = new();
    protected PageFilter Filter { get; set; } = new();

    protected bool _loading;
    protected bool _saving;
    private bool _disposed;

    private ColoniaReadDto? _read;
    private List<PaisReadDto> _paises = new();
    private List<EstadoReadDto> _estados = new();
    private List<MunicipioReadDto> _municipios = new();

    public void Dispose() => _disposed = true;

    protected override async Task OnParametersSetAsync()
    {
        await LoadAsync(); // Carga el registro y Model
        await CargarPaisesAsync(); // Catálogo base
        await CargarEstadosAsync(Model.PaisId); // Filtrado por país actual
        await CargarMunicipiosAsync(Model.EstadoId); // Filtrado por estado actual
        AsegurarPaisActualEnLista();
        AsegurarEstadoActualEnLista();
        AsegurarMunicipioActualEnLista();
        if (!_disposed) StateHasChanged();
    }

    private async Task LoadAsync(CancellationToken ct = default)
    {
        _loading = true;
        if (!_disposed)
        {
            await InvokeAsync(StateHasChanged);
            await Task.Yield();
        }

        try
        {
            var resp = await Service.GetByIdAsync(Id, ct);
            if (resp?.Payload is null || resp.StatusCode == 404)
            {
                if (!_disposed)
                {
                    try
                    {
                        await Swal.AlertAsync("No encontrado", "La colonia no existe.", "warning");
                    }
                    catch
                    {
                    }
                }

                await OnCancel.InvokeAsync();
                return;
            }

            _read = resp.Payload; // <-- A S I G N A R  EL READ
            Model = MapFrom(resp.Payload); // Map a UpdateDto
        }
        catch (Exception ex)
        {
            if (!_disposed)
            {
                try
                {
                    await Swal.AlertAsync("Error", ex.Message, "error");
                }
                catch
                {
                }
            }

            await OnCancel.InvokeAsync();
        }
        finally
        {
            _loading = false;
            if (!_disposed) await InvokeAsync(StateHasChanged);
        }
    }

    private async Task CargarPaisesAsync()
    {
        try
        {
            Filter = new PageFilter
            {
                Page = 1,
                PageSize = 250,
                SortBy = "PaisId",
                SortDir = "ASC",
                Search = string.Empty,
                ColumnFilters = new Dictionary<string, string> { ["Activo"] = "true" }
            };

            var paged = await ServicePais.GetPagedAsync(Filter);
            _paises = paged?.Payload?.Items?.ToList() ?? new();
            if (Model.PaisId == 0 && _paises.Count == 1) Model.PaisId = _paises[0].PaisId;
        }
        catch (Exception ex)
        {
            try
            {
                if (!_disposed) await Swal.ToastAsync($"No fue posible cargar países: {ex.Message}", "warning");
            }
            catch
            {
            }
        }
    }

    private async Task CargarEstadosAsync(int paisId)
    {
        try
        {
            _estados.Clear();
            if (paisId <= 0) return;

            Filter = new PageFilter
            {
                Page = 1,
                PageSize = 200,
                SortBy = "EstadoId",
                SortDir = "ASC",
                Search = string.Empty,
                ColumnFilters = new Dictionary<string, string>
                {
                    ["Activo"] = "true",
                    ["PaisId"] = paisId.ToString()
                }
            };

            var paged = await ServiceEstado.GetPagedAsync(Filter);
            _estados = paged?.Payload?.Items?.ToList() ?? new();
            if (Model.EstadoId == 0 && _estados.Count == 1) Model.EstadoId = _estados[0].EstadoId;
        }
        catch (Exception ex)
        {
            try
            {
                if (!_disposed) await Swal.ToastAsync($"No fue posible cargar estados: {ex.Message}", "warning");
            }
            catch
            {
            }
        }
    }

    private async Task CargarMunicipiosAsync(int estadoId)
    {
        try
        {
            _municipios.Clear();
            if (estadoId <= 0) return;

            Filter = new PageFilter
            {
                Page = 1,
                PageSize = 1000,
                SortBy = "MunicipioId",
                SortDir = "ASC",
                Search = string.Empty,
                ColumnFilters = new Dictionary<string, string>
                {
                    ["Activo"] = "true",
                    ["EstadoId"] = estadoId.ToString()
                }
            };

            var paged = await ServiceMunicipio.GetPagedAsync(Filter);
            _municipios = paged?.Payload?.Items?.ToList() ?? new();
            if (Model.MunicipioId == 0 && _municipios.Count == 1) Model.MunicipioId = _municipios[0].MunicipioId;
        }
        catch (Exception ex)
        {
            try
            {
                if (!_disposed) await Swal.ToastAsync($"No fue posible cargar municipios: {ex.Message}", "warning");
            }
            catch
            {
            }
        }
    }

    // =================== Handlers de cambio ===================

    private async Task OnPaisChanged(int newPaisId)
    {
        Model.PaisId = newPaisId;

        // Limpiar dependientes
        Model.EstadoId = 0;
        Model.MunicipioId = 0;

        // (Opcional) limpiar campos derivados
        // Model.Codigo = null;
        // Model.CodigoPostal = null;
        // Model.Descripcion = null;

        _estados.Clear();
        _municipios.Clear();

        await CargarEstadosAsync(newPaisId);
        if (!_disposed) await InvokeAsync(StateHasChanged);
    }

    private async Task OnEstadoChanged(int newEstadoId)
    {
        Model.EstadoId = newEstadoId;

        // Limpiar dependiente
        Model.MunicipioId = 0;

        // (Opcional) limpiar campos derivados
        // Model.Codigo = null;
        // Model.CodigoPostal = null;
        // Model.Descripcion = null;

        _municipios.Clear();

        await CargarMunicipiosAsync(newEstadoId);
        if (!_disposed) await InvokeAsync(StateHasChanged);
    }

    private void AsegurarPaisActualEnLista()
    {
        if (Model?.PaisId > 0 && !_paises.Any(x => x.PaisId == Model.PaisId))
        {
            // Intentamos obtener nombre desde el read, si lo tenemos
            var nombre = _read?.PaisNombre;
            // Agrega una opción sintética para que el select pueda marcarlo
            _paises.Insert(0, new PaisReadDto
            {
                PaisId = Model.PaisId,
                Descripcion = string.IsNullOrWhiteSpace(nombre) ? $"País #{Model.PaisId}" : nombre!.Trim(),
                Activo = true
            });
        }
    }

    private void AsegurarEstadoActualEnLista()
    {
        if (Model?.EstadoId > 0 && !_estados.Any(x => x.EstadoId == Model.EstadoId))
        {
            // Intentamos obtener nombre desde el read, si lo tenemos
            var nombre = _read?.EstadoNombre;
            // Agrega una opción sintética para que el select pueda marcarlo
            _estados.Insert(0, new EstadoReadDto
            {
                EstadoId = Model.EstadoId,
                Descripcion = string.IsNullOrWhiteSpace(nombre) ? $"Estado #{Model.EstadoId}" : nombre!.Trim(),
                Activo = true,
                PaisId = Model.PaisId
            });
        }
    }

    private void AsegurarMunicipioActualEnLista()
    {
        if (Model?.MunicipioId > 0 && !_municipios.Any(x => x.MunicipioId == Model.MunicipioId))
        {
            // Intentamos obtener nombre desde el read, si lo tenemos
            var nombre = _read?.MunicipioNombre;
            // Agrega una opción sintética para que el select pueda marcarlo
            _municipios.Insert(0, new MunicipioReadDto
            {
                MunicipioId = Model.MunicipioId,
                Descripcion = string.IsNullOrWhiteSpace(nombre) ? $"Municipio #{Model.MunicipioId}" : nombre!.Trim(),
                Activo = true,
                EstadoId = Model.EstadoId
            });
        }
    }

    private static ColoniaUpdateDto MapFrom(ColoniaReadDto src)
        => new()
        {
            Codigo = src.Codigo?.Trim(),
            CodigoPostal = src.CodigoPostal?.Trim(),
            Descripcion = src.ColoniaNombre?.Trim(),
            PaisId = src.PaisId,
            EstadoId = src.EstadoId,
            MunicipioId = src.MunicipioId,
            Activo = src.Activo,
            // ModificadoPor se coloca al guardar con el usuario actual
            ModificadoPor = null
        };

    protected async Task SaveAsync()
    {
        if (_saving || _loading) return;
        _saving = true;

        if (!_disposed)
        {
            await InvokeAsync(StateHasChanged); // muestra spinner
            await Task.Yield();
        }

        bool success = false;

        try
        {
            var user = (await AuthState).User;
            var alias = user.GetEmailLocalPart(); // parte antes de '@'
            Model.ModificadoPor = string.IsNullOrWhiteSpace(alias) ? "sistema" : alias;

            var ok = await Service.UpdateAsync(Id, Model);
            if (ok)
            {
                success = true;
                if (!_disposed)
                {
                    try
                    {
                        await Swal.ToastAsync("Cambios guardados");
                    }
                    catch
                    {
                    }
                }
            }
            else
            {
                if (!_disposed)
                {
                    try
                    {
                        await Swal.AlertAsync("No guardado", "No se pudo actualizar la colonia.", "error");
                    }
                    catch
                    {
                    }
                }
            }
        }
        catch (Exception ex)
        {
            if (!_disposed)
            {
                try
                {
                    await Swal.AlertAsync("Error", ex.Message, "error");
                }
                catch
                {
                }
            }
        }
        finally
        {
            _saving = false;
            if (!_disposed) await InvokeAsync(StateHasChanged);
        }

        if (success)
        {
            await OnSaved.InvokeAsync(); // el padre suele cerrar el modal aquí
        }
    }

    protected async Task Cancel()
    {
        if (_saving || _loading) return;
        await OnCancel.InvokeAsync();
    }
}