using Microsoft.AspNetCore.Components;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Response;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeDocumentos;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Features.Catalogos.Pages.TiposDeDocumentos;

public partial class TipoDocumento : ComponentBase
{
    [Inject] ICrudService<TipoDocumentoCreateDto, TipoDocumentoReadDto, TipoDocumentoUpdateDto, int> Service { get; set; } = default!;
    [Inject] ISweetAlertService Swal { get; set; } = default!;

    protected BaseResponseModel<PagedResult<TipoDocumentoReadDto>>? ItemsLst;
    protected bool _loading;
    protected int _currentPage = 1, _pageSize = 10, _totalPages = 1, _totalCount = 0;
    protected string _sortBy = "TipoDocumentoId", _sortDir = "ASC";
    private string _searchTerm = string.Empty;

    // Modales / acciones
    protected bool _showCreate, _showEdit, _showAudit;
    protected int? _editId;
    protected AuditDto? _audit;

    protected override async Task OnInitializedAsync() => await LoadDataAsync();

    protected async Task LoadDataAsync()
    {
        _loading = true;
        StateHasChanged();

        try
        {
            var filter = new PageFilter
            {
                Page = _currentPage,
                PageSize = _pageSize,
                SortBy = _sortBy,
                SortDir = _sortDir,
                Search = _searchTerm,
            };

            var resp = await Service.GetPagedAsync(filter);
            var payload = resp?.Payload;

            if (payload is null)
            {
                ItemsLst = null;
                _totalCount = 0;
                _totalPages = 1;
                return;
            }

            ItemsLst = new BaseResponseModel<PagedResult<TipoDocumentoReadDto>>
            {
                Payload = payload
            };

            _totalCount = payload.TotalCount;
            _pageSize = payload.PageSize > 0 ? payload.PageSize : _pageSize;

            var pageFromApi = payload.Page > 0 ? payload.Page : _currentPage;
            _currentPage = pageFromApi;

            _totalPages = payload.TotalPages > 0
                ? payload.TotalPages
                : Math.Max(1, (int)Math.Ceiling((_totalCount * 1.0) / Math.Max(1, _pageSize)));

            if (_currentPage < 1) _currentPage = 1;
            if (_currentPage > _totalPages) _currentPage = _totalPages;
        }
        catch (Exception ex)
        {
            try
            {
                await Swal.ToastAsync($"Error al cargar: {ex.Message}", "error");
            }
            catch
            {
            }
        }
        finally
        {
            _loading = false;
            StateHasChanged();
        }
    }

    protected async Task Search()
    {
        _currentPage = 1;
        await LoadDataAsync();
    }

    protected async Task ClearSearch()
    {
        _searchTerm = string.Empty;
        _currentPage = 1;
        await LoadDataAsync();
    }

    protected async Task ChangePage(int newPage)
    {
        if (newPage >= 1 && newPage <= _totalPages)
        {
            _currentPage = newPage;
            await LoadDataAsync();
        }
    }

    protected async Task OnPageSizeChanged(int newPageSize)
    {
        _pageSize = newPageSize;
        _currentPage = 1;
        await LoadDataAsync();
    }

    protected async Task SortByColumn(string column)
    {
        if (_sortBy == column)
        {
            _sortDir = _sortDir == "ASC" ? "DESC" : "ASC";
        }
        else
        {
            _sortBy = column;
            _sortDir = "ASC";
        }
        await LoadDataAsync();
    }

    protected string SortByColumnIndicator(string column)
    {
        if (_sortBy != column) return "";
        return _sortDir == "ASC" ? "▲" : "▼";
    }

    // Modales
    protected void NewRecord()
    {
        _showCreate = true;
    }

    protected void CloseCreate()
    {
        _showCreate = false;
    }

    protected async Task HandleCreateSaved()
    {
        _showCreate = false;
        await LoadDataAsync();
        try
        {
            await Swal.ToastAsync("Registro creado exitosamente", "success");
        }
        catch { }
    }

    protected void EditRecord(int id)
    {
        _editId = id;
        _showEdit = true;
    }

    protected void CloseEdit()
    {
        _showEdit = false;
        _editId = null;
    }

    protected async Task HandleEditSaved()
    {
        _showEdit = false;
        _editId = null;
        await LoadDataAsync();
        try
        {
            await Swal.ToastAsync("Registro actualizado exitosamente", "success");
        }
        catch { }
    }

    protected async Task DeleteRecord(int id)
    {
        try
        {
            var confirmed = await Swal.ConfirmAsync("¿Está seguro de que desea eliminar este registro?", "Confirmación");
            if (confirmed)
            {
                var success = await Service.DeleteAsync(id);
                if (success)
                {
                    await LoadDataAsync();
                    await Swal.ToastAsync("Registro eliminado exitosamente", "success");
                }
                else
                {
                    await Swal.ToastAsync("Error al eliminar el registro", "error");
                }
            }
        }
        catch (Exception ex)
        {
            await Swal.ToastAsync($"Error: {ex.Message}", "error");
        }
    }

    protected void ShowAudit(TipoDocumentoReadDto item)
    {
        _audit = new AuditDto
        {
            CreadoPor = item.CreadoPor,
            FechaCreacion = item.FechaCreacion,
            ModificadoPor = item.ModificadoPor,
            FechaModificacion = item.FechaModificacion
        };
        _showAudit = true;
    }

    protected void CloseAudit()
    {
        _showAudit = false;
        _audit = null;
    }
}