using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Security;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeDocumentos;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Features.Catalogos.Pages.TiposDeDocumentos;

public partial class TipoDocumentoUpdateComponent : ComponentBase
{
    [Parameter] public int Id { get; set; }
    [Parameter] public EventCallback OnSaved { get; set; }
    [Parameter] public EventCallback OnCancel { get; set; }
    [CascadingParameter] private Task<AuthenticationState> AuthState { get; set; } = default!;

    [Inject] private ICrudService<TipoDocumentoCreateDto, TipoDocumentoReadDto, TipoDocumentoUpdateDto, int> Service { get; set; } = default!;
    [Inject] private ISweetAlertService Swal { get; set; } = default!;

    public TipoDocumentoUpdateDto Model { get; set; } = new();
    
    protected bool _loading;
    protected bool _saving;
    private bool _disposed;
    private TipoDocumentoReadDto? _read;

    public void Dispose() => _disposed = true;

    protected override async Task OnInitializedAsync()
    {
        var authState = await AuthState;
        var user = authState.User;
        Model.ModificadoPor = user?.GetAuditName() ?? "Unknown";
        
        await LoadDataAsync();
    }

    private async Task LoadDataAsync()
    {
        try
        {
            _loading = true;
            StateHasChanged();

            var response = await Service.GetByIdAsync(Id);
            if (response?.Payload != null)
            {
                _read = response.Payload;
                Model = new TipoDocumentoUpdateDto
                {
                    TipoDocumentoId = _read.TipoDocumentoId,
                    Nombre = _read.Nombre,
                    Descripcion = _read.Descripcion,
                    Activo = _read.Activo,
                    ModificadoPor = Model.ModificadoPor,
                    CatTipoDocumentoId = _read.CatTipoDocumentoId
                };
            }
            else
            {
                await Swal.ToastAsync("No se pudo cargar el registro", "error");
            }
        }
        catch (Exception ex)
        {
            await Swal.ToastAsync($"Error al cargar: {ex.Message}", "error");
        }
        finally
        {
            _loading = false;
            if (!_disposed) StateHasChanged();
        }
    }

    private async Task HandleValidSubmit()
    {
        if (_saving) return;

        try
        {
            _saving = true;
            StateHasChanged();

            var success = await Service.UpdateAsync(Id, Model);
            if (success)
            {
                await OnSaved.InvokeAsync();
            }
            else
            {
                await Swal.ToastAsync("Error al actualizar el registro", "error");
            }
        }
        catch (Exception ex)
        {
            await Swal.ToastAsync($"Error: {ex.Message}", "error");
        }
        finally
        {
            _saving = false;
            if (!_disposed) StateHasChanged();
        }
    }

    private async Task HandleCancel()
    {
        await OnCancel.InvokeAsync();
    }
}