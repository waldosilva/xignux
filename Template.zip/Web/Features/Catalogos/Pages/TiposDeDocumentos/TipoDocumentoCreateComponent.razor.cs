using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Security;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeDocumentos;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Features.Catalogos.Pages.TiposDeDocumentos;

public partial class TipoDocumentoCreateComponent : ComponentBase
{
    [Parameter] public EventCallback OnSaved { get; set; }
    [Parameter] public EventCallback OnCancel { get; set; }
    [CascadingParameter] private Task<AuthenticationState> AuthState { get; set; } = default!;

    [Inject] private ICrudService<TipoDocumentoCreateDto, TipoDocumentoReadDto, TipoDocumentoUpdateDto, int> Service { get; set; } = default!;
    [Inject] private ISweetAlertService Swal { get; set; } = default!;

    private TipoDocumentoCreateDto _model = new();
    private bool _saving;

    protected override async Task OnInitializedAsync()
    {
        var authState = await AuthState;
        var user = authState.User;
        _model.CreadoPor = user?.GetAuditName() ?? "Unknown";
    }

    private async Task HandleValidSubmit()
    {
        if (_saving) return;

        try
        {
            _saving = true;
            StateHasChanged();

            var result = await Service.CreateAsync(_model);
            if (result > 0)
            {
                await OnSaved.InvokeAsync();
            }
            else
            {
                await Swal.ToastAsync("Error al crear el registro", "error");
            }
        }
        catch (Exception ex)
        {
            await Swal.ToastAsync($"Error: {ex.Message}", "error");
        }
        finally
        {
            _saving = false;
            StateHasChanged();
        }
    }

    private async Task HandleCancel()
    {
        await OnCancel.InvokeAsync();
    }
}