using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Response;
using Xignux.Juridico.Inmuebles.Web.Common.Security;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Documentos;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeDocumentos;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Features.Catalogos.Pages.Documentos;

public partial class DocumentoCreateComponent : ComponentBase
{
    [Parameter] public EventCallback OnSaved { get; set; }
    [Parameter] public EventCallback OnCancel { get; set; }
    [CascadingParameter] private Task<AuthenticationState> AuthState { get; set; } = default!;

    [Inject] private ICrudService<DocumentoCreateDto, DocumentoReadDto, DocumentoUpdateDto, int> Service { get; set; } = default!;
    [Inject] private ICrudService<TipoDocumentoCreateDto, TipoDocumentoReadDto, TipoDocumentoUpdateDto, int> TipoDocumentoService { get; set; } = default!;
    [Inject] private ISweetAlertService Swal { get; set; } = default!;

    private DocumentoCreateDto _model = new();
    private bool _saving;
    private bool _loadingTipos;
    private List<TipoDocumentoReadDto> _tiposDocumento = new();
    private List<CriticidadOption> _criticidadesDocumento = new()
    {
        new() { Id = 1, Nombre = "Baja" },
        new() { Id = 2, Nombre = "Media" },
        new() { Id = 3, Nombre = "Alta" },
        new() { Id = 4, Nombre = "Crítica" }
    };

    protected override async Task OnInitializedAsync()
    {
        var authState = await AuthState;
        var user = authState.User;
        _model.CreadoPor = user?.GetAuditName() ?? "Unknown";
        
        await LoadTiposDocumentoAsync();
    }
    
    private async Task LoadTiposDocumentoAsync()
    {
        try
        {
            _loadingTipos = true;
            StateHasChanged();
            
            var filter = new PageFilter
            {
                Page = 1,
                PageSize = 100,
                SortBy = "Nombre",
                SortDir = "ASC"
            };
            
            var response = await TipoDocumentoService.GetPagedAsync(filter);
            if (response?.Payload?.Items != null)
            {
                _tiposDocumento = response.Payload.Items.Where(x => x.Activo).ToList();
            }
        }
        catch (Exception ex)
        {
            await Swal.ToastAsync($"Error al cargar tipos de documento: {ex.Message}", "error");
        }
        finally
        {
            _loadingTipos = false;
            StateHasChanged();
        }
    }

    private async Task HandleValidSubmit()
    {
        if (_saving) return;

        try
        {
            _saving = true;
            StateHasChanged();

            var result = await Service.CreateAsync(_model);
            if (result > 0)
            {
                await OnSaved.InvokeAsync();
            }
            else
            {
                await Swal.ToastAsync("Error al crear el documento", "error");
            }
        }
        catch (Exception ex)
        {
            await Swal.ToastAsync($"Error: {ex.Message}", "error");
        }
        finally
        {
            _saving = false;
            StateHasChanged();
        }
    }

    private async Task HandleCancel()
    {
        await OnCancel.InvokeAsync();
    }

    private class CriticidadOption
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
    }
}