using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Response;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Divisiones;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Features.Catalogos.Pages.Divisiones;

public partial class Divisiones : ComponentBase
{
    [Inject] ICrudService<DivisionCreateDto, DivisionReadDto, DivisionUpdateDto, int> Service { get; set; } = default!;
    [Inject] ISweetAlertService Swal { get; set; } = default!;
    [Inject] IBlobStorageService BlobStorage { get; set; } = default!;

    protected BaseResponseModel<PagedResult<DivisionReadDto>>? ItemsLst;
    protected bool _loading;
    protected int _currentPage = 1, _pageSize = 10, _totalPages = 1, _totalCount = 0;
    protected string _sortBy = "DivisionId", _sortDir = "ASC";
    private string _searchTerm = string.Empty;

    // Manejo de imagenes
    private bool _showImage;
    private string? _lightboxUrl;
    private string _lightboxCaption = "Imagen";

    // Modales / acciones
    protected bool _showCreate, _showEdit, _showAudit;
    protected int? _editId;
    protected AuditDto? _audit;

    protected override async Task OnInitializedAsync() => await LoadDataAsync();
    
    protected async Task LoadDataAsync()
    {
        _loading = true;
        StateHasChanged();

        try
        {
            var filter = new PageFilter
            {
                Page = _currentPage,
                PageSize = _pageSize,
                SortBy = _sortBy,
                SortDir = _sortDir,
                Search = _searchTerm,
            };

            var resp = await Service.GetPagedAsync(filter);
            var payload = resp?.Payload;

            if (payload is null)
            {
                ItemsLst = null;
                _totalCount = 0;
                _totalPages = 1;
                return;
            }

            // 🔐 Generar SAS para cada imagen
            foreach (var item in payload.Items)
            {
                if (!string.IsNullOrWhiteSpace(item.UrlImg))
                {
                    try
                    {
                        var uri = new Uri(item.UrlImg, UriKind.RelativeOrAbsolute);
                        item.UrlImg = await BlobStorage.GetReadOnlySasUrlAsync(uri.ToString(), TimeSpan.FromMinutes(15));
                    }
                    catch (UriFormatException)
                    {
                        Console.WriteLine($"URL inválida: {item.UrlImg}");
                        item.UrlImg = null; // o asigna una imagen por defecto
                    }
                }
            }

            // Asignar ItemsLst con las URLs ya protegidas
            ItemsLst = new BaseResponseModel<PagedResult<DivisionReadDto>>
            {
                Payload = payload
            };

            _totalCount = payload.TotalCount;
            _pageSize = payload.PageSize > 0 ? payload.PageSize : _pageSize;

            var pageFromApi = payload.Page > 0 ? payload.Page : _currentPage;
            _currentPage = pageFromApi;

            _totalPages = payload.TotalPages > 0
                ? payload.TotalPages
                : Math.Max(1, (int)Math.Ceiling((_totalCount * 1.0) / Math.Max(1, _pageSize)));

            if (_currentPage < 1) _currentPage = 1;
            if (_currentPage > _totalPages) _currentPage = _totalPages;
        }
        catch (Exception ex)
        {
            try
            {
                await Swal.ToastAsync($"Error al cargar: {ex.Message}", "error");
            }
            catch { }
        }
        finally
        {
            _loading = false;
            StateHasChanged();
        }
    }



    // Toolbar
    protected void NewRecord() => _showCreate = true;

    protected async Task Search()
    {
        _currentPage = 1;
        await LoadDataAsync();
    }

    protected async Task ClearSearch()
    {
        _searchTerm = string.Empty;
        _currentPage = 1;
        await LoadDataAsync();
    }

    // Sort
    protected async Task SortByColumn(string col)
    {
        if (_sortBy.Equals(col, StringComparison.OrdinalIgnoreCase))
            _sortDir = _sortDir.Equals("ASC", StringComparison.OrdinalIgnoreCase) ? "DESC" : "ASC";
        else
        {
            _sortBy = col;
            _sortDir = "ASC";
        }

        _currentPage = 1;
        await LoadDataAsync();
    }

    protected MarkupString SortByColumnIndicator(string col)
    {
        var isCurrent = _sortBy.Equals(col, StringComparison.OrdinalIgnoreCase);
        var arrow = isCurrent ? (_sortDir == "ASC" ? "▲" : "▼") : "◇";
        return (MarkupString)$"<span class='ms-1 text-white'>{arrow}</span>";
    }

    // Paginación
    protected async Task ChangePage(int p)
    {
        if (p < 1 || p > _totalPages) return;
        _currentPage = p;
        await LoadDataAsync();
    }

    protected async Task OnPageSizeChanged(int size)
    {
        _pageSize = size;
        _currentPage = 1;
        await LoadDataAsync();
    }

    // Acciones
    protected void ShowAudit(DivisionReadDto item)
    {
        _audit = MapAudit(item);
        _showAudit = true;
    }

    protected void CloseAudit() => _showAudit = false;
    protected void CloseCreate() => _showCreate = false;

    protected void CloseEdit()
    {
        _showEdit = false;
        _editId = null;
    }

    protected void EditRecord(int id)
    {
        _editId = id;
        _showEdit = true;
    }

    // === DELETE integrado: borra en BD y luego elimina el blob por URL ===
    private async Task DeleteRecord(int id, CancellationToken ct = default)
    {
        if (!await Swal.ConfirmAsync($"Eliminar registro No. {id}", "Esta acción no se puede deshacer"))
        {
            await Swal.ToastAsync("Acción cancelada", "info");
            return;
        }

        _loading = true;
        await InvokeAsync(StateHasChanged);
        await Task.Yield(); 
            
        string? originalUrl = null;

        try
        {
            // 1) Obtén la URL original ANTES de borrar en BD (crítico)
            var dto = await Service.GetByIdAsync(id);
            originalUrl = dto?.Payload?.UrlImg;

            // 2) Elimina en BD
            var ok = await Service.DeleteAsync(id);
            if (ok)
            {
                // 3) Si había imagen, elimina en Blob Storage por URL
                if (!string.IsNullOrWhiteSpace(originalUrl))
                {
                    try
                    {
                        await BlobStorage.DeleteByUrlIfExistsAsync(originalUrl!, ct);
                    }
                    catch
                    {
                        // No bloquees la UX; log si es necesario
                    }
                }

                await Swal.AlertAsync("Eliminado", "El registro fue eliminado", "success");
                await LoadDataAsync();
            }
            else
            {
                await Swal.AlertAsync("Error", "No fue posible eliminar el registro.", "error");
            }
        }
        catch (Exception ex)
        {
            try { await Swal.AlertAsync("Error", ex.Message, "error"); } catch { }
        }
        finally
        {
            _loading = false;
            await InvokeAsync(StateHasChanged);
        }
    }

    protected async Task HandleCreateSaved()
    {
        _showCreate = false;
        await LoadDataAsync();
    }

    protected async Task HandleEditSaved()
    {
        _showEdit = false;
        await LoadDataAsync();
    }

    private static AuditDto MapAudit(DivisionReadDto r) => new()
    {
        CreadoPor = r.CreadoPor, FechaCreacion = r.FechaCreacion,
        ModificadoPor = r.ModificadoPor, FechaModificacion = r.FechaModificacion,
    };

    // Manejo de miniatura de imagenes y modal para mostrarla
    private void OpenLightbox(string? url, string? caption)
    {
        if (string.IsNullOrWhiteSpace(url)) return;
        _lightboxUrl = url;
        _lightboxCaption = string.IsNullOrWhiteSpace(caption) ? "Imagen" : caption.Trim();
        _showImage = true;
        StateHasChanged();
    }

    private void CloseLightbox()
    {
        _showImage = false;
        _lightboxUrl = null;
        _lightboxCaption = "Imagen";
        StateHasChanged();
    }

    private void OnLightboxKeyDown(KeyboardEventArgs e)
    {
        if (e.Key == "Escape") CloseLightbox();
    }
}