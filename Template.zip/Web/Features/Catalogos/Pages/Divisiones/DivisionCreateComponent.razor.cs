using System.Security.Cryptography;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Forms;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Security;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Divisiones;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Features.Catalogos.Pages.Divisiones;

public partial class DivisionCreateComponent : ComponentBase
{
    [Parameter] public EventCallback OnSaved { get; set; }
    [Parameter] public EventCallback OnCancel { get; set; }
    [CascadingParameter] private Task<AuthenticationState> AuthState { get; set; } = default!;

    [Inject] private ICrudService<DivisionCreateDto, DivisionReadDto, DivisionUpdateDto, int> Service { get; set; } = default!;
    [Inject] private ISweetAlertService Swal { get; set; } = default!;
    [Inject] private IBlobStorageService BlobStorage { get; set; } = default!;

    public DivisionCreateDto Model { get; set; } = new();

    private bool _saving;
    private bool _disposed;

    // Manejo de imagen
    private IBrowserFile? _selectedFile;
    private string? _previewDataUrl;      // data:image/*;base64,...
    private bool _deleteExisting;         // marcar eliminación si ya había una imagen guardada

    public void Dispose() => _disposed = true;

    private async Task OnFileSelected(InputFileChangeEventArgs e)
    {
        // Solo 1 archivo
        var file = e.File;
        if (file is null) return;

        // Validaciones básicas
        var permitted = new[] { "image/jpeg", "image/png", "image/webp", "image/gif" };
        if (!permitted.Contains(file.ContentType))
        {
            await Swal.AlertAsync("Archivo no permitido", "Solo se permiten JPG, PNG, WEBP o GIF.", "warning");
            return;
        }

        const long maxBytes = 3 * 1024 * 1024; // 3MB
        if (file.Size > maxBytes)
        {
            await Swal.AlertAsync("Archivo muy grande", "Tamaño máximo: 3 MB.", "warning");
            return;
        }

        _selectedFile = file;
        _deleteExisting = false; // si selecciona una nueva, ya no eliminar manualmente la existente: la reemplazaremos

        // Generar DataURL para previsualización
        using var stream = file.OpenReadStream(maxBytes);
        using var ms = new MemoryStream();
        await stream.CopyToAsync(ms);
        var base64 = Convert.ToBase64String(ms.ToArray());
        _previewDataUrl = $"data:{file.ContentType};base64,{base64}";

        await InvokeAsync(StateHasChanged);
    }

    private async Task RemoveSelectedImage()
    {
        _selectedFile = null;
        _previewDataUrl = null;
        await InvokeAsync(StateHasChanged);
    }

    private async Task RemoveExistingImage()
    {
        // Marcar que se elimine durante el guardado (no lo borres aún por si el guardado falla)
        _deleteExisting = true;
        // Ocultar de la vista
        Model.UrlImg = null;
        Model.ImagenBlobName = null;
        await InvokeAsync(StateHasChanged);
    }

    private async Task SaveAsync()
    {
        if (_saving) return;
        _saving = true;

        if (!_disposed)
        {
            await InvokeAsync(StateHasChanged);
            await Task.Yield();
        }

        bool success = false;
        string? previousBlob = null;

        try
        {
            var user = (await AuthState).User;
            var alias = user.GetEmailLocalPart();
            Model.CreadoPor = string.IsNullOrWhiteSpace(alias) ? "sistema" : alias;

            // 1) Si hay selección nueva -> subir a blob
            if (_selectedFile != null)
            {
                // Si existía una imagen previa, recuerda su blob para borrarlo luego (solo si todo salió bien)
                previousBlob = Model.ImagenBlobName;

                // Subir
                var ext = Path.GetExtension(_selectedFile.Name); // conserva extensión
                var blobName = $"views/division/{DateTime.UtcNow:yyyy/MM/dd}/{CreateSafeRandomName()}{ext}";
                using var stream = _selectedFile.OpenReadStream(3 * 1024 * 1024);
                var ct = _selectedFile.ContentType;

                // Carga al contenedor
                var publicUrl = await BlobStorage.UploadAsync(blobName, stream, ct);

                // Actualiza modelo
                Model.UrlImg = publicUrl;
                Model.ImagenBlobName = blobName;
            }
            else if (_deleteExisting && !string.IsNullOrWhiteSpace(Model.ImagenBlobName))
            {
                // Si marcó eliminar y no se subió nada nuevo: borrar al final si todo ok
                previousBlob = Model.ImagenBlobName;
                Model.UrlImg = null;
                Model.ImagenBlobName = null;
            }

            // 2) Guardar entidad (creación)
            var id = await Service.CreateAsync(Model);
            if (id != 0)
            {
                success = true;

                // 3) Si éxito: eliminar blob anterior (si aplica)
                if (!string.IsNullOrWhiteSpace(previousBlob))
                {
                    try { await BlobStorage.DeleteIfExistsAsync(previousBlob); } catch { /* mejor no romper */ }
                }

                if (!_disposed) { try { await Swal.ToastAsync($"Se ha registrado una nueva División con el ID {id}"); } catch { } }
            }
            else
            {
                if (!_disposed) { try { await Swal.AlertAsync("Error", "No se pudo crear la División.", "error"); } catch { } }
            }
        }
        catch (Exception ex)
        {
            try
            {
                if (!_disposed)
                    await Swal.AlertAsync("Error", ex.Message, "error");
            }
            catch { }
        }
        finally
        {
            _saving = false;
            if (!_disposed)
                await InvokeAsync(StateHasChanged);
        }

        if (success)
        {
            await OnSaved.InvokeAsync();
        }
    }

    private async Task Cancel()
    {
        if (_saving) return;
        await OnCancel.InvokeAsync();
    }

    private static string CreateSafeRandomName()
    {
        // nombre aleatorio URL-safe
        Span<byte> buf = stackalloc byte[16];
        RandomNumberGenerator.Fill(buf);
        return Convert.ToHexString(buf).ToLowerInvariant();
    }
}