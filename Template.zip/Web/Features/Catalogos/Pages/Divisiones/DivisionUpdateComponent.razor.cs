using System.Security.Cryptography;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Forms;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Security;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Divisiones;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Features.Catalogos.Pages.Divisiones;

public partial class DivisionUpdateComponent : ComponentBase
{
    [Parameter] public int Id { get; set; }
    [Parameter] public EventCallback OnSaved { get; set; }
    [Parameter] public EventCallback OnCancel { get; set; }

    [CascadingParameter] private Task<AuthenticationState> AuthState { get; set; } = default!;

    [Inject] private ICrudService<DivisionCreateDto, DivisionReadDto, DivisionUpdateDto, int> Service { get; set; } = default!;
    [Inject] private IBlobStorageService BlobStorage { get; set; } = default!;
    [Inject] private ISweetAlertService Swal { get; set; } = default!;

    public DivisionUpdateDto Model { get; set; } = new();

    private bool _loading;
    private bool _saving;
    private bool _disposed;

    // Imagen
    private IBrowserFile? _selectedFile;
    private string? _previewDataUrl;            // data:image/*;base64,...
    private bool _deleteExisting;               // marcar eliminación de la imagen actual
    private string? _originalUrlImg;            // URL original traída de BD (para conocer qué blob borrar)

    protected override async Task OnParametersSetAsync()
    {
        _loading = true;
        try
        {
            var dto = await Service.GetByIdAsync(Id);
            if (dto is null || dto.Payload is null)
            {
                await Swal.AlertAsync("No encontrado", $"No existe la División #{Id}", "warning");
                await OnCancel.InvokeAsync();
                return;
            }

            // Guarda la URL original (tal cual viene de BD)
            _originalUrlImg = dto.Payload.UrlImg;

            // Opcional: generar SAS temporal para visualizar (sin tocar _originalUrlImg)
            string? sasUrl = null;
            if (!string.IsNullOrWhiteSpace(dto.Payload.UrlImg))
            {
                try
                {
                    // Si tu servicio espera blobName, extrae el nombre; si acepta URL, puede ir directo.
                    // Aquí asumimos que acepta URL completa.
                    sasUrl = await BlobStorage.GetReadOnlySasUrlAsync(dto.Payload.UrlImg!, TimeSpan.FromMinutes(15));
                }
                catch
                {
                    sasUrl = null;
                }
            }

            Model = new DivisionUpdateDto
            {
                DivisionId   = dto.Payload.DivisionId,
                Codigo       = dto.Payload.Codigo,
                Descripcion  = dto.Payload.Descripcion,
                UrlImg       = sasUrl ?? dto.Payload.UrlImg, // muestra SAS si hubo
                Activo       = dto.Payload.Activo,
            };

            _deleteExisting = false;
            _selectedFile = null;
            _previewDataUrl = null;
        }
        catch (Exception ex)
        {
            await Swal.AlertAsync("Error", ex.Message, "error");
            await OnCancel.InvokeAsync();
            return;
        }
        finally
        {
            _loading = false;
            if (!_disposed) await InvokeAsync(StateHasChanged);
        }
    }

    public void Dispose() => _disposed = true;

    private async Task OnFileSelected(InputFileChangeEventArgs e)
    {
        var file = e.File;
        if (file is null) return;

        var permitted = new[] { "image/jpeg", "image/png", "image/webp", "image/gif" };
        if (!permitted.Contains(file.ContentType))
        {
            await Swal.AlertAsync("Archivo no permitido", "Solo se permiten JPG, PNG, WEBP o GIF.", "warning");
            return;
        }

        const long maxBytes = 3 * 1024 * 1024; // 3MB
        if (file.Size > maxBytes)
        {
            await Swal.AlertAsync("Archivo muy grande", "Tamaño máximo: 3 MB.", "warning");
            return;
        }

        _selectedFile = file;
        _deleteExisting = false; // si se selecciona una nueva, no usamos el flag de eliminar: se reemplaza

        using var stream = file.OpenReadStream(maxBytes);
        using var ms = new MemoryStream();
        await stream.CopyToAsync(ms);
        var base64 = Convert.ToBase64String(ms.ToArray());
        _previewDataUrl = $"data:{file.ContentType};base64,{base64}";

        await InvokeAsync(StateHasChanged);
    }

    private async Task RemoveSelectedImage()
    {
        _selectedFile = null;
        _previewDataUrl = null;
        _deleteExisting = false; // vuelve al estado original
        await InvokeAsync(StateHasChanged);
    }

    private async Task RemoveExistingImage()
    {
        // Marca para borrar en el guardado; NO toques _originalUrlImg
        _deleteExisting = true;
        Model.UrlImg = null; // visual (quita de la UI)
        await InvokeAsync(StateHasChanged);
    }

    private async Task SaveAsync()
    {
        if (_saving) return;
        _saving = true;

        if (!_disposed)
        {
            await InvokeAsync(StateHasChanged);
            await Task.Yield();
        }

        // Guardamos qué blob borrar (derivado SIEMPRE de la URL original)
        string? previousBlobToDelete = null;
        if (!string.IsNullOrWhiteSpace(_originalUrlImg) && (_selectedFile != null || _deleteExisting))
        {
            TryGetBlobNameFromUrl(_originalUrlImg, out previousBlobToDelete);
        }

        bool success = false;

        try
        {
            var user = (await AuthState).User;
            var alias = user.GetEmailLocalPart();
            Model.ModificadoPor = string.IsNullOrWhiteSpace(alias) ? "sistema" : alias;

            // 1) Subida de nueva imagen (reemplazo)
            if (_selectedFile != null)
            {
                var ext = EnsureImageExtension(_selectedFile.Name, _selectedFile.ContentType);
                var blobName = $"views/division/{DateTime.UtcNow:yyyy/MM/dd}/{CreateSafeRandomName()}{ext}";
                using var upload = _selectedFile.OpenReadStream(3 * 1024 * 1024);
                var contentType = _selectedFile.ContentType;

                var publicUrl = await BlobStorage.UploadAsync(blobName, upload, contentType);
                Model.UrlImg = publicUrl; // Usa la URL pública/permanente para persistir
            }
            // 2) Eliminar existente sin subir nueva
            else if (_deleteExisting)
            {
                Model.UrlImg = null;
            }
            // 3) Caso sin cambios de imagen: Model.UrlImg queda como está (SAS o pública).
            //    Si guardaste SAS en Model.UrlImg solo para mostrar, considera mapearla
            //    de vuelta a URL pública al persistir (si tu backend espera pública).

            // Actualiza en API
            var updated = await Service.UpdateAsync(Id, Model);
            success = updated;

            if (success)
            {
                // Si hubo nueva imagen o eliminaste la existente, intenta borrar el blob anterior
                if (!string.IsNullOrWhiteSpace(previousBlobToDelete))
                {
                    try
                    {
                        await BlobStorage.DeleteIfExistsAsync(previousBlobToDelete);
                    }
                    catch
                    {
                        // No bloquear UX por fallas en limpieza
                    }
                }

                try
                {
                    await Swal.ToastAsync($"Registro #{Model.DivisionId} actualizado");
                }
                catch { /* noop */ }
            }
            else
            {
                await Swal.AlertAsync("Error", "No se pudo actualizar el registro.", "error");
            }
        }
        catch (Exception ex)
        {
            try { await Swal.AlertAsync("Error", ex.Message, "error"); } catch { }
        }
        finally
        {
            _saving = false;
            if (!_disposed) await InvokeAsync(StateHasChanged);
        }

        if (success)
            await OnSaved.InvokeAsync();
    }

    private async Task Cancel()
    {
        if (_saving) return;
        await OnCancel.InvokeAsync();
    }

    // ===================== Helpers =====================

    private static string EnsureImageExtension(string fileName, string contentType)
    {
        var ext = Path.GetExtension(fileName);
        if (!string.IsNullOrWhiteSpace(ext)) return ext;

        return contentType switch
        {
            "image/jpeg" => ".jpg",
            "image/png"  => ".png",
            "image/webp" => ".webp",
            "image/gif"  => ".gif",
            _            => ".bin"
        };
    }

    private static string CreateSafeRandomName()
    {
        Span<byte> buf = stackalloc byte[16];
        RandomNumberGenerator.Fill(buf);
        return Convert.ToHexString(buf).ToLowerInvariant();
    }

    /// <summary>
    /// Acepta URL absoluta con container (/container/path/file.ext[?sas]),
    /// y devuelve el blobName como "path/file.ext" (sin el nombre del contenedor).
    /// </summary>
    private static bool TryGetBlobNameFromUrl(string? url, out string? blobName)
    {
        blobName = null;
        if (string.IsNullOrWhiteSpace(url)) return false;
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri)) return false;

        // /container/f1/f2/file.ext
        var path = uri.AbsolutePath.TrimStart('/');
        var idx = path.IndexOf('/');
        if (idx < 0 || idx == path.Length - 1) return false;

        var raw = path[(idx + 1)..]; // quita '<container>/'
        blobName = Uri.UnescapeDataString(raw);
        return true;
    }
}