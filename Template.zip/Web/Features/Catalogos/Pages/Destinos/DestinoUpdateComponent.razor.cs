using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Security;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Destinos;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Features.Catalogos.Pages.Destinos;

public partial class DestinoUpdateComponent : ComponentBase
{
    [Parameter] public int Id { get; set; }

    [Parameter] public EventCallback OnSaved { get; set; }
    [Parameter] public EventCallback OnCancel { get; set; }

    [CascadingParameter] private Task<AuthenticationState> AuthState { get; set; } = default!;

    [Inject] private ICrudService<DestinoCreateDto, DestinoReadDto, DestinoUpdateDto, int> Service { get; set; } = default!;
    [Inject] private ISweetAlertService Swal { get; set; } = default!;

    public DestinoUpdateDto Model { get; set; } = new();

    protected bool _loading;
    protected bool _saving;
    private bool _disposed;

    public void Dispose() => _disposed = true;

    protected override async Task OnParametersSetAsync()
    {
        await LoadAsync();
    }

    private async Task LoadAsync(CancellationToken ct = default)
    {
        _loading = true;
        if (!_disposed) { await InvokeAsync(StateHasChanged); await Task.Yield(); }

        try
        {
            var resp = await Service.GetByIdAsync(Id, ct);
            if (resp?.Payload is null || resp.StatusCode == 404)
            {
                // No encontrado → avisa y cierra
                if (!_disposed) { try { await Swal.AlertAsync("No encontrado", "El Destino no existe.", "warning"); } catch { } }
                await OnCancel.InvokeAsync();
                return;
            }

            // Map DestinoReadDto -> DestinoUpdateDto
            Model = MapFrom(resp.Payload);
        }
        catch (Exception ex)
        {
            if (!_disposed) { try { await Swal.AlertAsync("Error", ex.Message, "error"); } catch { } }
            await OnCancel.InvokeAsync();
        }
        finally
        {
            _loading = false;
            if (!_disposed) await InvokeAsync(StateHasChanged);
        }
    }

    private static DestinoUpdateDto MapFrom(DestinoReadDto src)
        => new()
        {
            Descripcion   = src.Descripcion?.Trim(),
            Activo        = src.Activo,
            // ModificadoPor se coloca al guardar con el usuario actual
            ModificadoPor = null
        };

    protected async Task SaveAsync()
    {
        if (_saving || _loading) return;
        _saving = true;

        if (!_disposed)
        {
            await InvokeAsync(StateHasChanged); // muestra spinner
            await Task.Yield();
        }

        bool success = false;

        try
        {
            var user  = (await AuthState).User;
            var alias = user.GetEmailLocalPart(); // parte antes de '@'
            Model.ModificadoPor = string.IsNullOrWhiteSpace(alias) ? "sistema" : alias;

            var ok = await Service.UpdateAsync(Id, Model);
            if (ok)
            {
                success = true;
                if (!_disposed) { try { await Swal.ToastAsync("Cambios guardados"); } catch { } }
            }
            else
            {
                if (!_disposed) { try { await Swal.AlertAsync("No guardado", "No se pudo actualizar el Destino.", "error"); } catch { } }
            }
        }
        catch (Exception ex)
        {
            if (!_disposed) { try { await Swal.AlertAsync("Error", ex.Message, "error"); } catch { } }
        }
        finally
        {
            _saving = false;
            if (!_disposed) await InvokeAsync(StateHasChanged);
        }

        if (success)
        {
            await OnSaved.InvokeAsync(); // el padre suele cerrar el modal aquí
        }
    }

    protected async Task Cancel()
    {
        if (_saving || _loading) return;
        await OnCancel.InvokeAsync();
    }
}