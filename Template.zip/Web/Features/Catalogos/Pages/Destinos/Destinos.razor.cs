using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Response;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Destinos;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Features.Catalogos.Pages.Destinos;

public partial class Destinos : ComponentBase
{
    [Inject] ICrudService<DestinoCreateDto, DestinoReadDto, DestinoUpdateDto, int> Service { get; set; } = default!;
    [Inject] ISweetAlertService Swal { get; set; } = default!;

    protected BaseResponseModel<PagedResult<DestinoReadDto>>? ItemsLst;
    protected bool _loading;
    protected int _currentPage = 1, _pageSize = 10, _totalPages = 1, _totalCount = 0;
    protected string _sortBy = "DestinoId", _sortDir = "ASC";
    private string _searchTerm = string.Empty;

    // Manejo de imagenes
    private bool _showImage;
    private string? _lightboxUrl;
    private string _lightboxCaption = "Imagen";

    // Modales / acciones
    protected bool _showCreate, _showEdit, _showAudit;
    protected int? _editId;
    protected AuditDto? _audit;

    protected override async Task OnInitializedAsync() => await LoadDataAsync();

    protected async Task LoadDataAsync()
    {
        _loading = true;
        StateHasChanged();

        try
        {
            var filter = new PageFilter
            {
                Page = _currentPage,
                PageSize = _pageSize,
                SortBy = _sortBy,
                SortDir = _sortDir,
                Search = _searchTerm,
            };

            var resp = await Service.GetPagedAsync(filter);
            var payload = resp?.Payload; // PagedResult<DestinoReadDto> esperado

            // Si no hay payload, resetea seguro y sal
            if (payload is null)
            {
                ItemsLst = null;
                _totalCount = 0;
                _totalPages = 1;
                return;
            }

            // Asigna ItemsLst una sola vez (lo usas en el .razor)
            ItemsLst = new BaseResponseModel<PagedResult<DestinoReadDto>>
            {
                Payload = payload
            };

            // Toma números del payload (preferentes) y calcula faltantes
            _totalCount = payload.TotalCount;
            _pageSize = payload.PageSize > 0 ? payload.PageSize : _pageSize;

            // Algunas APIs usan Page, otras CurrentPage…
            var pageFromApi = payload.Page > 0 ? payload.Page : (payload.Page > 0 ? payload.Page : _currentPage);
            _currentPage = pageFromApi;

            _totalPages = payload.TotalPages > 0
                ? payload.TotalPages
                : Math.Max(1, (int)Math.Ceiling((_totalCount * 1.0) / Math.Max(1, _pageSize)));

            // Ajusta página actual a rango [1, _totalPages]
            if (_currentPage < 1) _currentPage = 1;
            if (_currentPage > _totalPages) _currentPage = _totalPages;
        }
        catch (Exception ex)
        {
            try
            {
                await Swal.ToastAsync($"Error al cargar: {ex.Message}", "error");
            }
            catch
            {
            }
        }
        finally
        {
            _loading = false;
            StateHasChanged();
        }
    }


    // Toolbar
    protected void NewRecord() => _showCreate = true;

    protected async Task Search()
    {
        _currentPage = 1;
        await LoadDataAsync();
    }

    protected async Task ClearSearch()
    {
        _searchTerm = string.Empty;
        _currentPage = 1;
        await LoadDataAsync();
    }

    // Sort
    protected async Task SortByColumn(string col)
    {
        if (_sortBy.Equals(col, StringComparison.OrdinalIgnoreCase))
            _sortDir = _sortDir.Equals("ASC", StringComparison.OrdinalIgnoreCase) ? "DESC" : "ASC";
        else
        {
            _sortBy = col;
            _sortDir = "ASC";
        }

        _currentPage = 1;
        await LoadDataAsync();
    }

    protected MarkupString SortByColumnIndicator(string col)
    {
        var isCurrent = _sortBy.Equals(col, StringComparison.OrdinalIgnoreCase);
        var arrow = isCurrent ? (_sortDir == "ASC" ? "▲" : "▼") : "◇";
        return (MarkupString)$"<span class='ms-1 text-white'>{arrow}</span>";
    }

    // Paginación
    protected async Task ChangePage(int p)
    {
        if (p < 1 || p > _totalPages) return;
        _currentPage = p;
        await LoadDataAsync();
    }

    protected async Task OnPageSizeChanged(int size)
    {
        _pageSize = size;
        _currentPage = 1;
        await LoadDataAsync();
    }

    // Acciones
    protected void ShowAudit(DestinoReadDto item)
    {
        _audit = MapAudit(item);
        _showAudit = true;
    }

    protected void CloseAudit() => _showAudit = false;
    protected void CloseCreate() => _showCreate = false;

    protected void CloseEdit()
    {
        _showEdit = false;
        _editId = null;
    }

    protected void EditRecord(int id)
    {
        _editId = id;
        _showEdit = true;
    }

    private async Task DeleteRecord(int id, CancellationToken ct = default)
    {
        if (await Swal.ConfirmAsync($"Eliminar registro No. {id}", "Esta acción no se puede deshacer"))
        {
            _loading = true;
            await InvokeAsync(StateHasChanged); // pinta el overlay
            await Task.Yield(); 
            
            var result = await Service.DeleteAsync(id);
            if (result)
            {
                await Swal.AlertAsync("Eliminado", "El registro fue eliminado", "success");
                await LoadDataAsync();
            }
            else
            {
                await Swal.AlertAsync("Eliminado", "El registro fue eliminado", "error");
                await LoadDataAsync();
            }
        }
        else
        {
            await Swal.ToastAsync("Acción cancelada", "info");
        }
    }

    protected async Task HandleCreateSaved()
    {
        _showCreate = false;
        await LoadDataAsync();
    }

    protected async Task HandleEditSaved()
    {
        _showEdit = false;
        await LoadDataAsync();
    }

    private static AuditDto MapAudit(DestinoReadDto r) => new()
    {
        CreadoPor = r.CreadoPor, FechaCreacion = r.FechaCreacion,
        ModificadoPor = r.ModificadoPor, FechaModificacion = r.FechaModificacion,
    };

    // Manejo de miniatura de imagenes y modal para mostrarla
    private void OpenLightbox(string? url, string? caption)
    {
        if (string.IsNullOrWhiteSpace(url)) return;
        _lightboxUrl = url;
        _lightboxCaption = string.IsNullOrWhiteSpace(caption) ? "Imagen" : caption.Trim();
        _showImage = true;
        StateHasChanged();
    }

    private void CloseLightbox()
    {
        _showImage = false;
        _lightboxUrl = null;
        _lightboxCaption = "Imagen";
        StateHasChanged();
    }

    private void OnLightboxKeyDown(KeyboardEventArgs e)
    {
        if (e.Key == "Escape") CloseLightbox();
    }
}