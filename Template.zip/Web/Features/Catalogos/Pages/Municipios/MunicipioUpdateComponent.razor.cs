using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Response;
using Xignux.Juridico.Inmuebles.Web.Common.Security;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Estados;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Municipios;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Paises;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Features.Catalogos.Pages.Municipios;

public partial class MunicipioUpdateComponent : ComponentBase
{
    [Parameter] public int Id { get; set; }
    [Parameter] public EventCallback OnSaved { get; set; }
    [Parameter] public EventCallback OnCancel { get; set; }
    [CascadingParameter] private Task<AuthenticationState> AuthState { get; set; } = default!;
    [Inject] private ICrudService<MunicipioCreateDto, MunicipioReadDto, MunicipioUpdateDto, int> Service { get; set; } = default!;
    [Inject] private ICrudService<EstadoCreateDto, EstadoReadDto, EstadoUpdateDto, int> ServiceEstado { get; set; } = default!;
    [Inject] private ICrudService<PaisCreateDto, PaisReadDto, PaisUpdateDto, int> ServicePais { get; set; } = default!;
    
    [Inject] private ISweetAlertService Swal { get; set; } = default!;
    
    protected PageFilter Filter { get; set; } = new();

    public MunicipioUpdateDto Model { get; set; } = new();

    protected bool _loading;
    protected bool _saving;
    private bool _disposed;
    private List<EstadoReadDto> _estados = new();
    private List<PaisReadDto> _paises = new();
    
    private MunicipioReadDto? _read;
    
    public void Dispose() => _disposed = true;
    
    protected override async Task OnParametersSetAsync()
    {
        await LoadDataAsync();
        await CargarPaisesAsync();
        await CargarEstadosAsync();
        AsegurarPaisActualEnLista();
        AsegurarEstadoActualEnLista();
        if (!_disposed) StateHasChanged();
    }
    
    private async Task LoadDataAsync(CancellationToken ct = default)
    {
        _loading = true;
        if (!_disposed) { await InvokeAsync(StateHasChanged); await Task.Yield(); }

        try
        {
            var resp = await Service.GetByIdAsync(Id, ct);
            if (resp?.Payload is null || resp.StatusCode == 404)
            {
                if (!_disposed) { try { await Swal.AlertAsync("No encontrado", "El Estado no existe.", "warning"); } catch { } }
                await OnCancel.InvokeAsync();
                return;
            }

            _read = resp.Payload;
            Model = MapFrom(_read);
        }
        catch (Exception ex)
        {
            if (!_disposed) { try { await Swal.AlertAsync("Error", ex.Message, "error"); } catch { } }
            await OnCancel.InvokeAsync();
        }
        finally
        {
            _loading = false;
            if (!_disposed) await InvokeAsync(StateHasChanged);
        }
    }
    
    private async Task CargarPaisesAsync()
    {
        try
        {
            Filter = new PageFilter
            {
                Page = 1,
                PageSize = 500,
                SortBy = "PaisId",
                SortDir = "ASC",
                Search = string.Empty,
                ColumnFilters = new Dictionary<string, string>
                {
                    ["Activo"] = "true"   // <-- así se agrega un par clave/valor
                }
            };

            var paged = await ServicePais.GetPagedAsync(Filter);

            _paises = paged?.Payload?.Items?.ToList() ?? new List<PaisReadDto>();

            if (Model.PaisId == 0 && _paises.Count == 1)
                Model.PaisId = _paises[0].PaisId;
        }
        catch (Exception ex)
        {
            try { if (!_disposed) await Swal.ToastAsync($"No fue posible cargar países: {ex.Message}", "warning"); } catch { }
        }
    }

    private async Task CargarEstadosAsync()
    {
        try
        {
            Filter = new PageFilter
            {
                Page = 1,
                PageSize = 500,
                SortBy = "EstadoId",
                SortDir = "ASC",
                Search = string.Empty,
                ColumnFilters = new Dictionary<string, string>
                {
                    ["Activo"] = "true"   // <-- así se agrega un par clave/valor
                }
            };

            var paged = await ServiceEstado.GetPagedAsync(Filter);

            _estados = paged?.Payload?.Items?.ToList() ?? new List<EstadoReadDto>();

            if (Model.EstadoId == 0 && _estados.Count == 1)
                Model.EstadoId = _estados[0].EstadoId;
        }
        catch (Exception ex)
        {
            try { if (!_disposed) await Swal.ToastAsync($"No fue posible cargar estados: {ex.Message}", "warning"); } catch { }
        }
    }
    
    private void AsegurarPaisActualEnLista()
    {
        if (Model?.PaisId > 0 && !_paises.Any(x => x.PaisId == Model.PaisId))
        {
            // Intentamos obtener nombre desde el read, si lo tenemos
            var nombre = _read?.PaisNombre;
            // Agrega una opción sintética para que el select pueda marcarlo
            _paises.Insert(0, new PaisReadDto
            {
                PaisId = Model.PaisId,
                Descripcion = string.IsNullOrWhiteSpace(nombre) ? $"País #{Model.PaisId}" : nombre!.Trim(),
                Activo = true
            });
        }
    }
    
    private void AsegurarEstadoActualEnLista()
    {
        if (Model?.EstadoId > 0 && !_estados.Any(x => x.EstadoId == Model.EstadoId))
        {
            // Intentamos obtener nombre desde el read, si lo tenemos
            var nombre = _read?.EstadoNombre;
            // Agrega una opción sintética para que el select pueda marcarlo
            _estados.Insert(0, new EstadoReadDto
            {
                EstadoId = Model.EstadoId,
                Descripcion = string.IsNullOrWhiteSpace(nombre) ? $"Estado #{Model.EstadoId}" : nombre!.Trim(),
                Activo = true
            });
        }
    }

    private static MunicipioUpdateDto MapFrom(MunicipioReadDto src)
        => new()
        {
            // Asegúrate de que tu UpdateDto tenga estas propiedades
            // (ajusta nombres si difieren)
            PaisId       = src.PaisId,
            EstadoId     = src.EstadoId, 
            Descripcion  = src.Descripcion?.Trim(),
            Activo       = src.Activo,
            // ModificadoPor se setea al guardar
        };

    protected async Task SaveAsync()
    {
        if (_saving || _loading) return;
        _saving = true;

        if (!_disposed)
        {
            await InvokeAsync(StateHasChanged);
            await Task.Yield();
        }

        var success = false;

        try
        {
            if (Model.PaisId == 0)
                throw new InvalidOperationException("Selecciona un país.");

            var user  = (await AuthState).User;
            var alias = user.GetEmailLocalPart();
            Model.ModificadoPor = string.IsNullOrWhiteSpace(alias) ? "sistema" : alias;

            var ok = await Service.UpdateAsync(Id, Model);
            success = ok;

            if (success)
            {
                if (!_disposed) { try { await Swal.ToastAsync("Cambios guardados"); } catch { } }
            }
            else
            {
                if (!_disposed) { try { await Swal.AlertAsync("No guardado", "No se pudo actualizar el Estado.", "error"); } catch { } }
            }
        }
        catch (Exception ex)
        {
            if (!_disposed) { try { await Swal.AlertAsync("Error", ex.Message, "error"); } catch { } }
        }
        finally
        {
            _saving = false;
            if (!_disposed) await InvokeAsync(StateHasChanged);
        }

        if (success)
            await OnSaved.InvokeAsync();
    }

    protected async Task Cancel()
    {
        if (_saving || _loading) return;
        await OnCancel.InvokeAsync();
    }
}