using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Response;
using Xignux.Juridico.Inmuebles.Web.Common.Security;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Estados;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Paises;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Features.Catalogos.Pages.Estados;

public partial class EstadoUpdateComponent : ComponentBase
{
    [Parameter] public int Id { get; set; }
    [Parameter] public EventCallback OnSaved { get; set; }
    [Parameter] public EventCallback OnCancel { get; set; }

    [CascadingParameter] private Task<AuthenticationState> AuthState { get; set; } = default!;

    [Inject] private ICrudService<EstadoCreateDto, EstadoReadDto, EstadoUpdateDto, int> Service { get; set; } = default!;
    [Inject] private ICrudService<PaisCreateDto, PaisReadDto, PaisUpdateDto, int> ServicePais { get; set; } = default!;
    [Inject] private ISweetAlertService Swal { get; set; } = default!;

    protected PageFilter Filter { get; set; } = new();

    public EstadoUpdateDto Model { get; set; } = new();

    protected bool _loading;
    protected bool _saving;
    private bool _disposed;
    private List<PaisReadDto> _paises = new();

    // guardamos el read para tener PaisId/PaisNombre si hace falta
    private EstadoReadDto? _read;

    public void Dispose() => _disposed = true;

    protected override async Task OnParametersSetAsync()
    {
        await LoadDataAsync();           // 1) carga el registro
        await CargarPaisesAsync();   // 2) carga países
        // 3) garantiza que el país del registro esté en la lista
        AsegurarPaisActualEnLista();
        if (!_disposed) StateHasChanged();
    }

    private async Task LoadDataAsync(CancellationToken ct = default)
    {
        _loading = true;
        if (!_disposed) { await InvokeAsync(StateHasChanged); await Task.Yield(); }

        try
        {
            var resp = await Service.GetByIdAsync(Id, ct);
            if (resp?.Payload is null || resp.StatusCode == 404)
            {
                if (!_disposed) { try { await Swal.AlertAsync("No encontrado", "El Estado no existe.", "warning"); } catch { } }
                await OnCancel.InvokeAsync();
                return;
            }

            _read = resp.Payload;
            Model = MapFrom(_read);   // <-- ahora incluye PaisId y Codigo
        }
        catch (Exception ex)
        {
            if (!_disposed) { try { await Swal.AlertAsync("Error", ex.Message, "error"); } catch { } }
            await OnCancel.InvokeAsync();
        }
        finally
        {
            _loading = false;
            if (!_disposed) await InvokeAsync(StateHasChanged);
        }
    }

    private async Task CargarPaisesAsync()
    {
        try
        {
            Filter = new PageFilter
            {
                Page = 1,
                PageSize = 500,
                SortBy = "PaisId",
                SortDir = "ASC",
                Search = string.Empty,
                ColumnFilters = new Dictionary<string, string>
                {
                    ["Activo"] = "true"
                }
            };

            var paged = await ServicePais.GetPagedAsync(Filter);
            _paises = paged?.Payload?.Items?.ToList() ?? new List<PaisReadDto>();
        }
        catch (Exception ex)
        {
            try { if (!_disposed) await Swal.ToastAsync($"No fue posible cargar países: {ex.Message}", "warning"); } catch { }
        }
    }

    private void AsegurarPaisActualEnLista()
    {
        if (Model?.PaisId > 0 && !_paises.Any(x => x.PaisId == Model.PaisId))
        {
            // Intentamos obtener nombre desde el read, si lo tenemos
            var nombre = _read?.PaisNombre;
            // Agrega una opción sintética para que el select pueda marcarlo
            _paises.Insert(0, new PaisReadDto
            {
                PaisId = Model.PaisId,
                Descripcion = string.IsNullOrWhiteSpace(nombre) ? $"País #{Model.PaisId}" : nombre!.Trim(),
                Activo = true
            });
        }
    }

    private static EstadoUpdateDto MapFrom(EstadoReadDto src)
        => new()
        {
            // Asegúrate de que tu UpdateDto tenga estas propiedades
            // (ajusta nombres si difieren)
            PaisId       = src.PaisId,                 // <-- clave para que el select lo marque
            Codigo       = src.Codigo?.Trim(),         // si editas código
            Descripcion  = src.Descripcion?.Trim(),
            Activo       = src.Activo,
            // ModificadoPor se setea al guardar
        };

    protected async Task SaveAsync()
    {
        if (_saving || _loading) return;
        _saving = true;

        if (!_disposed)
        {
            await InvokeAsync(StateHasChanged);
            await Task.Yield();
        }

        var success = false;

        try
        {
            if (Model.PaisId == 0)
                throw new InvalidOperationException("Selecciona un país.");

            var user  = (await AuthState).User;
            var alias = user.GetEmailLocalPart();
            Model.ModificadoPor = string.IsNullOrWhiteSpace(alias) ? "sistema" : alias;

            var ok = await Service.UpdateAsync(Id, Model);
            success = ok;

            if (success)
            {
                if (!_disposed) { try { await Swal.ToastAsync("Cambios guardados"); } catch { } }
            }
            else
            {
                if (!_disposed) { try { await Swal.AlertAsync("No guardado", "No se pudo actualizar el Estado.", "error"); } catch { } }
            }
        }
        catch (Exception ex)
        {
            if (!_disposed) { try { await Swal.AlertAsync("Error", ex.Message, "error"); } catch { } }
        }
        finally
        {
            _saving = false;
            if (!_disposed) await InvokeAsync(StateHasChanged);
        }

        if (success)
            await OnSaved.InvokeAsync();
    }

    protected async Task Cancel()
    {
        if (_saving || _loading) return;
        await OnCancel.InvokeAsync();
    }
}
