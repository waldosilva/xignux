using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Security;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.GiroDeActividades;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Features.Catalogos.Pages.GiroDeActividades;

public partial class GiroActividadCreateComponent : ComponentBase
{
    [Parameter] public EventCallback OnSaved { get; set; }
    [Parameter] public EventCallback OnCancel { get; set; }
    [CascadingParameter] private Task<AuthenticationState> AuthState { get; set; } = default!;

    [Inject]
    private ICrudService<GiroActividadCreateDto, GiroActividadReadDto, GiroActividadUpdateDto, int> Service { get; set; } = default!;
    private ISweetAlertService Swal { get; set; } = default!;

    public GiroActividadCreateDto Model { get; set; } = new();

    private bool _saving;
    private bool _disposed;
    
    public void Dispose() => _disposed = true;

    private async Task SaveAsync()
    {
        if (_saving) return;
        _saving = true;

        if (!_disposed)
        {
            await InvokeAsync(StateHasChanged); // pinta el estado de “guardando”
            await Task.Yield();                  // cede turno para que se renderice
        }

        bool success = false;
        
        try
        {
            var user = (await AuthState).User;
            var alias = user.GetEmailLocalPart(); // parte antes de '@'
            Model.CreadoPor = string.IsNullOrWhiteSpace(alias) ? "sistema" : alias;

            var id = await Service.CreateAsync(Model);

            if (id != 0)
            {
                success = true;
                // muestra toast de éxito
                if (!_disposed) { try { await Swal.ToastAsync($"Se ha registrado una nueva GiroActividad con el ID {id}"); } catch { } }
            }
            else
            {
                // error de negocio
                if (!_disposed) { try { await Swal.AlertAsync("Error", "No se pudo crear la GiroActividad.", "error"); } catch { } }
            }
        }
        catch (Exception ex)
        {
            try
            {
                if (!_disposed)
                    await Swal.AlertAsync("Error", ex.Message, "error");
            }
            catch { /* evita romper el circuito por interop */ }
        }
        finally
        {
            _saving = false;

            // MUY IMPORTANTE: re-renderizar SOLO si el componente sigue montado.
            if (!_disposed)
                await InvokeAsync(StateHasChanged);
        }

        // Dispara el evento al padre DESPUÉS de apagar _saving y renderizar.
        // El padre seguramente cerrará el modal y dispondrá este componente.
        if (success)
        {
            await OnSaved.InvokeAsync(); // no hagas más UI después de esto
        }
    }

    private async Task Cancel()
    {
        if (_saving) return;
        await OnCancel.InvokeAsync();
    }
}