using Microsoft.AspNetCore.Components;

namespace Xignux.Juridico.Inmuebles.Web.Features.Inmuebles.Pages;

public partial class Inmuebles : ComponentBase
{
}