using Microsoft.AspNetCore.Components;

namespace Xignux.Juridico.Inmuebles.Web.Features.Documentos.Pages;

public partial class Documentos : ComponentBase
{
}