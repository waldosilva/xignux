using Microsoft.AspNetCore.Components;

namespace Xignux.Juridico.Inmuebles.Web.Features.Reportes.Pages;

public partial class Reportes : ComponentBase
{
}