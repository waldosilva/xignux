using System.Net.Http.Headers;
using Microsoft.Identity.Web;

namespace Xignux.Juridico.Inmuebles.Web.Common.Security;

/// <summary>
/// Agrega:
/// - Authorization: Bearer {access_token de Entra ID}
/// - Ocp-Apim-Subscription-Key (si está configurada)
/// </summary>
public sealed class ApiAuthHandler : DelegatingHandler
{
    private readonly ITokenAcquisition _tokens;
    private readonly IHttpContextAccessor _httpCtx;
    private readonly IConfiguration _cfg;

    public ApiAuthHandler(ITokenAcquisition tokens, IHttpContextAccessor httpCtx, IConfiguration cfg)
    {
        _tokens = tokens;
        _httpCtx = httpCtx;
        _cfg = cfg;
    }

    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
    {
        // Scopes: DownstreamApi:Scopes o AzureAd:ApiScope (fallback)
        var scopes = _cfg.GetSection("DownstreamApi:Scopes").Get<string[]>();
        if (scopes == null || scopes.Length == 0)
        {
            var scope = _cfg["AzureAd:ApiScope"];
            if (!string.IsNullOrWhiteSpace(scope)) scopes = new[] { scope };
        }

        var user = _httpCtx.HttpContext?.User;
        var accessToken = await _tokens.GetAccessTokenForUserAsync(scopes!, user: user);

        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

        var apimKey = _cfg["Apim:SubscriptionKey"];
        if (!string.IsNullOrWhiteSpace(apimKey))
            request.Headers.TryAddWithoutValidation("Ocp-Apim-Subscription-Key", apimKey);

        return await base.SendAsync(request, ct);
    }
}