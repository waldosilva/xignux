using System.IdentityModel.Tokens.Jwt;
using System.Net.Http.Headers;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Identity.Web;

namespace Xignux.Juridico.Inmuebles.Web.Common.Security;

public static class ClaimsPrincipalExtensions
{
    public static bool IsAuthenticated(this ClaimsPrincipal? user)
        => user?.Identity?.IsAuthenticated == true;

    public static string GetFullName(this ClaimsPrincipal? user)
    {
        if (!user.IsAuthenticated()) return string.Empty;

        // 1) Nombre “amigable”
        var full = First(user!, "name", "displayName");
        if (!string.IsNullOrWhiteSpace(full)) return full!;

        // 2) Composición GivenName + Surname
        var given  = First(user!, ClaimTypes.GivenName, "given_name");
        var family = First(user!, ClaimTypes.Surname,   "family_name");
        var composed = $"{given} {family}".Trim();
        if (!string.IsNullOrWhiteSpace(composed)) return composed;

        // 3) Fallbacks
        var alt = First(user!, "preferred_username", ClaimTypes.Upn, ClaimTypes.Email, "emails");
        return alt ?? user!.Identity!.Name ?? string.Empty;
    }

    public static string GetEmailLocalPart(this ClaimsPrincipal? user)
    {
        if (!user.IsAuthenticated()) return string.Empty;

        var candidate = First(user!,
            ClaimTypes.Email, "emails",
            "preferred_username", ClaimTypes.Upn, "upn",
            ClaimTypes.Name);

        return ExtractLocalPart(candidate) ?? string.Empty;
    }

    /// <summary>
    /// Devuelve el nombre a usar en auditoría.
    /// preferFullName=true → usa nombre completo si existe; si no, alias del correo.
    /// preferFullName=false → prioriza alias; si no, nombre completo.
    /// </summary>
    public static string GetAuditName(this ClaimsPrincipal? user, bool preferFullName = true, string fallback = "sistema")
    {
        if (!user.IsAuthenticated()) return fallback;

        var full  = user!.GetFullName();
        var alias = user!.GetEmailLocalPart();

        var chosen = preferFullName
            ? (string.IsNullOrWhiteSpace(full)  ? alias : full)
            : (string.IsNullOrWhiteSpace(alias) ? full  : alias);

        return string.IsNullOrWhiteSpace(chosen)
            ? (user!.Identity!.Name ?? fallback)
            : chosen!;
    }

    // Helpers
    private static string? First(ClaimsPrincipal user, params string[] types)
    {
        foreach (var t in types)
        {
            var v = user.FindFirst(t)?.Value;
            if (!string.IsNullOrWhiteSpace(v)) return v;
        }
        return null;
    }

    private static string? ExtractLocalPart(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        foreach (var token in value.Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries))
        {
            var s = token.Trim().Trim('"', '\'');
            var at = s.IndexOf('@');
            if (at > 0) return s[..at];
        }
        return null;
    }
    
    /// <summary>
    /// Obtiene el access token de Entra ID usando ITokenAcquisition (recomendado).
    /// Resuelve los scopes desde DownstreamApi:Scopes o AzureAd:ApiScope.
    /// </summary>
    public static async Task<string?> GetAccessTokenAsync(
        this ClaimsPrincipal? user,
        IHttpContextAccessor http,
        ITokenAcquisition tokens,
        IConfiguration cfg)
    {
        if (user?.Identity?.IsAuthenticated != true) return null;

        // 1) Scopes desde config
        var scopes = cfg.GetSection("DownstreamApi:Scopes").Get<string[]>();
        if (scopes == null || scopes.Length == 0)
        {
            var scope = cfg["AzureAd:ApiScope"];
            if (!string.IsNullOrWhiteSpace(scope)) scopes = new[] { scope };
        }
        if (scopes == null || scopes.Length == 0) return null;

        // 2) Access token para el usuario actual
        return await tokens.GetAccessTokenForUserAsync(scopes, user: user);
    }

    /// <summary>
    /// Obtiene tokens crudos del contexto (requiere OpenIdConnectOptions.SaveTokens = true).
    /// </summary>
    public static async Task<(string? IdToken, string? AccessToken)> GetRawTokensAsync(
        this ClaimsPrincipal? user,
        IHttpContextAccessor http)
    {
        var ctx = http.HttpContext;
        if (ctx == null || user?.Identity?.IsAuthenticated != true) return (null, null);

        var idt = await ctx.GetTokenAsync("id_token");
        var at  = await ctx.GetTokenAsync("access_token");
        return (idt, at);
    }

    /// <summary>
    /// Decodifica un JWT (sin validar firmas) para inspeccionar claims.
    /// </summary>
    public static JwtSecurityToken? DecodeJwt(this string? token)
    {
        if (string.IsNullOrWhiteSpace(token)) return null;
        var handler = new JwtSecurityTokenHandler();
        return handler.ReadJwtToken(token);
    }

    /// <summary>
    /// Adjunta el Bearer token (y opcionalmente la subscription key de APIM) al request.
    /// Usa ITokenAcquisition para obtener el access token.
    /// </summary>
    public static async Task AttachAuthHeadersAsync(
        this ClaimsPrincipal? user,
        HttpRequestMessage request,
        IHttpContextAccessor http,
        ITokenAcquisition tokens,
        IConfiguration cfg)
    {
        var accessToken = await user.GetAccessTokenAsync(http, tokens, cfg);
        if (!string.IsNullOrWhiteSpace(accessToken))
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

        var apimKey = cfg["Apim:SubscriptionKey"];
        if (!string.IsNullOrWhiteSpace(apimKey))
            request.Headers.TryAddWithoutValidation("Ocp-Apim-Subscription-Key", apimKey);
    }
}