using Azure.Storage;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Sas;
using Microsoft.Extensions.Options;
using Xignux.Juridico.Inmuebles.Web.Services;

namespace Xignux.Juridico.Inmuebles.Web.Common.BlodStorage;

public sealed class AzureBlobStorageService : IBlobStorageService
{
    private readonly BlobServiceClient _blobServiceClient;
    private readonly string _accountKey;

    public AzureBlobStorageService(IOptions<BlobOptions> options)
    {
        var blobOptions = options.Value;
        _blobServiceClient = new BlobServiceClient(blobOptions.ConnectionString);
        _accountKey = blobOptions.AccountKey;
    }

    // blobKey: clave COMPLETA dentro del contenedor, ej. "views/2025/09/18/abcdef.jpg"
    public async Task<string> UploadAsync(string blobKey, Stream data, string contentType, CancellationToken ct = default)
    {
        var containerClient = _blobServiceClient.GetBlobContainerClient("img");
        var blobClient = containerClient.GetBlobClient(blobKey);

        await blobClient.UploadAsync(
            data,
            new BlobHttpHeaders { ContentType = contentType },
            cancellationToken: ct);

        return blobClient.Uri.ToString();
    }

    public async Task<bool> DeleteIfExistsAsync(string blobKey, CancellationToken ct = default)
    {
        var containerClient = _blobServiceClient.GetBlobContainerClient("img");
        var blobClient = containerClient.GetBlobClient(blobKey);
        var result = await blobClient.DeleteIfExistsAsync(cancellationToken: ct);
        return result.Value; // true if deleted
    }

    public async Task<string> GetReadOnlySasUrlAsync(string blobUrl, TimeSpan duracion, CancellationToken ct = default)
    {
        var uri = new Uri(blobUrl);
        var containerName = uri.Segments[1].TrimEnd('/');
        var blobKey = string.Join("", uri.Segments.Skip(2)); // incluye "views/..."

        var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);
        var blobClient = containerClient.GetBlobClient(blobKey);

        var sasBuilder = new BlobSasBuilder
        {
            BlobContainerName = containerName,
            BlobName = blobKey,
            Resource = "b",
            ExpiresOn = DateTimeOffset.UtcNow.Add(duracion)
        };
        sasBuilder.SetPermissions(BlobSasPermissions.Read);

        var sasToken = sasBuilder.ToSasQueryParameters(
            new StorageSharedKeyCredential(_blobServiceClient.AccountName, _accountKey)
        ).ToString();

        return $"{blobClient.Uri}?{sasToken}";
    }

    // Conveniencia: borrar POR URL (evita errores de clave/ruta)
    public async Task<bool> DeleteByUrlIfExistsAsync(string blobUrl, CancellationToken ct = default)
    {
        var uri = new Uri(blobUrl);
        var containerName = uri.Segments[1].TrimEnd('/');      // "img"
        var blobKey = string.Join("", uri.Segments.Skip(2));   // "views/2025/09/18/abcdef.jpg"

        var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);
        var blobClient = containerClient.GetBlobClient(blobKey);
        var result = await blobClient.DeleteIfExistsAsync(cancellationToken: ct);
        return result.Value;
    }
}