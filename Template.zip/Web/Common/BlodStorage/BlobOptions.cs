namespace Xignux.Juridico.Inmuebles.Web.Common.BlodStorage;

public class BlobOptions
{
    public string ConnectionString { get; set; } = string.Empty;
    public string AccountKey { get; set; } = string.Empty;
}