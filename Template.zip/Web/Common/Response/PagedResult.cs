namespace Xignux.Juridico.Inmuebles.Web.Common.Response;

public sealed class PagedResult<T>
{
    public IReadOnlyList<T> Items { get; set; } = [];
    public int TotalCount { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 10;
    public string SortBy { get; set; } = string.Empty;
    public string SortDir { get; set; } = "ASC";
    public int TotalPages => (int)Math.Ceiling((double)TotalCount / PageSize);
}
