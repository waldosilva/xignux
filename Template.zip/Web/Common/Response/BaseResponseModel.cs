namespace Xignux.Juridico.Inmuebles.Web.Common.Response;

public sealed class BaseResponseModel<T>
{
    public int StatusCode { get; set; }
    public string Message { get; set; } = string.Empty;
    public T? Payload { get; set; }

    public int CurrentPage { get; set; }
    public int TotalRecords { get; set; }
    public int TotalPages { get; set; }
    public int PageSize { get; set; }
}
