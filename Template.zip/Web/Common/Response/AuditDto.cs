namespace Xignux.Juridico.Inmuebles.Web.Common.Response;

public class AuditDto
{
    public string CreadoPor { get; set; } = null!;

    public DateTime FechaCreacion { get; set; }

    public string ModificadoPor { get; set; } = null!;

    public DateTime FechaModificacion { get; set; }
}