// Confirmación que devuelve true/false
export function confirm(title, text, confirmText = 'Sí', cancelText = 'No') {
    return window.Swal.fire({
        title,
        text,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: confirmText,
        cancelButtonText: cancelText,
        focusCancel: true
    }).then(r => r.isConfirmed === true);
}

// Alerta estándar (info/success/error/warning)
export function alert(title, text = '', icon = 'info') {
    return window.Swal.fire({ title, text, icon });
}

// Toast rápido (arriba-derecha)
export function toast(message, icon = 'success') {
    const Toast = window.Swal.mixin({
        toast: true,
        position: 'top-end',
        timer: 3000,
        showConfirmButton: false,
        timerProgressBar: true
    });
    return Toast.fire({ title: message, icon });
}
