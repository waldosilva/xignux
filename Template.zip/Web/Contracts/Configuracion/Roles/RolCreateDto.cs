namespace Xignux.Juridico.Inmuebles.Web.Contracts.Configuracion.Roles;

public class RolCreateDto
{
    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;

    public string CreadoPor { get; set; } = null!;
}