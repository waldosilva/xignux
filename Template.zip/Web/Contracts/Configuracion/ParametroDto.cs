namespace Xignux.Juridico.Inmuebles.Web.Contracts.Configuracion;

public class ParametroDto
{
    
}