namespace Xignux.Juridico.Inmuebles.Web.Contracts.Configuracion.Usuarios;

public class UsuarioUpdateDto
{
    public int UsuarioId { get; set; }
    public string Email { get; set; } = null!;
    public int EmpresaId { get; set; }
    public string? EmpresaNombre { get; set; }
    public int RolId { get; set; }
    public string? RolNombre { get; set; }
    public string? EmpCode { get; set; }
    public string ModificadoPor { get; set; } = null!;
    public bool Activo { get; set; }
}