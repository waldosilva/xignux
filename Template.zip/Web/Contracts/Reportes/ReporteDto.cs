namespace Xignux.Juridico.Inmuebles.Web.Contracts.Reportes;

public class ReporteDto
{
    
}