namespace Xignux.Juridico.Inmuebles.Web.Contracts.Documentos;

public class CreateDocumentoDto
{
    
}