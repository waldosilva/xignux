namespace Xignux.Juridico.Inmuebles.Web.Contracts.Inmuebles;

public class CreateInmuebleDto
{
    
}