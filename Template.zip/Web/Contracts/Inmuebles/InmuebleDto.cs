namespace Xignux.Juridico.Inmuebles.Web.Contracts.Inmuebles;

public sealed record InmuebleDto(Guid Id, string ClaveCatastral, string? Domicilio, decimal? Superficie);