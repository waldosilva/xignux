using Xignux.Juridico.Inmuebles.Web.Common.Request;

namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeDocumentos;

public class TipoDocumentoReadDto : BaseRequestModel
{
    public int TipoDocumentoId { get; set; }
    public string Nombre { get; set; } = null!;
    public string Descripcion { get; set; } = null!;
    public int? CatTipoDocumentoId { get; set; }
    public string? CatTipoDocumentoNombre { get; set; }
}