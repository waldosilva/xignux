namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeDocumentos;

public class TipoDocumentoCreateDto
{
    public string Nombre { get; set; } = null!;
    public string Descripcion { get; set; } = null!;
    public string CreadoPor { get; set; } = null!;
    public int? CatTipoDocumentoId { get; set; }
}