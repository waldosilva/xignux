using Xignux.Juridico.Inmuebles.Web.Common.Request;

namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeMovimientos;

public class TipoMovimientoReadDto: BaseRequestModel
{
    public int TipoMovimientoId { get; set; }
    public string Nombre { get; set; } = null!;
    public string Descripcion { get; set; } = null!;
}