namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeMovimientos;

public class TipoMovimientoCreateDto
{
    public string Nombre { get; set; } = null!;
    public string Descripcion { get; set; } = null!;
    public string CreadoPor { get; set; } = null!;
}