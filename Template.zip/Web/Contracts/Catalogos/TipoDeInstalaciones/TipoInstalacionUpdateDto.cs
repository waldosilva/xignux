namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeInstalaciones;

public class TipoInstalacionUpdateDto
{
    public int TipoInstalacionId { get; set; }
    public string Codigo { get; set; } = null!;
    public string Descripcion { get; set; } = null!;
    public bool Activo { get; set; }
    public string ModificadoPor { get; set; } = null!;
}