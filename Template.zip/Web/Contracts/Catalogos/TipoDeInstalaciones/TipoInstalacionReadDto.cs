using Xignux.Juridico.Inmuebles.Web.Common.Request;

namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeInstalaciones;

public class TipoInstalacionReadDto : BaseRequestModel
{
    public int TipoInstalacionId { get; set; }

    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;
    public bool Activo { get; set; }
}