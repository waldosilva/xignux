namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeInstalaciones;

public class TipoInstalacionCreateDto
{
    public string Codigo { get; set; } = null!;
    public string Descripcion { get; set; } = null!;
    public string CreadoPor { get; set; } = null!;
}