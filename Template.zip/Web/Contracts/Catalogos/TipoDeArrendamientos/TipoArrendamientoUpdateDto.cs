namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeArrendamientos;

public class TipoArrendamientoUpdateDto
{
    public int TipoArrendamientoId { get; set; }

    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;

    public string ModificadoPor { get; set; } = null!;

    public bool Activo { get; set; }
}