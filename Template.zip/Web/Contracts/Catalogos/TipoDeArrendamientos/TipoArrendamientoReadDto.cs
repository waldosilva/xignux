using Xignux.Juridico.Inmuebles.Web.Common.Request;

namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeArrendamientos;

public class TipoArrendamientoReadDto : BaseRequestModel
{
    public int TipoArrendamientoId { get; set; }

    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;
}