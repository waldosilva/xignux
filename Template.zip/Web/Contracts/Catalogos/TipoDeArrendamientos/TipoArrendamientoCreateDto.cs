namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeArrendamientos;

public class TipoArrendamientoCreateDto
{
    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;

    public string CreadoPor { get; set; } = null!;
}