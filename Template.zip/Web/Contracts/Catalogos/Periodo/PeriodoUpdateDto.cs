namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Periodo;

public class PeriodoUpdateDto
{
    public int PeriodoId { get; set; }
    public string Descripcion { get; set; } = null!;
    public bool Activo { get; set; }
    public string ModificadoPor { get; set; } = null!;
}