namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Periodo;

public class PeriodoCreateDto
{
    public string? Descripcion { get; set; }
    public string CreadoPor { get; set; } = null!;
}