using Xignux.Juridico.Inmuebles.Web.Common.Request;

namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Periodo;

public class PeriodoReadDto: BaseRequestModel
{
    public int PeriodoId { get; set; }

    public string Descripcion { get; set; } = null!;
}