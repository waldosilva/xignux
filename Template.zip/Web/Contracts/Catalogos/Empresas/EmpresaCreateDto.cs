namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Empresas;

public class EmpresaCreateDto
{
    public int DivisionId { get; set; }

    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;
    
    public string? UrlImg { get; set; }
    
    public string? ImagenBlobName { get; set; }

    public string CreadoPor { get; set; } = null!;
}