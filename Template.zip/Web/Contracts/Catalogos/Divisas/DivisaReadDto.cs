using Xignux.Juridico.Inmuebles.Web.Common.Request;

namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Divisas;

public class DivisaReadDto : BaseRequestModel
{
    public int DivisaId { get; set; }

    public string? Descripcion { get; set; }
}