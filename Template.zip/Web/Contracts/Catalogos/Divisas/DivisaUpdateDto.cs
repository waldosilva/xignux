namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Divisas;

public class DivisaUpdateDto
{
    public int DivisaId { get; set; }
    public string Descripcion { get; set; } = null!;
    public bool Activo { get; set; }
    public string ModificadoPor { get; set; } = null!;
}