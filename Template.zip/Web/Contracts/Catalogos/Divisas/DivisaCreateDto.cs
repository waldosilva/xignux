namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Divisas;

public class DivisaCreateDto
{
    public string? Descripcion { get; set; }
    public string CreadoPor { get; set; } = null!;
}