namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Destinos;

public class DestinoUpdateDto
{
    public int DestinoId { get; set; }
    public string? Descripcion { get; set; } = null!;
    public string ModificadoPor { get; set; } = null!;
    public bool Activo { get; set; }
}