using Xignux.Juridico.Inmuebles.Web.Common.Request;

namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Destinos;

public class DestinoReadDto : BaseRequestModel
{
    public int DestinoId { get; set; }

    public string Descripcion { get; set; } = null!;
}