namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Destinos;

public class DestinoCreateDto
{
    public int DestinoId { get; set; }

    public string Descripcion { get; set; } = null!;
    
    public string CreadoPor { get; set; } = null!;
}