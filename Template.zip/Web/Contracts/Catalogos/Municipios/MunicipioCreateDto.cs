namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Municipios;

public class MunicipioCreateDto
{
    public int PaisId { get; set; }
    public int EstadoId { get; set; }
    public string? Descripcion { get; set; }
    public string CreadoPor { get; set; } = null!;
}