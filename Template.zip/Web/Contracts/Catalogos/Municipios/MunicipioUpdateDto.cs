namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Municipios;

public class MunicipioUpdateDto
{
    public int MunicipioId { get; set; }
    public int EstadoId { get; set; }
    public string? EstadoNombre { get; set; }
    public int PaisId { get; set; }
    public string? Descripcion { get; set; }
    public string ModificadoPor { get; set; } = null!;
    public bool Activo { get; set; }
}