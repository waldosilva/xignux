using Xignux.Juridico.Inmuebles.Web.Common.Request;

namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Municipios;

public class MunicipioReadDto : BaseRequestModel
{
    public int MunicipioId { get; set; }
    public string? Descripcion { get; set; }
    
    public int EstadoId { get; set; }
    public string? EstadoNombre { get; set; }
    
    public int PaisId { get; set; }
    public string? PaisNombre { get; set; }
    
}