namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Colonias;

public class ColoniaCreateDto
{
    public int PaisId     { get; set; }
    public string PaisNombre       { get; set; } = null!;
    public int EstadoId     { get; set; }
    public string EstadoNombre       { get; set; } = null!;
    public int MunicipioId     { get; set; }
    public string MunicipioNombre       { get; set; } = null!;
    public string Codigo       { get; set; } = null!;
    public string CodigoPostal { get; set; } = null!;
    public string Descripcion  { get; set; } = null!;
    public string CreadoPor    { get; set; } = null!;
}