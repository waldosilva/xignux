namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Estatus;

public class EstatusCreateDto
{
    public string Codigo { get; set; } = null!;
    public string Descripcion { get; set; } = null!;
    public string CreadoPor { get; set; } = null!;
}