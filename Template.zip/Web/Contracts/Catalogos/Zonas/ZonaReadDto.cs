using Xignux.Juridico.Inmuebles.Web.Common.Request;

namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Zonas;

public class ZonaReadDto : BaseRequestModel
{
    public int ZonaId { get; set; }
    public int? DivisionId { get; set; }
    public string? Descripcion { get; set; }
}