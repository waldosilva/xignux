namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.GiroDeActividades;

public class GiroActividadCreateDto
{
    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;

    public string CreadoPor { get; set; } = null!;
}