using Xignux.Juridico.Inmuebles.Web.Common.Request;

namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Estados;

public class EstadoReadDto : BaseRequestModel
{
    public string? Codigo { get; set; }
    public int EstadoId { get; set; }
    public string? Descripcion { get; set; }
    
    public int PaisId { get; set; }
    public string? PaisNombre { get; set; }
}