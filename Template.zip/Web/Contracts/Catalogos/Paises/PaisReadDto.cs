using Xignux.Juridico.Inmuebles.Web.Common.Request;

namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Paises;

public class PaisReadDto : BaseRequestModel
{
    public int PaisId { get; set; }

    public string? Codigo { get; set; }

    public string? Descripcion { get; set; }
}