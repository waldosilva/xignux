namespace Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Paises;

public class PaisUpdateDto
{
    public int PaisId { get; set; }

    public string? Codigo { get; set; }

    public string? Descripcion { get; set; }

    public string? ModificadoPor { get; set; }

    public bool Activo { get; set; }
}