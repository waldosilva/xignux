using Microsoft.AspNetCore.Components;

namespace Xignux.Juridico.Inmuebles.Web.Components.Layout;

public partial class MainLayout : LayoutComponentBase
{
    [Inject] private NavigationManager NavigationManager { get; set; } = default!;
    protected bool IsHomePage => NavigationManager.Uri.EndsWith("/") || NavigationManager.Uri.EndsWith("/index");
}