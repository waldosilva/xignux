using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;

namespace Xignux.Juridico.Inmuebles.Web.Components.Layout;

public partial class MainLayout : LayoutComponentBase
{
    [Inject] private NavigationManager NavigationManager { get; set; } = default!;
    
    [Inject] IUsuarioService Service { get; set; } = default!;
    
    [CascadingParameter] private Task<AuthenticationState> AuthState { get; set; } = default!;
    
    private int _userRolId = 0;
    
    protected bool IsHomePage => NavigationManager.Uri.EndsWith("/") || NavigationManager.Uri.EndsWith("/index");
    
    
    protected override async Task OnInitializedAsync()
    {
        var user = (await AuthState).User;
        if (user.Identity?.Name != null)
        {
            var result = await Service.GetByEmailAsync(user.Identity?.Name!);
            if (result.Payload != null) _userRolId = result.Payload.RolId;
        }
    }

}