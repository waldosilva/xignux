using System.Globalization;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Routing;

namespace Xignux.Juridico.Inmuebles.Web.Components.Navigation;

public partial class Breadcrumb : ComponentBase, IDisposable
{
    [Inject] protected NavigationManager NavigationManager { get; set; } = default!;

    // 🔤 Diccionario de títulos corregidos (case-insensitive)
    // Agrega o ajusta las entradas que necesites
    private static readonly Dictionary<string, string> SegmentTitleMap =
        new(StringComparer.OrdinalIgnoreCase)
        {
            // acciones comunes
            ["lista"]          = "Lista",
            ["nuevo"]          = "Nuevo",
            ["editar"]         = "Editar",
            ["detalle"]        = "Detalle",
                
            // módulos
            ["inmuebles"]      = "Inmuebles",
            ["documentos"]     = "Revisión de Documento",
            ["catalogos"]      = "Catálogos",
            ["reportes"]       = "Reportes",
            ["configuracion"]  = "Configuración",

            // páginas internas / catálogos
            ["colonias"]                = "Colonia",
            ["destinos"]                = "Destino",
            ["divisas"]                 = "Divisa",
            ["divisiones"]              = "Division",
            ["empresas"]                = "Empresa",
            ["estados"]                 = "Estado",
            ["estatus"]                 = "Estatus",
            ["giro_de_actividades"]     = "Giro de Actividades",
            ["municipios"]              = "Municipio",
            ["paises"]                  = "Pais",
            ["periodos"]                = "Períodos",
            ["tipo_de_arrendamientos"]  = "Tipos de Arrendamientos",
            ["tipo_de_instalacioness"]  = "Tipos de Instalaciones",
            
            // páginas internas / configuración
            ["modulos"]                = "Módulos",
            ["pantallas"]              = "Pantallas",
            ["permisos_de_aplicacion"]  = "Permisos de Aplicación",
            ["permisos_y_roles"]        = "Permisos y Rol",
            ["roles"]                  = "Rol",
            ["usuarios_y_empresas"]     = "Usuario y Empresa",
            ["usuarios"]               = "Usuario",

        };

    protected List<BreadcrumbSegment> Segments { get; set; } = new();

    protected override void OnInitialized()
    {
        NavigationManager.LocationChanged += OnLocationChanged;
        Build();
    }

    protected override void OnParametersSet()
    {
        // SSR: asegura que en el primer render ya tengas los segmentos
        Build();
    }

    private void OnLocationChanged(object? sender, LocationChangedEventArgs e)
    {
        Build();
        InvokeAsync(StateHasChanged);
    }

    private void Build()
    {
        Segments.Clear();

        // Ruta relativa (sin dominio)
        var rel = NavigationManager.ToBaseRelativePath(NavigationManager.Uri);

        // Quitar querystring y hash
        var q = rel.IndexOf('?'); if (q >= 0) rel = rel[..q];
        var h = rel.IndexOf('#'); if (h >= 0) rel = rel[..h];

        rel = rel.Trim('/');

        if (string.IsNullOrEmpty(rel))
            return;

        var parts = rel.Split('/', StringSplitOptions.RemoveEmptyEntries);

        var path = string.Empty;
        for (int i = 0; i < parts.Length; i++)
        {
            var seg = parts[i];
            path += "/" + seg;

            Segments.Add(new BreadcrumbSegment
            {
                Title = TitleFor(seg),   // ← usa el diccionario primero
                Url   = path,
                IsLast = i == parts.Length - 1
            });
        }
    }

    // 🔎 Obtiene un título "bonito": primero diccionario, luego TitleCase
    private static string TitleFor(string seg)
    {
        if (string.IsNullOrWhiteSpace(seg)) return seg;

        // si está mapeado, úsalo
        if (SegmentTitleMap.TryGetValue(seg, out var mapped) && !string.IsNullOrWhiteSpace(mapped))
            return mapped;

        // si no, derivar: reemplaza separadores y aplica TitleCase
        var friendly = seg.Replace("-", " ").Replace("_", " ").Trim();
        return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(friendly);
    }

    public void Dispose()
    {
        NavigationManager.LocationChanged -= OnLocationChanged;
    }

    protected class BreadcrumbSegment
    {
        public string Title { get; set; } = "";
        public string Url { get; set; } = "";
        public bool IsLast { get; set; }
    }
}
