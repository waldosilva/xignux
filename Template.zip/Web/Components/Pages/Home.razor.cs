namespace Xignux.Juridico.Inmuebles.Web.Components.Pages;

public partial class Home_razor
{
    
}