using Microsoft.AspNetCore.Components;

namespace Xignux.Juridico.Inmuebles.Web.Components.Pages;

public sealed partial class Home : ComponentBase
{
   // Modelo de fila
    public sealed class EmpresaPermisosRow
    {
        public EmpresaPermisosRow(string empresa) => Empresa = empresa;
        public string Empresa { get; init; }

        public bool P1 { get; set; }
        public bool P2 { get; set; }
        public bool P3 { get; set; }
        public bool P4 { get; set; }
        public bool P5 { get; set; }
        public bool P6 { get; set; }
        public bool P7 { get; set; }
    }

    private List<EmpresaPermisosRow> Rows = new();

    protected override void OnInitialized()
    {
        var empresas = new[]
        {
            "MULTIPAK, S.A. DE C.V.",
            "CONDUCTORES MONTERREY, S.A. DE C.V.",
            "XIGNUX, S.A. DE C.V.",
            "QUALTIA ALIMENTOS OPERACIONES, S. DE R.L. DE C.V.",
            "BOTANAS Y DERIVADOS, S.A. DE C.V.",
            "PROLEC, S.A. DE C.V.",
            "PROLEC GE INTERNACIONAL, S. DE R.L. DE C.V.",
            "INDUSTRIAS XIGNUX, S.A. DE C.V.",
            "MAGNEKON, S.A. DE C.V.",
            "XIGNUX CORPORATIVO, S.A. DE C.V.",
            "FOOD SERVICE DE MEXICO, S.A. DE C.V.",
            "PRALGO, S.A. DE C.V.",
            "VIAKABLE, S.A. DE C.V.",
            "CARNES PREMIUM XO, S.A. DE C.V.",
            "Atlantic Meat de México, S. DE R.L. DE C.V.",
            "INTERAMERICANA DE CABLES VENEZUELA, S.A.",
            "CME WIRE AND CABLE, INC",
            "CONDUCTORES DEL NORTE, S.A. DE C.V",
            "PROLEC GE BRASIL TRANSMISSAO DE ENERGIA S.A",
            "VOLTWAY, S.A.P.I de C.V.",
            "NANOMATERIALES, S.A. DE C.V.",
            "SHARESER, S.A. DE C.V",
            "PROLEC GE USA, LLC",
            "PROLEC GE WAUKESHA, INC",
            "GE PROLEC TRANSFORMERS, INC",
            "PROLEC, LLC",
            "Sin Empresa",
            "VIALUTEK, S.A. DE C.V.",
            "EMPRESA PRUEBAS"
        };

        Rows = empresas.Select(e => new EmpresaPermisosRow(e)).ToList();
    }

    // ===== Encabezados (propiedades calculadas por columna) =====
    private bool Col1All
    {
        get => Rows.Count > 0 && Rows.All(r => r.P1);
        set { foreach (var r in Rows) r.P1 = value; }
    }
    private bool Col2All
    {
        get => Rows.Count > 0 && Rows.All(r => r.P2);
        set { foreach (var r in Rows) r.P2 = value; }
    }
    private bool Col3All
    {
        get => Rows.Count > 0 && Rows.All(r => r.P3);
        set { foreach (var r in Rows) r.P3 = value; }
    }
    private bool Col4All
    {
        get => Rows.Count > 0 && Rows.All(r => r.P4);
        set { foreach (var r in Rows) r.P4 = value; }
    }
    private bool Col5All
    {
        get => Rows.Count > 0 && Rows.All(r => r.P5);
        set { foreach (var r in Rows) r.P5 = value; }
    }
    private bool Col6All
    {
        get => Rows.Count > 0 && Rows.All(r => r.P6);
        set { foreach (var r in Rows) r.P6 = value; }
    }
    private bool Col7All
    {
        get => Rows.Count > 0 && Rows.All(r => r.P7);
        set { foreach (var r in Rows) r.P7 = value; }
    }

    // (Opcional) botón Limpiar
    private void Limpiar()
    {
        foreach (var r in Rows)
            r.P1 = r.P2 = r.P3 = r.P4 = r.P5 = r.P6 = r.P7 = false;
    }

    // (Opcional) Guardar
    private Task GuardarAsync()
    {
        var payload = Rows.Select(r => new
        {
            r.Empresa,
            r.P1, r.P2, r.P3, r.P4, r.P5, r.P6, r.P7
        }).ToList();

        // await _http.PostAsJsonAsync("api/empresas/permisos", payload);
        return Task.CompletedTask;
    }
}