using Microsoft.AspNetCore.Components;

namespace Xignux.Juridico.Inmuebles.Web.Components.Shared;

public partial class LoadingOverlay : ComponentBase
{
    [Parameter] public bool Show { get; set; }
}