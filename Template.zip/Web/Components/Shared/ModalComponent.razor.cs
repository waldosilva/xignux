using Microsoft.AspNetCore.Components;

namespace Xignux.Juridico.Inmuebles.Web.Components.Shared;

public partial class ModalComponent : ComponentBase
{
    [Parameter] public bool Show { get; set; }
    [Parameter] public string? Title { get; set; }
    [Parameter] public RenderFragment? ChildContent { get; set; }
    [Parameter] public RenderFragment? FooterContent { get; set; }
    [Parameter] public bool ShowFooter { get; set; } = false;
    [Parameter] public EventCallback OnClose { get; set; }

    private Task Close() => OnClose.InvokeAsync();
}