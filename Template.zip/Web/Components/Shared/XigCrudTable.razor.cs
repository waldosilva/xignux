using Microsoft.AspNetCore.Components;

namespace Xignux.Juridico.Inmuebles.Web.Components.Shared;

public class XigCrudTableBase<TItem> : ComponentBase
{
    // Datos / estado
    [Parameter] public IEnumerable<TItem>? Items { get; set; }
    [Parameter] public bool Loading { get; set; }

    [Parameter] public int CurrentPage { get; set; } = 1;
    [Parameter] public int PageSize { get; set; } = 10;
    [Parameter] public int TotalPages { get; set; } = 1;
    [Parameter] public int TotalCount { get; set; } = 0;

    [Parameter] public int[] PageSizeOptions { get; set; } = new[] { 10, 25, 50 };

    // Búsqueda (two-way bind)
    [Parameter] public string? SearchTerm { get; set; }
    [Parameter] public EventCallback<string?> SearchTermChanged { get; set; }

    // Plantillas
    [Parameter] public RenderFragment? HeaderTemplate { get; set; }
    [Parameter] public RenderFragment<TItem>? RowTemplate { get; set; }
    [Parameter] public RenderFragment? ChildContent { get; set; } // para modales/zona extra

    // Eventos (el padre hace el trabajo real)
    [Parameter] public EventCallback OnNew { get; set; }
    [Parameter] public EventCallback OnSearch { get; set; }
    [Parameter] public EventCallback OnClearSearch { get; set; }
    [Parameter] public EventCallback<int> ChangePageRequested { get; set; }
    [Parameter] public EventCallback<int> PageSizeChanged { get; set; }

    protected IEnumerable<int> VisiblePageRange(int max = 7)
    {
        if (TotalPages <= 0) yield break;

        var half = max / 2;
        var start = Math.Max(1, CurrentPage - half);
        var end = Math.Min(TotalPages, start + max - 1);
        if (end - start + 1 < max) start = Math.Max(1, end - max + 1);

        for (var p = start; p <= end; p++)
            yield return p;
    }

    protected async Task HandlePageSizeChanged(ChangeEventArgs e)
    {
        if (int.TryParse(e.Value?.ToString(), out var newSize))
            await PageSizeChanged.InvokeAsync(newSize);
    }
}