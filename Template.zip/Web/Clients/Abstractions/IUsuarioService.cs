using Xignux.Juridico.Inmuebles.Web.Common.Response;
using Xignux.Juridico.Inmuebles.Web.Contracts.Configuracion.Usuarios;

namespace Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;

public interface IUsuarioService 
    : ICrudService<UsuarioCreateDto, UsuarioReadDto, UsuarioUpdateDto, int>
{
    Task<BaseResponseModel<UsuarioReadDto?>> GetByEmailAsync(string email, CancellationToken ct = default);
}