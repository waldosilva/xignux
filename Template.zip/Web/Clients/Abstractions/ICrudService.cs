using Xignux.Juridico.Inmuebles.Web.Common.Response;

namespace Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;

public interface ICrudService<TCreateDto, TReadDto, TUpdateDto, TKey>
{
    Task<BaseResponseModel<PagedResult<TReadDto>>> GetPagedAsync(PageFilter filter, CancellationToken ct = default);
    Task<BaseResponseModel<TReadDto>> GetByIdAsync(TKey id, CancellationToken ct = default);
    Task<TKey> CreateAsync(TCreateDto dto, CancellationToken ct = default);
    Task<bool> UpdateAsync(TKey id, TUpdateDto dto, CancellationToken ct = default);
    Task<bool> DeleteAsync(TKey id, CancellationToken ct = default);
}
