using System.Net.Http.Headers;
using Microsoft.Identity.Web;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Response;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeArrendamientos;

namespace Xignux.Juridico.Inmuebles.Web.Clients.Modules.Catalogos;

public sealed class TipoArrendamientoService : ICrudService<TipoArrendamientoCreateDto, TipoArrendamientoReadDto, TipoArrendamientoUpdateDto, int>
{
    private readonly HttpClient _http;
    private readonly ITokenAcquisition _tokens;
    private readonly IHttpContextAccessor _httpCtx;
    private readonly IConfiguration _cfg;

    public TipoArrendamientoService(HttpClient http, ITokenAcquisition tokens, IHttpContextAccessor httpCtx, IConfiguration cfg)
    {
        _http = http;
        _tokens = tokens;
        _httpCtx = httpCtx;
        _cfg = cfg;
    }
    
    // -------- helper para adjuntar Bearer y APIM key --------
    private async Task AttachAuthAsync(HttpRequestMessage req)
    {
        // Scopes desde DownstreamApi:Scopes o AzureAd:ApiScope
        var scopes = _cfg.GetSection("DownstreamApi:Scopes").Get<string[]>();
        if (scopes == null || scopes.Length == 0)
        {
            var s = _cfg["AzureAd:ApiScope"];
            if (!string.IsNullOrWhiteSpace(s)) scopes = new[] { s };
        }

        var user = _httpCtx.HttpContext?.User;
        var accessToken = await _tokens.GetAccessTokenForUserAsync(scopes!, user: user);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

        var apimKey = _cfg["Apim:SubscriptionKey"];
        if (!string.IsNullOrWhiteSpace(apimKey))
            req.Headers.TryAddWithoutValidation("Ocp-Apim-Subscription-Key", apimKey);
    }
    
    public async Task<BaseResponseModel<PagedResult<TipoArrendamientoReadDto>>> GetPagedAsync(PageFilter filter, CancellationToken ct = default)
    {
        using var req = new HttpRequestMessage(HttpMethod.Post, "tipoarrendamiento/buscar")
        {
            Content = JsonContent.Create(filter)
        };
        await AttachAuthAsync(req);
        using var res = await _http.SendAsync(req, ct);
        return await res.Content.ReadFromJsonAsync<BaseResponseModel<PagedResult<TipoArrendamientoReadDto>>>(cancellationToken: ct)
               ?? new BaseResponseModel<PagedResult<TipoArrendamientoReadDto>> { StatusCode = 500, Message = "Error al obtener datos" };
    }

    public async Task<BaseResponseModel<TipoArrendamientoReadDto>> GetByIdAsync(int id, CancellationToken ct = default)
    {
        using var req = new HttpRequestMessage(HttpMethod.Get, $"tipoarrendamiento/{id}");
        await AttachAuthAsync(req);
        using var res = await _http.SendAsync(req, ct);
        return await res.Content.ReadFromJsonAsync<BaseResponseModel<TipoArrendamientoReadDto>>(cancellationToken: ct)
               ?? new BaseResponseModel<TipoArrendamientoReadDto> { StatusCode = 500, Message = "Error al obtener TipoArrendamiento" };
    }

    public async Task<int> CreateAsync(TipoArrendamientoCreateDto dto, CancellationToken ct = default)
    {
        using var req = new HttpRequestMessage(HttpMethod.Post, "tipoarrendamiento")
        { Content = JsonContent.Create(dto) };
        await AttachAuthAsync(req);
        using var res = await _http.SendAsync(req, ct);
        return await res.Content.ReadFromJsonAsync<int>(cancellationToken: ct);
    }

    public async Task<bool> UpdateAsync(int id, TipoArrendamientoUpdateDto dto, CancellationToken ct = default)
    {
        using var req = new HttpRequestMessage(HttpMethod.Put, $"tipoarrendamiento/{id}")
        { Content = JsonContent.Create(dto) };
        await AttachAuthAsync(req);
        using var res = await _http.SendAsync(req, ct);
        return res.IsSuccessStatusCode;
    }

    public async Task<bool> DeleteAsync(int id, CancellationToken ct = default)
    {
        // Nota: estandariza el case de la ruta (usa "tipoarrendamiento", no "TipoArrendamiento")
        using var req = new HttpRequestMessage(HttpMethod.Delete, $"tipoarrendamiento/{id}");
        await AttachAuthAsync(req);
        using var res = await _http.SendAsync(req, ct);
        return res.IsSuccessStatusCode;
    }
}