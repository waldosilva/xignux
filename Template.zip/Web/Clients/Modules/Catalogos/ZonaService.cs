using System.Net.Http.Headers;
using Microsoft.Identity.Web;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Common.Response;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Zonas;

namespace Xignux.Juridico.Inmuebles.Web.Clients.Modules.Catalogos;

public sealed class ZonaService : ICrudService<ZonaCreateDto, ZonaReadDto, ZonaUpdateDto, int>
    {
        private readonly HttpClient _http;
        private readonly ITokenAcquisition _tokens;
        private readonly IHttpContextAccessor _httpCtx;
        private readonly IConfiguration _cfg;

        public ZonaService(HttpClient http, ITokenAcquisition tokens, IHttpContextAccessor httpCtx, IConfiguration cfg)
        {
            _http = http;
            _tokens = tokens;
            _httpCtx = httpCtx;
            _cfg = cfg;
        }

        private async Task AttachAuthAsync(HttpRequestMessage req)
        {
            // Scopes desde DownstreamApi:Scopes o AzureAd:ApiScope
            var scopes = _cfg.GetSection("DownstreamApi:Scopes").Get<string[]>();
            if (scopes == null || scopes.Length == 0)
            {
                var s = _cfg["AzureAd:ApiScope"];
                if (!string.IsNullOrWhiteSpace(s)) scopes = new[] { s };
            }

            var user = _httpCtx.HttpContext?.User;
            var accessToken = await _tokens.GetAccessTokenForUserAsync(scopes!, user: user);
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            var apimKey = _cfg["Apim:SubscriptionKey"];
            if (!string.IsNullOrWhiteSpace(apimKey))
                req.Headers.TryAddWithoutValidation("Ocp-Apim-Subscription-Key", apimKey);
        }

        public async Task<BaseResponseModel<PagedResult<ZonaReadDto>>> GetPagedAsync(PageFilter filter, CancellationToken ct = default)
        {
            using var req = new HttpRequestMessage(HttpMethod.Post, "Zona/buscar")
            {
                Content = JsonContent.Create(filter)
            };
            await AttachAuthAsync(req);
            using var res = await _http.SendAsync(req, ct);
            return await res.Content.ReadFromJsonAsync<BaseResponseModel<PagedResult<ZonaReadDto>>>(cancellationToken: ct)
                   ?? new BaseResponseModel<PagedResult<ZonaReadDto>> { StatusCode = 500, Message = "Error al obtener datos" };
        }

        public async Task<BaseResponseModel<ZonaReadDto>> GetByIdAsync(int id, CancellationToken ct = default)
        {
            using var req = new HttpRequestMessage(HttpMethod.Get, $"Zona/{id}");
            await AttachAuthAsync(req);
            using var res = await _http.SendAsync(req, ct);
            return await res.Content.ReadFromJsonAsync<BaseResponseModel<ZonaReadDto>>(cancellationToken: ct)
                   ?? new BaseResponseModel<ZonaReadDto> { StatusCode = 500, Message = "Error al obtener Zona" };
        }

        public async Task<int> CreateAsync(ZonaCreateDto dto, CancellationToken ct = default)
        {
            using var req = new HttpRequestMessage(HttpMethod.Post, "Zona")
            { Content = JsonContent.Create(dto) };
            await AttachAuthAsync(req);
            using var res = await _http.SendAsync(req, ct);
            return await res.Content.ReadFromJsonAsync<int>(cancellationToken: ct);
        }

        public async Task<bool> UpdateAsync(int id, ZonaUpdateDto dto, CancellationToken ct = default)
        {
            using var req = new HttpRequestMessage(HttpMethod.Put, $"Zona/{id}")
            { Content = JsonContent.Create(dto) };
            await AttachAuthAsync(req);
            using var res = await _http.SendAsync(req, ct);
            return res.IsSuccessStatusCode;
        }

        public async Task<bool> DeleteAsync(int id, CancellationToken ct = default)
        {
            using var req = new HttpRequestMessage(HttpMethod.Delete, $"Zona/{id}");
            await AttachAuthAsync(req);
            using var res = await _http.SendAsync(req, ct);
            return res.IsSuccessStatusCode;
        }

    }