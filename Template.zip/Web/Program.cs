using System.Net.Http.Headers;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.Identity.Web;
using Microsoft.Identity.Web.UI;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Xignux.Juridico.Inmuebles.Web.Clients.Abstractions;
using Xignux.Juridico.Inmuebles.Web.Clients.Modules.Catalogos;
using Xignux.Juridico.Inmuebles.Web.Clients.Modules.Configuracion;
using Xignux.Juridico.Inmuebles.Web.Common.BlodStorage;
using Xignux.Juridico.Inmuebles.Web.Common.Security;
using Xignux.Juridico.Inmuebles.Web.Components;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Colonias;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Destinos;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Divisas;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Divisiones;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Documentos;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Empresas;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Estados;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Estatus;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.GiroDeActividades;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Municipios;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Paises;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Periodo;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeArrendamientos;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeDocumentos;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeInstalaciones;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.TipoDeMovimientos;
using Xignux.Juridico.Inmuebles.Web.Contracts.Catalogos.Zonas;
using Xignux.Juridico.Inmuebles.Web.Contracts.Configuracion.Roles;
using Xignux.Juridico.Inmuebles.Web.Services;

var builder = WebApplication.CreateBuilder(args);

// ---------- Base URL para la API (APIM en prod, localhost en dev) ----------
var apimBase = builder.Configuration["DownstreamApi:BaseUrl"]; // p.ej. https://miapim.azure-api.net/
var localBase = builder.Configuration["ApiBaseUrl"];           // p.ej. http://localhost:5253/api/
var baseUrl = !string.IsNullOrWhiteSpace(apimBase) && !apimBase.Contains("<tu-dominio-apim>")
    ? apimBase
    : localBase ?? throw new InvalidOperationException("Falta ApiBaseUrl o DownstreamApi:BaseUrl");



// ---------- Auth OIDC + adquisición de tokens (MSAL) ----------
builder.Services.AddAuthentication(OpenIdConnectDefaults.AuthenticationScheme)
    .AddMicrosoftIdentityWebApp(builder.Configuration.GetSection("AzureAd"))
    .EnableTokenAcquisitionToCallDownstreamApi()   // necesario para ITokenAcquisition
    .AddInMemoryTokenCaches();

builder.Services.AddRazorPages().AddMicrosoftIdentityUI();

builder.Services.Configure<OpenIdConnectOptions>(OpenIdConnectDefaults.AuthenticationScheme, options =>
{
    options.ResponseType = OpenIdConnectResponseType.Code; // "code"
    options.UsePkce = true;
    options.SaveTokens = true; // útil si necesitas inspeccionar tokens
});

// Toda la app autenticada por defecto
builder.Services.AddAuthorization(options =>
{
    options.FallbackPolicy = options.DefaultPolicy;
});

builder.Services.AddCascadingAuthenticationState();

// ---------- Blazor SSR ----------
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents()
    .AddCircuitOptions(o => o.DetailedErrors = true);

// ---------- HttpClient con handler que agrega Bearer y APIM key ----------
builder.Services.AddHttpContextAccessor();
builder.Services.AddTransient<ApiAuthHandler>(); // ver clase abajo

builder.Services.AddHttpClient("Api", c =>
{
    var normalized = baseUrl.TrimEnd('/') + "/";
    c.BaseAddress = new Uri(normalized, UriKind.Absolute);
    c.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
})
.AddHttpMessageHandler<ApiAuthHandler>();

// Proveer HttpClient "Api" por request (para tus servicios existentes)
builder.Services.AddScoped(sp =>
{
    var factory = sp.GetRequiredService<IHttpClientFactory>();
    return factory.CreateClient("Api");
});

// ---------- Servicios propios ----------
builder.Services.AddSingleton<IconCatalogService>();
builder.Services.AddScoped<ISweetAlertService, SweetAlertService>();

builder.Services.Configure<BlobOptions>(builder.Configuration.GetSection("AzureBlob"));
builder.Services.AddSingleton<IBlobStorageService, AzureBlobStorageService>();

builder.Services.AddScoped<ICrudService<ColoniaCreateDto, ColoniaReadDto, ColoniaUpdateDto, int>, ColoniaService>();
builder.Services.AddScoped<ICrudService<DestinoCreateDto, DestinoReadDto, DestinoUpdateDto, int>, DestinoService>();
builder.Services.AddScoped<ICrudService<DivisaCreateDto, DivisaReadDto, DivisaUpdateDto, int>, DivisaService>();
builder.Services.AddScoped<ICrudService<DivisionCreateDto, DivisionReadDto, DivisionUpdateDto, int>, DivisionService>();
builder.Services.AddScoped<ICrudService<DocumentoCreateDto, DocumentoReadDto, DocumentoUpdateDto, int>, DocumentoService>();
builder.Services.AddScoped<ICrudService<EmpresaCreateDto, EmpresaReadDto, EmpresaUpdateDto, int>, EmpresaService>();
builder.Services.AddScoped<ICrudService<EstadoCreateDto, EstadoReadDto, EstadoUpdateDto, int>, EstadoService>();
builder.Services.AddScoped<ICrudService<EstatusCreateDto, EstatusReadDto, EstatusUpdateDto, int>, EstatusService>();
builder.Services.AddScoped<ICrudService<GiroActividadCreateDto, GiroActividadReadDto, GiroActividadUpdateDto, int>, GiroActividadService>();
builder.Services.AddScoped<ICrudService<MunicipioCreateDto, MunicipioReadDto, MunicipioUpdateDto, int>, MunicipioService>();
builder.Services.AddScoped<ICrudService<PaisCreateDto, PaisReadDto, PaisUpdateDto, int>, PaisService>();
builder.Services.AddScoped<ICrudService<PeriodoCreateDto, PeriodoReadDto, PeriodoUpdateDto, int>, PeriodoService>();
builder.Services.AddScoped<ICrudService<RolCreateDto, RolReadDto, RolUpdateDto, int>, RolService>();
builder.Services.AddScoped<ICrudService<TipoArrendamientoCreateDto, TipoArrendamientoReadDto, TipoArrendamientoUpdateDto, int>, TipoArrendamientoService>();
builder.Services.AddScoped<ICrudService<TipoDocumentoCreateDto, TipoDocumentoReadDto, TipoDocumentoUpdateDto, int>, TipoDocumentoService>();
builder.Services.AddScoped<ICrudService<TipoInstalacionCreateDto, TipoInstalacionReadDto, TipoInstalacionUpdateDto, int>, TipoInstalacionService>();
builder.Services.AddScoped<ICrudService<TipoMovimientoCreateDto, TipoMovimientoReadDto, TipoMovimientoUpdateDto, int>, TipoMovimientoService>();
builder.Services.AddScoped<IUsuarioService, UsuarioService>();
builder.Services.AddScoped<ICrudService<ZonaCreateDto, ZonaReadDto, ZonaUpdateDto, int>, ZonaService>();

var app = builder.Build();

// ---------- Pipeline ----------
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();

app.UseAuthentication();
app.UseAuthorization();

// Logout helper
app.MapGet("/logout", () =>
    Results.SignOut(
        new AuthenticationProperties { RedirectUri = "/" },
        new[] { CookieAuthenticationDefaults.AuthenticationScheme, OpenIdConnectDefaults.AuthenticationScheme }
    )
).AllowAnonymous();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();