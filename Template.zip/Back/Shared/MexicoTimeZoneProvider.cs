namespace Xugnux.Juridico.Inmuebles.API.Shared;

public static class MexicoTimeZoneProvider
{
    public static TimeZoneInfo GetMexicoTimeZone()
    {
        try
        {
            return TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time (Mexico)");
        }
        catch
        {
            return TimeZoneInfo.FindSystemTimeZoneById("America/Mexico_City");
        }
    }
}