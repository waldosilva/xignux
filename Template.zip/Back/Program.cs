using System.Data;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.Data.SqlClient;
using Microsoft.Identity.Web;
using Microsoft.IdentityModel.Tokens;
using Xugnux.Juridico.Inmuebles.API.Interfaces;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Colonias;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Destino;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Divisas;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Division;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Empresas;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Estados;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Estatus;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.GirosActividades;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Municipios;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Paises;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Periodo;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.TiposArrendamientos;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.TipoDocumento;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Documento;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.TiposInstalaciones;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Configuraciones.Roles;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Configuraciones.Usuarios;
using Xugnux.Juridico.Inmuebles.API.Services;


var builder = WebApplication.CreateBuilder(args);

// ===== Controllers: [Authorize] global (toda la API protegida por defecto) =====
builder.Services.AddControllers(options =>
{
    var policy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .Build();
    options.Filters.Add(new AuthorizeFilter(policy));
});

// ===== Swagger + Bearer =====
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "Inmuebles API", Version = "v1" });
    c.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        Description = "JWT Bearer. Ej: Bearer {token}",
        Name = "Authorization",
        In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT"
    });
    c.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new Microsoft.OpenApi.Models.OpenApiSecurityScheme
            {
                Reference = new Microsoft.OpenApi.Models.OpenApiReference
                {
                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

// ===== Dapper =====
builder.Services.AddScoped<IDbConnection>(sp =>
    new SqlConnection(builder.Configuration.GetConnectionString("DB")));

// ===== CORS (tal cual lo tenías) =====
builder.Services.AddCors(options =>
{
    options.AddPolicy("CorsPolicy", policy => policy
        .AllowAnyOrigin()
        .AllowAnyMethod()
        .AllowAnyHeader());
});

// ===== Authentication: Entra ID (JWT) =====
// (Recomendado) evita que se remapeen los claims a nombres cortos
JwtSecurityTokenHandler.DefaultMapInboundClaims = false;

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddMicrosoftIdentityWebApi(builder.Configuration.GetSection("AzureAd"));

// ===== Authorization por scope =====
builder.Services.AddAuthorization(options =>
{
    // Política basada en scope emitido por TU API.
    // Tu scope es: api://cea44936-81ea-4a29-b040-2e03be38ca7c/user.impersonate
    // Aquí solo va el nombre del scope:
    options.AddPolicy("ApiScope", policy =>
    {
        policy.RequireAuthenticatedUser();
        policy.RequireScope("user.impersonate");
    });
});

// ===== Controllers: exigir la política (scope) GLOBALMENTE =====
builder.Services.AddControllers(options =>
{
    options.Filters.Add(new AuthorizeFilter("ApiScope"));
});


// ===== Lista blanca de tenants (si usas multi-tenant "organizations") =====
var allowedTenants =
    builder.Configuration.GetSection("AzureAd:AllowedTenants").Get<string[]>() ?? Array.Empty<string>();
if (allowedTenants.Length > 0)
{
    builder.Services.Configure<JwtBearerOptions>(JwtBearerDefaults.AuthenticationScheme, options =>
    {
        options.TokenValidationParameters.ValidateIssuer = true;
        options.TokenValidationParameters.IssuerValidator = (issuer, securityToken, validationParameters) =>
        {
            if (securityToken is JwtSecurityToken jwt)
            {
                var tid = jwt.Claims.FirstOrDefault(c => c.Type == "tid")?.Value;
                if (!string.IsNullOrEmpty(tid) &&
                    allowedTenants.Contains(tid, StringComparer.OrdinalIgnoreCase))
                {
                    return issuer; // issuer permitido
                }
            }

            throw new SecurityTokenInvalidIssuerException("Tenant no permitido.");
        };
    });
}

// Servicios
builder.Services.AddScoped<
    ICrudService<ColoniaCreateDto, ColoniaReadDto, ColoniaUpdateDto, int>,
    ColoniaService>();

builder.Services.AddScoped<
    ICrudService<DestinoCreateDto, DestinoReadDto, DestinoUpdateDto, int>,
    DestinoService>();

builder.Services.AddScoped<
    ICrudService<DivisaCreateDto, DivisaReadDto, DivisaUpdateDto, int>,
    DivisasService>();

builder.Services.AddScoped<
    ICrudService<DivisionCreateDto, DivisionReadDto, DivisionUpdateDto, int>,
    DivisionService>();

builder.Services.AddScoped<
    ICrudService<EmpresaCreateDto, EmpresaReadDto, EmpresaUpdateDto, int>,
    EmpresaService>();

builder.Services.AddScoped<
    ICrudService<EstadoCreateDto, EstadoReadDto, EstadoUpdateDto, int>,
    EstadoService>();

builder.Services.AddScoped<
    ICrudService<EstatusCreateDto, EstatusReadDto, EstatusUpdateDto, int>,
    EstatusService>();

builder.Services.AddScoped<
    ICrudService<GiroActividadCreateDto, GiroActividadReadDto, GiroActividadUpdateDto, int>,
    GiroActividadService>();

builder.Services.AddScoped<
    ICrudService<MunicipioCreateDto, MunicipioReadDto, MunicipioUpdateDto, int>,
    MunicipioService>();

builder.Services.AddScoped<
    ICrudService<PaisCreateDto, PaisReadDto, PaisUpdateDto, int>,
    PaisService>();

builder.Services.AddScoped<
    ICrudService<PeriodoCreateDto, PeriodoReadDto, PeriodoUpdateDto, int>,
    PeriodoService>();

builder.Services.AddScoped<
    ICrudService<RolCreateDto, RolReadDto, RolUpdateDto, int>,
    RolService>();

builder.Services.AddScoped<
    ICrudService<TipoArrendamientoCreateDto, TipoArrendamientoReadDto, TipoArrendamientoUpdateDto, int>,
    TipoArrendamientoService>();

builder.Services.AddScoped<
    ICrudService<TipoDocumentoCreateDto, TipoDocumentoReadDto, TipoDocumentoUpdateDto, int>,
    TipoDocumentoService>();

builder.Services.AddScoped<
    ICrudService<DocumentoCreateDto, DocumentoReadDto, DocumentoUpdateDto, int>,
    DocumentoService>();

builder.Services.AddScoped<
    ICrudService<TipoInstalacionCreateDto, TipoInstalacionReadDto, TipoInstalacionUpdateDto, int>,
    TiposInstalacionService>();

builder.Services.AddScoped<IUsuarioService, UsuarioService>();


var app = builder.Build();

// ===== Pipeline =====
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
else
{
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseCors("CorsPolicy");

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();