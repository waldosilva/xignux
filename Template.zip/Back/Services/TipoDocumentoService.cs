using System.Data;
using System.Text.Json;
using Dapper;
using Xugnux.Juridico.Inmuebles.API.Interfaces;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.TipoDocumento;
using Xugnux.Juridico.Inmuebles.API.Models.Response;
using Xugnux.Juridico.Inmuebles.API.Shared;

namespace Xugnux.Juridico.Inmuebles.API.Services;

public class TipoDocumentoService : ICrudService<TipoDocumentoCreateDto, TipoDocumentoReadDto, TipoDocumentoUpdateDto, int>
{
    private readonly IDbConnection _db;

    public TipoDocumentoService(IDbConnection db)
    {
        _db = db;
    }

    public async Task<BaseResponseModel<PagedResult<TipoDocumentoReadDto>>> GetPagedAsync(PageFilter filter,
        CancellationToken ct = default)
    {
        // Prepara JSON de filtros
        string? filtersJson = null;
        if (filter.ColumnFilters is { Count: > 0 })
        {
            filtersJson = JsonSerializer.Serialize(filter.ColumnFilters);
        }

        // Normaliza sort
        var sortBy = string.IsNullOrWhiteSpace(filter.SortBy) ? "TipoDocumentoId" : filter.SortBy!;
        var sortDir = string.Equals(filter.SortDir, "DESC", StringComparison.OrdinalIgnoreCase) ? "DESC" : "ASC";

        var p = new DynamicParameters();
        p.Add("Page", filter.Page);
        p.Add("PageSize", filter.PageSize);
        p.Add("SortBy", sortBy);
        p.Add("SortDir", sortDir);
        p.Add("Search", string.IsNullOrWhiteSpace(filter.Search) ? null : filter.Search);
        p.Add("ColumnFiltersJson", filtersJson);

        using var multi = await _db.QueryMultipleAsync(
            new CommandDefinition(
                "Catalogo.usp_TipoDocumento_GetPaged",
                p,
                commandType: CommandType.StoredProcedure,
                cancellationToken: ct
            )
        );

        var total = await multi.ReadFirstAsync<int>();
        var items = (await multi.ReadAsync<TipoDocumentoReadDto>()).ToList();

        // Limpia trailing spaces si tus columnas son NCHAR/CHAR
        foreach (var item in items)
        {
            item.Nombre = item.Nombre?.Trim();
            item.Descripcion = item.Descripcion?.Trim();
            item.CatTipoDocumentoNombre = item.CatTipoDocumentoNombre?.Trim();
        }

        var paged = new PagedResult<TipoDocumentoReadDto>
        {
            Items = items,
            TotalCount = total,
            Page = filter.Page,
            PageSize = filter.PageSize,
            SortBy = sortBy,
            SortDir = sortDir
        };

        return BaseResponseModel<PagedResult<TipoDocumentoReadDto>>.Success(
            paged, currentPage: filter.Page, totalRecords: total, pageSize: filter.PageSize
        );
    }

    public async Task<BaseResponseModel<TipoDocumentoReadDto>> GetByIdAsync(int id, CancellationToken ct = default)
    {
        var cmd = new CommandDefinition(
            "Catalogo.SP_TipoDocumento_GetById",
            new { TipoDocumentoId = id },
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct
        );

        var result = await _db.QueryFirstOrDefaultAsync<TipoDocumentoReadDto>(cmd);

        return result is not null
            ? BaseResponseModel<TipoDocumentoReadDto>.Success(result)
            : BaseResponseModel<TipoDocumentoReadDto>.Fail("Registro no encontrado", StatusCodes.Status404NotFound);
    }

    public async Task<int> CreateAsync(TipoDocumentoCreateDto dto, CancellationToken ct = default)
    {
        var nowMexico = TimeZoneInfo.ConvertTime(DateTime.Now, MexicoTimeZoneProvider.GetMexicoTimeZone());

        var p = new DynamicParameters();
        p.Add("Nombre", dto.Nombre);
        p.Add("Descripcion", dto.Descripcion);
        p.Add("CreadoPor", dto.CreadoPor);
        p.Add("ModificadoPor", dto.CreadoPor);
        p.Add("Activo", true);
        p.Add("CatTipoDocumentoId", dto.CatTipoDocumentoId);
        p.Add("TipoDocumentoId", dbType: DbType.Int32, direction: ParameterDirection.Output);

        var cmd = new CommandDefinition(
            commandText: "Catalogo.usp_TipoDocumento_Insert",
            parameters: p,
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct
        );

        await _db.ExecuteAsync(cmd);

        // Id generado
        return p.Get<int>("TipoDocumentoId");
    }

    public async Task<bool> UpdateAsync(int id, TipoDocumentoUpdateDto dto, CancellationToken ct = default)
    {
        var nowMexico = TimeZoneInfo.ConvertTime(DateTime.Now, MexicoTimeZoneProvider.GetMexicoTimeZone());

        var p = new DynamicParameters();
        p.Add("TipoDocumentoId", id);
        p.Add("Nombre", dto.Nombre);
        p.Add("Descripcion", dto.Descripcion);
        p.Add("Activo", dto.Activo);
        p.Add("ModificadoPor", dto.ModificadoPor);
        p.Add("FechaModificacion", nowMexico);
        p.Add("CatTipoDocumentoId", dto.CatTipoDocumentoId);
        p.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);

        var cmd = new CommandDefinition(
            "Catalogo.usp_TipoDocumento_Update",
            p,
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct
        );

        await _db.ExecuteAsync(cmd);

        var result = p.Get<int>("Result");
        switch (result)
        {
            case 1:
                return true; // actualizado
            case 0:
                return false; // no existe TipoDocumentoId
            case -1:
                throw new InvalidOperationException("No se pudo actualizar: CatTipoDocumentoId inválido o violación de FK.");
            case -2:
                throw new InvalidOperationException("No se pudo actualizar: conflicto de duplicidad (índice único).");
            default:
                return false; // otros códigos si decides usarlos (-3, etc.)
        }
    }

    public async Task<bool> DeleteAsync(int id, CancellationToken ct = default)
    {
        var p = new DynamicParameters();
        p.Add("TipoDocumentoId", id, DbType.Int32);
        p.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);

        var cmd = new CommandDefinition(
            "Catalogo.usp_TipoDocumento_Delete",
            p,
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct
        );

        await _db.ExecuteAsync(cmd);

        var result = p.Get<int>("Result");

        if (result == -1)
            throw new InvalidOperationException("No se puede eliminar: el tipo de documento tiene dependencias (FK).");

        return result > 0; // true si se eliminó; false si no existía
    }
}