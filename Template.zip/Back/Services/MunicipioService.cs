using System.Data;
using System.Text.Json;
using Dapper;
using Xugnux.Juridico.Inmuebles.API.Interfaces;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Municipios;
using Xugnux.Juridico.Inmuebles.API.Models.Response;
using Xugnux.Juridico.Inmuebles.API.Shared;

namespace Xugnux.Juridico.Inmuebles.API.Services;

public class MunicipioService : ICrudService<MunicipioCreateDto, MunicipioReadDto, MunicipioUpdateDto, int>
{
    private readonly IDbConnection _db;

    public MunicipioService(IDbConnection db)
    {
        _db = db;
    }
    public async Task<BaseResponseModel<PagedResult<MunicipioReadDto>>> GetPagedAsync(PageFilter filter,
        CancellationToken ct = default)
    {
        // Prepara JSON de filtros
        string? filtersJson = null;
        if (filter.ColumnFilters is { Count: > 0 })
        {
            // Por ejemplo: { "MunicipioNombre":"centro", "MunicipioNombre":"nuevo leon" }
            filtersJson = JsonSerializer.Serialize(filter.ColumnFilters);
        }

        // Normaliza sort
        var sortBy = string.IsNullOrWhiteSpace(filter.SortBy) ? "MunicipioId" : filter.SortBy!;
        var sortDir = string.Equals(filter.SortDir, "DESC", StringComparison.OrdinalIgnoreCase) ? "DESC" : "ASC";

        var p = new DynamicParameters();
        p.Add("Page", filter.Page);
        p.Add("PageSize", filter.PageSize);
        p.Add("SortBy", sortBy);
        p.Add("SortDir", sortDir);
        p.Add("Search", string.IsNullOrWhiteSpace(filter.Search) ? null : filter.Search);
        p.Add("ColumnFiltersJson", filtersJson);

        using var multi = await _db.QueryMultipleAsync(
            new CommandDefinition(
                "Catalogo.usp_Municipio_GetPaged",
                p,
                commandType: CommandType.StoredProcedure,
                cancellationToken: ct
            )
        );

        var total = await multi.ReadFirstAsync<int>();
        var items = (await multi.ReadAsync<MunicipioReadDto>()).ToList();

        // Limpia trailing spaces si tus columnas son NCHAR/CHAR
        foreach (var item in items)
        {
            item.Descripcion = item.Descripcion?.Trim();
            item.EstadoNombre = item.EstadoNombre?.Trim();
        }

        var paged = new PagedResult<MunicipioReadDto>
        {
            Items = items,
            TotalCount = total,
            Page = filter.Page,
            PageSize = filter.PageSize,
            SortBy = sortBy,
            SortDir = sortDir
        };

        return BaseResponseModel<PagedResult<MunicipioReadDto>>.Success(
            paged, currentPage: filter.Page, totalRecords: total, pageSize: filter.PageSize
        );
    }

    public async Task<BaseResponseModel<MunicipioReadDto>> GetByIdAsync(int id, CancellationToken ct = default)
    {
        var cmd = new CommandDefinition(
            "Catalogo.usp_Municipio_GetById",
            new { MunicipioId = id },
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct
        );

        var result = await _db.QueryFirstOrDefaultAsync<MunicipioReadDto>(cmd);

        return result is not null
            ? BaseResponseModel<MunicipioReadDto>.Success(result)
            : BaseResponseModel<MunicipioReadDto>.Fail("Municipio no encontrada", StatusCodes.Status404NotFound);
    }

    public async Task<int> CreateAsync(MunicipioCreateDto dto, CancellationToken ct = default)
    {
        var nowMexico = TimeZoneInfo.ConvertTime(DateTime.Now, MexicoTimeZoneProvider.GetMexicoTimeZone());

        var p = new DynamicParameters();
        p.Add("EstadoId", dto.EstadoId);
        p.Add("Descripcion", dto.Descripcion);
        p.Add("CreadoPor", dto.CreadoPor);
        p.Add("FechaCreacion", nowMexico);
        p.Add("FechaModificacion", nowMexico);
        p.Add("MunicipioId", dbType: DbType.Int32, direction: ParameterDirection.Output);

        var cmd = new CommandDefinition(
            commandText: "Catalogo.usp_Municipio_Insert",
            parameters: p,
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct
        );

        await _db.ExecuteAsync(cmd);

        // Id generado
        return p.Get<int>("MunicipioId");
    }

    public async Task<bool> UpdateAsync(int id, MunicipioUpdateDto dto, CancellationToken ct = default)
    {
        var nowMexico = TimeZoneInfo.ConvertTime(DateTime.Now, MexicoTimeZoneProvider.GetMexicoTimeZone());

        var p = new DynamicParameters();
        p.Add("MunicipioId", id);
        p.Add("EstadoId", dto.EstadoId);
        p.Add("Descripcion", dto.Descripcion);
        p.Add("ModificadoPor", dto.ModificadoPor);
        p.Add("FechaModificacion", nowMexico);
        p.Add("Activo", dto.Activo);
        p.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);

        var cmd = new CommandDefinition(
            "Catalogo.usp_Municipio_Update",
            p,
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct
        );

        await _db.ExecuteAsync(cmd);

        var result = p.Get<int>("Result");
        switch (result)
        {
            case 1:
                return true; // actualizado
            case 0:
                return false; // no existe MunicipioId
            case -1:
                throw new InvalidOperationException("No se pudo actualizar: EstadoId inválido o violación de FK.");
            case -2:
                throw new InvalidOperationException("No se pudo actualizar: conflicto de duplicidad (índice único).");
            default:
                return false; // otros códigos si decides usarlos (-3, etc.)
        }
    }

    public async Task<bool> DeleteAsync(int id, CancellationToken ct = default)
    {
        var p = new DynamicParameters();
        p.Add("MunicipioId", id, DbType.Int32);
        p.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);

        var cmd = new CommandDefinition(
            "Catalogo.usp_Municipio_Delete",
            p,
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct
        );

        await _db.ExecuteAsync(cmd);

        var result = p.Get<int>("Result");

        if (result == -1)
            throw new InvalidOperationException("No se puede eliminar: el Municipio tiene dependencias (FK).");

        return result > 0; // true si se eliminó; false si no existía
    }
}