using System.Data;
using System.Text.Json;
using Dapper;
using Xugnux.Juridico.Inmuebles.API.Interfaces;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Colonias;
using Xugnux.Juridico.Inmuebles.API.Models.Response;
using Xugnux.Juridico.Inmuebles.API.Shared;

namespace Xugnux.Juridico.Inmuebles.API.Services;

public class ColoniaService : ICrudService<ColoniaCreateDto, ColoniaReadDto, ColoniaUpdateDto, int>
{
    private readonly IDbConnection _db;

    public ColoniaService(IDbConnection db)
    {
        _db = db;
    }

    public async Task<BaseResponseModel<PagedResult<ColoniaReadDto>>> GetPagedAsync(PageFilter filter,
        CancellationToken ct = default)
    {
        // Prepara JSON de filtros
        string? filtersJson = null;
        if (filter.ColumnFilters is { Count: > 0 })
        {
            // Por ejemplo: { "ColoniaNombre":"centro", "EstadoNombre":"nuevo leon" }
            filtersJson = JsonSerializer.Serialize(filter.ColumnFilters);
        }

        // Normaliza sort
        var sortBy = string.IsNullOrWhiteSpace(filter.SortBy) ? "ColoniaId" : filter.SortBy!;
        var sortDir = string.Equals(filter.SortDir, "DESC", StringComparison.OrdinalIgnoreCase) ? "DESC" : "ASC";

        var p = new DynamicParameters();
        p.Add("Page", filter.Page);
        p.Add("PageSize", filter.PageSize);
        p.Add("SortBy", sortBy);
        p.Add("SortDir", sortDir);
        p.Add("Search", string.IsNullOrWhiteSpace(filter.Search) ? null : filter.Search);
        p.Add("ColumnFiltersJson", filtersJson);

        using var multi = await _db.QueryMultipleAsync(
            new CommandDefinition(
                "Catalogo.usp_Colonia_GetPaged",
                p,
                commandType: CommandType.StoredProcedure,
                cancellationToken: ct
            )
        );

        var total = await multi.ReadFirstAsync<int>();
        var items = (await multi.ReadAsync<ColoniaReadDto>()).ToList();

        // Limpia trailing spaces si tus columnas son NCHAR/CHAR
        foreach (var item in items)
        {
            item.ColoniaNombre = item.ColoniaNombre?.Trim();
            item.MunicipioNombre = item.MunicipioNombre?.Trim();
            item.EstadoNombre = item.EstadoNombre?.Trim();
            item.PaisNombre = item.PaisNombre?.Trim();
        }

        var paged = new PagedResult<ColoniaReadDto>
        {
            Items = items,
            TotalCount = total,
            Page = filter.Page,
            PageSize = filter.PageSize,
            SortBy = sortBy,
            SortDir = sortDir
        };

        return BaseResponseModel<PagedResult<ColoniaReadDto>>.Success(
            paged, currentPage: filter.Page, totalRecords: total, pageSize: filter.PageSize
        );
    }

    public async Task<BaseResponseModel<ColoniaReadDto>> GetByIdAsync(int id, CancellationToken ct = default)
    {
        var cmd = new CommandDefinition(
            "Catalogo.usp_Colonia_GetById",
            new { ColoniaId = id },
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct
        );

        var result = await _db.QueryFirstOrDefaultAsync<ColoniaReadDto>(cmd);

        return result is not null
            ? BaseResponseModel<ColoniaReadDto>.Success(result)
            : BaseResponseModel<ColoniaReadDto>.Fail("Registro no encontrado", StatusCodes.Status404NotFound);
    }

    public async Task<int> CreateAsync(ColoniaCreateDto dto, CancellationToken ct = default)
    {
        var nowMexico = TimeZoneInfo.ConvertTime(DateTime.Now, MexicoTimeZoneProvider.GetMexicoTimeZone());

        var p = new DynamicParameters();
        p.Add("Codigo", dto.Codigo);
        p.Add("CodigoPostal", dto.CodigoPostal);
        p.Add("Descripcion", dto.Descripcion);
        p.Add("MunicipioId", dto.MunicipioId);
        p.Add("CreadoPor", dto.CreadoPor);
        p.Add("FechaCreacion", nowMexico);
        p.Add("FechaModificacion", nowMexico);
        p.Add("ColoniaId", dbType: DbType.Int32, direction: ParameterDirection.Output);

        var cmd = new CommandDefinition(
            commandText: "Catalogo.usp_Colonia_Insert",
            parameters: p,
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct
        );

        await _db.ExecuteAsync(cmd);

        // Id generado
        return p.Get<int>("ColoniaId");
    }

    public async Task<bool> UpdateAsync(int id, ColoniaUpdateDto dto, CancellationToken ct = default)
    {
        var nowMexico = TimeZoneInfo.ConvertTime(DateTime.Now, MexicoTimeZoneProvider.GetMexicoTimeZone());

        var p = new DynamicParameters();
        p.Add("ColoniaId", id);
        p.Add("Codigo", dto.Codigo);
        p.Add("CodigoPostal", dto.CodigoPostal);
        p.Add("Descripcion", dto.Descripcion);
        p.Add("MunicipioId", dto.MunicipioId);
        p.Add("Activo", dto.Activo);
        p.Add("ModificadoPor", dto.ModificadoPor);
        p.Add("FechaModificacion", nowMexico);
        p.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);

        var cmd = new CommandDefinition(
            "Catalogo.usp_Colonia_Update",
            p,
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct
        );

        await _db.ExecuteAsync(cmd);

        var result = p.Get<int>("Result");
        switch (result)
        {
            case 1:
                return true; // actualizado
            case 0:
                return false; // no existe ColoniaId
            case -1:
                throw new InvalidOperationException("No se pudo actualizar: MunicipioId inválido o violación de FK.");
            case -2:
                throw new InvalidOperationException("No se pudo actualizar: conflicto de duplicidad (índice único).");
            default:
                return false; // otros códigos si decides usarlos (-3, etc.)
        }
    }

    public async Task<bool> DeleteAsync(int id, CancellationToken ct = default)
    {
        var p = new DynamicParameters();
        p.Add("ColoniaId", id, DbType.Int32);
        p.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);

        var cmd = new CommandDefinition(
            "Catalogo.usp_Colonia_Delete",
            p,
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct
        );

        await _db.ExecuteAsync(cmd);

        var result = p.Get<int>("Result");

        if (result == -1)
            throw new InvalidOperationException("No se puede eliminar: la colonia tiene dependencias (FK).");

        return result > 0; // true si se eliminó; false si no existía
    }
}