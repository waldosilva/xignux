using Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Colonias;
using Xugnux.Juridico.Inmuebles.API.Models.Response;

namespace Xugnux.Juridico.Inmuebles.API.Interfaces;

public interface ICrudService<TCreateDto, TReadDto, TUpdateDto, TKey>
{
    Task<BaseResponseModel<PagedResult<TReadDto>>> GetPagedAsync(PageFilter filter,
        CancellationToken ct = default);
    Task<BaseResponseModel<TReadDto>> GetByIdAsync(TKey id, CancellationToken ct = default);
    Task<TKey> CreateAsync(TCreateDto dto, CancellationToken ct = default);
    Task<bool> UpdateAsync(TKey id, TUpdateDto dto, CancellationToken ct = default);
    Task<bool> DeleteAsync(TKey id, CancellationToken ct = default);
}
