using Xugnux.Juridico.Inmuebles.API.Models.Dto.Configuraciones.Usuarios;
using Xugnux.Juridico.Inmuebles.API.Models.Response;

namespace Xugnux.Juridico.Inmuebles.API.Interfaces;

public interface IUsuarioService 
    : ICrudService<UsuarioCreateDto, UsuarioReadDto, UsuarioUpdateDto, int>
{
    Task<BaseResponseModel<UsuarioReadDto?>> GetByEmailAsync(string email, CancellationToken ct = default);
}