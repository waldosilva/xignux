using Microsoft.AspNetCore.Mvc;
using Xugnux.Juridico.Inmuebles.API.Interfaces;
using Xugnux.Juridico.Inmuebles.API.Models.Dto.Configuraciones.Roles;
using Xugnux.Juridico.Inmuebles.API.Models.Response;

namespace Xugnux.Juridico.Inmuebles.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RolController : ControllerBase
    {
        private readonly ICrudService<RolCreateDto, RolReadDto, RolUpdateDto, int> _service;

        public RolController(ICrudService<RolCreateDto, RolReadDto, RolUpdateDto, int> service)
        {
            _service = service;
        }

        [HttpPost("buscar")]
        public async Task<ActionResult<BaseResponseModel<PagedResult<RolReadDto>>>> GetPaged([FromBody] PageFilter filter, CancellationToken ct)
        {
            filter.Page = filter.Page <= 0 ? 1 : filter.Page;
            filter.PageSize = filter.PageSize <= 0 ? 10 : filter.PageSize;
            filter.SortDir = string.IsNullOrWhiteSpace(filter.SortDir) || filter.SortDir == "" || filter.SortDir == "string" ? "ASC" : filter.SortDir.ToUpper();
            filter.SortBy = string.IsNullOrWhiteSpace(filter.SortBy) || filter.SortBy == "" || filter.SortBy == "string" ? "RolId" : filter.SortBy;
            filter.Search = string.IsNullOrWhiteSpace(filter.Search) || filter.Search == "" || filter.Search == "string" ? "" : filter.Search;

            var result = await _service.GetPagedAsync(filter, ct);
            return Ok(result);
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<BaseResponseModel<RolReadDto>>> GetById(int id, CancellationToken ct)
        {
            var result = await _service.GetByIdAsync(id, ct);
            return StatusCode(result.StatusCode, result);
        }


        [HttpPost]
        public async Task<IActionResult> Create([FromBody] RolCreateDto dto, CancellationToken ct)
        {
            var id = await _service.CreateAsync(dto, ct);
            return CreatedAtAction(nameof(GetById), new { id }, id);
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] RolUpdateDto dto, CancellationToken ct)
        {
            var success = await _service.UpdateAsync(id, dto, ct);
            return success ? NoContent() : NotFound();
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id, CancellationToken ct)
        {
            var success = await _service.DeleteAsync(id, ct);
            return success ? NoContent() : NotFound();
        }
    }
}
