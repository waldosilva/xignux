namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.TiposMovimientos;

public class TipoMovimientoCreateDto
{
    public string Nombre { get; set; } = null!;
    public string Descripcion { get; set; } = null!;
    public string CreadoPor { get; set; } = null!;
}