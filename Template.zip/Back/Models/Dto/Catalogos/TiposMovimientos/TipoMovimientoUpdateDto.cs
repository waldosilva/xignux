namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.TiposMovimientos;

public class TipoMovimientoUpdateDto
{
    public int TipoMovimientoId { get; set; }
    public string Nombre { get; set; } = null!;
    public string Descripcion { get; set; } = null!;
    public string ModificadoPor { get; set; } = null!;
    public bool Activo { get; set; }
}