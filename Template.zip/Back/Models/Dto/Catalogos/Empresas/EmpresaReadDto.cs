using Xugnux.Juridico.Inmuebles.API.Models.Request;

namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Empresas;

public class EmpresaReadDto : BaseRequestModel
{
    public int EmpresaId { get; set; }

    public int DivisionId { get; set; }

    public string DivisionNombre { get; set; } = null!;
    
    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;

    public string? UrlImg { get; set; }
}