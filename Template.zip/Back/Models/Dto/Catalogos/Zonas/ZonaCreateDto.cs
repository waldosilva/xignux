namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Zonas;

public class ZonaCreateDto
{
    public int? DivisionId { get; set; }
    public string? Descripcion { get; set; }
    public string CreadoPor { get; set; } = null!;
}