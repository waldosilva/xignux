namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Zonas;

public class ZonaUpdateDto
{
    public int ZonaId { get; set; }
    public int? DivisionId { get; set; }
    public string? Descripcion { get; set; }
    public string ModificadoPor { get; set; } = null!;
    public bool Activo { get; set; }
}