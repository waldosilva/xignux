using Xugnux.Juridico.Inmuebles.API.Models.Request;

namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Zonas;

public class ZonaReadDto : BaseRequestModel
{
    public int ZonaId { get; set; }
    public int? DivisionId { get; set; }
    public string? Descripcion { get; set; }
}