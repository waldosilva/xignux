namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.TiposArrendamientos;

public class TipoArrendamientoCreateDto
{
    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;

    public string CreadoPor { get; set; } = null!;
}