using Xugnux.Juridico.Inmuebles.API.Models.Request;

namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.TipoDocumento;

public class TipoDocumentoReadDto : BaseRequestModel
{
    public int TipoDocumentoId { get; set; }
    public string Nombre { get; set; } = null!;
    public string Descripcion { get; set; } = null!;
    public int? CatTipoDocumentoId { get; set; }
    public string? CatTipoDocumentoNombre { get; set; }
}