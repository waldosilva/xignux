namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.GirosActividades;

public class GiroActividadCreateDto
{
    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;

    public string CreadoPor { get; set; } = null!;
}