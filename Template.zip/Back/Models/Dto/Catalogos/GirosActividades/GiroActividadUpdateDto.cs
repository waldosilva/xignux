namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.GirosActividades;

public class GiroActividadUpdateDto
{
    public int GiroActividadId { get; set; }

    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;

    public string ModificadoPor { get; set; } = null!;

    public bool Activo { get; set; }
}