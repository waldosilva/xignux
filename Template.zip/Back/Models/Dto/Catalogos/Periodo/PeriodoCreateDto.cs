namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Periodo;

public class PeriodoCreateDto
{
    public string? Descripcion { get; set; }
    public string CreadoPor { get; set; } = null!;
}