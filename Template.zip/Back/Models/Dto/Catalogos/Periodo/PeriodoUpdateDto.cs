namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Periodo;

public class PeriodoUpdateDto
{
    public int PeriodoId { get; set; }
    public string Descripcion { get; set; } = null!;
    public bool Activo { get; set; }
    public string ModificadoPor { get; set; } = null!;
}