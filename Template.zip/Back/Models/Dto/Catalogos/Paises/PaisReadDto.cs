using Xugnux.Juridico.Inmuebles.API.Models.Request;

namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Paises;

public class PaisReadDto : BaseRequestModel
{
    public int PaisId { get; set; }

    public string? Codigo { get; set; }

    public string? Descripcion { get; set; }
}