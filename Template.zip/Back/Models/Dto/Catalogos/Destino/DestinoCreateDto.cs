namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Destino;

public class DestinoCreateDto
{
    public int DestinoId { get; set; }

    public string Descripcion { get; set; } = null!;
    
    public string CreadoPor { get; set; } = null!;
}