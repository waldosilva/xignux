using Xugnux.Juridico.Inmuebles.API.Models.Request;

namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Destino;

public class DestinoReadDto : BaseRequestModel
{
    public int DestinoId { get; set; }

    public string Descripcion { get; set; } = null!;
}