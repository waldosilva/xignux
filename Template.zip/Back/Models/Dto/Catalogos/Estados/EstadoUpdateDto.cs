namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Estados;

public class EstadoUpdateDto
{
    public int EstadoId { get; set; }
    public int PaisId { get; set; }
    public string? Codigo { get; set; }
    public string? Descripcion { get; set; }
    public string? ModificadoPor { get; set; }
    public bool Activo { get; set; }
}