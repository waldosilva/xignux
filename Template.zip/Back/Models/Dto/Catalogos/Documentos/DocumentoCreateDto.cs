namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Documentos;

public class DocumentoCreateDto
{
    public string Codigo { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public int TipoDocumentoId { get; set; }
    public bool Vigencia { get; set; }
    public bool Recurrencia { get; set; }
    public bool VigenciaOpcional { get; set; }
    public int? CriticidadDocID { get; set; }
    public string CreadoPor { get; set; } = string.Empty;
}