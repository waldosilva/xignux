using Xugnux.Juridico.Inmuebles.API.Models.Request;

namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Municipios;

public class MunicipioReadDto : BaseRequestModel
{
    public int MunicipioId { get; set; }
    public string? Descripcion { get; set; }
    
    public int EstadoId { get; set; }
    public string? EstadoNombre { get; set; }
    
    public int PaisId { get; set; }
    public string? PaisNombre { get; set; }
    
}