using Xugnux.Juridico.Inmuebles.API.Models.Request;

namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Colonias;

public class ColoniaReadDto : BaseRequestModel
{
    public int ColoniaId          { get; set; }
    public string? Codigo         { get; set; }
    public string ColoniaNombre    { get; set; } = default!;
    public string? CodigoPostal    { get; set; }
    public int    MunicipioId      { get; set; }
    public string MunicipioNombre  { get; set; } = default!;
    public int    EstadoId      { get; set; }
    public string EstadoNombre     { get; set; } = default!;
    public int    PaisId      { get; set; }
    public string PaisNombre       { get; set; } = default!;
    public bool Activo             { get; set; }
}