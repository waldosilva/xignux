namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Colonias;

public class ColoniaUpdateDto
{
    public int MunicipioId { get; set; }
    public string Codigo { get; set; } = null!;
    public string CodigoPostal { get; set; } = null!;
    public string Descripcion { get; set; } = null!;
    public bool Activo { get; set; }
    public string ModificadoPor { get; set; } = null!;

}