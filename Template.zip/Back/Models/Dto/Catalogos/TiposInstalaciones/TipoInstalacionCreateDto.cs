namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.TiposInstalaciones;

public class TipoInstalacionCreateDto
{
    public string Codigo { get; set; } = null!;
    public string Descripcion { get; set; } = null!;
    public string CreadoPor { get; set; } = null!;
}