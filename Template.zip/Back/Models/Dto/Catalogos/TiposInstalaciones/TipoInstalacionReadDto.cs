using Xugnux.Juridico.Inmuebles.API.Models.Request;

namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.TiposInstalaciones;

public class TipoInstalacionReadDto : BaseRequestModel
{
    public int TipoInstalacionId { get; set; }

    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;
    public bool Activo { get; set; }
}