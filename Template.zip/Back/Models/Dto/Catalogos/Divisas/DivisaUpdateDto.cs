namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Divisas;

public class DivisaUpdateDto
{
    public int DivisaId { get; set; }
    public string Descripcion { get; set; } = null!;
    public bool Activo { get; set; }
    public string ModificadoPor { get; set; } = null!;
}