using Xugnux.Juridico.Inmuebles.API.Models.Request;

namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Divisas;

public class DivisaReadDto : BaseRequestModel
{
    public int DivisaId { get; set; }

    public string? Descripcion { get; set; }
}