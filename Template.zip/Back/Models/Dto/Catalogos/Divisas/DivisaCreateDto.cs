namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Divisas;

public class DivisaCreateDto
{
    public string? Descripcion { get; set; }
    public string CreadoPor { get; set; } = null!;
}