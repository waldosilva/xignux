using Xugnux.Juridico.Inmuebles.API.Models.Request;

namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Estatus;

public class EstatusReadDto : BaseRequestModel
{
    public int EstatusId { get; set; }

    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;
}