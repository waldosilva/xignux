namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Estatus;

public class EstatusUpdateDto
{
    public int EstatusId { get; set; }
    public string Codigo { get; set; } = null!;
    public string Descripcion { get; set; } = null!;
    public bool Activo { get; set; }
    public string ModificadoPor { get; set; } = null!;
}