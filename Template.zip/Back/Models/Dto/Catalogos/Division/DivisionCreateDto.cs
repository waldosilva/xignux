namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Division;

public class DivisionCreateDto
{
    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;
    
    public string? UrlImg { get; set; }
    
    public string CreadoPor { get; set; } = null!;
}