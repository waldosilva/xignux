using Xugnux.Juridico.Inmuebles.API.Models.Request;

namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.Division;

public class DivisionReadDto : BaseRequestModel
{
    public int DivisionId { get; set; }

    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;
    
    public string? UrlImg { get; set; }
}