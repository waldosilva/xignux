namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.TiposDocumentos;

public class TipoDocumentoUpdateDto
{
    public int TipoDocumentoId { get; set; }
    public string Nombre { get; set; } = null!;
    public string Descripcion { get; set; } = null!;
    public bool Activo { get; set; }
    public string ModificadoPor { get; set; } = null!;
    public int? CatTipoDocumentoId { get; set; }
}