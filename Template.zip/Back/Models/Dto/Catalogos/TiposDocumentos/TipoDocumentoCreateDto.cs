namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Catalogos.TiposDocumentos;

public class TipoDocumentoCreateDto
{
    public string Nombre { get; set; } = null!;
    public string Descripcion { get; set; } = null!;
    public string CreadoPor { get; set; } = null!;
    public int? CatTipoDocumentoId { get; set; }
}