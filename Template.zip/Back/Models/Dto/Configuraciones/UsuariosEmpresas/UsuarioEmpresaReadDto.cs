using Xugnux.Juridico.Inmuebles.API.Models.Request;

namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Configuraciones.UsuariosEmpresas;

public class UsuarioEmpresaReadDto : BaseRequestModel
{
    public int UsuarioEmpresaId { get; set; }

    public int UsuarioId { get; set; }

    public int EmpresaId { get; set; }
    
    public string? EmpresaNombre { get; set; }
}