namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Configuraciones.UsuariosEmpresas;

public class UsuarioEmpresaCreateDto
{
    public int UsuarioId { get; set; }

    public int EmpresaId { get; set; }

    public string CreadoPor { get; set; } = null!;
}