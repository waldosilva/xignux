namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Configuraciones.UsuariosEmpresas;

public class UsuarioEmpresaUpdateDto
{
    public int UsuarioEmpresaId { get; set; }

    public int UsuarioId { get; set; }

    public int EmpresaId { get; set; }
    
    public string ModificadoPor { get; set; } = null!;
    
    public bool Activo { get; set; }
}