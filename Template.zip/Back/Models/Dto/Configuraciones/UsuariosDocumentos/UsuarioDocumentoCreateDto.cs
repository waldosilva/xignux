namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Configuraciones.UsuariosDocumentos;

public class UsuarioDocumentoCreateDto
{
    public int? UsuarioId { get; set; }

    public int? DocumentoId { get; set; }
}