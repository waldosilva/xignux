namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Configuraciones.UsuariosDocumentos;

public class UsuarioDocumentoUpdateDto
{
    public int UsuarioDocumentoId { get; set; }

    public int? UsuarioId { get; set; }

    public int? DocumentoId { get; set; }
}