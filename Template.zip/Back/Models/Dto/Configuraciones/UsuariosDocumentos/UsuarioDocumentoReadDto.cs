namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Configuraciones.UsuariosDocumentos;

public class UsuarioDocumentoReadDto
{
    public int UsuarioDocumentoId { get; set; }

    public int? UsuarioId { get; set; }

    public int? DocumentoId { get; set; }
    
    public string? DocumentoNombre { get; set; }
}