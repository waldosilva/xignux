using Xugnux.Juridico.Inmuebles.API.Models.Request;

namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Configuraciones.Usuarios;

public class UsuarioReadDto : BaseRequestModel
{
    public int UsuarioId { get; set; }

    public string? UsuarioNt { get; set; }

    public string Email { get; set; } = null!;

    public int EmpresaId { get; set; }

    public int RolId { get; set; }
    
    public string? EmpCode { get; set; }
}