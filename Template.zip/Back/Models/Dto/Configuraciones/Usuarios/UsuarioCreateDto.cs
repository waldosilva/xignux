namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Configuraciones.Usuarios;

public class UsuarioCreateDto
{
    public string? UsuarioNt { get; set; }

    public string Email { get; set; } = null!;

    public int EmpresaId { get; set; }

    public string ApellidoPaterno { get; set; } = null!;

    public string? ApellidoMaterno { get; set; }

    public string Nombre { get; set; } = null!;

    public int RolId { get; set; }
    
    public string? EmpCode { get; set; }
    
    public string CreadoPor { get; set; } = null!;
}