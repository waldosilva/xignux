namespace Xugnux.Juridico.Inmuebles.API.Models.Dto.Configuraciones.Usuarios;

public class UsuarioUpdateDto
{
    public int UsuarioId { get; set; }
    public string Email { get; set; } = null!;
    public int EmpresaId { get; set; }
    public int RolId { get; set; }
    public string? EmpCode { get; set; }
    public string ModificadoPor { get; set; } = null!;
    public bool Activo { get; set; }
}