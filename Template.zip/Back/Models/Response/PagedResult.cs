namespace Xugnux.Juridico.Inmuebles.API.Models.Response;

public sealed class PagedResult<T>
{
    public required IReadOnlyList<T> Items { get; init; }
    public required int TotalCount { get; init; }
    public required int Page { get; init; } = 1;
    public required int PageSize { get; init; } = 10;
    public required string SortBy { get; init; }
    public required string SortDir { get; init; } = "ASC";
    public int TotalPages => (int)Math.Ceiling((double)TotalCount / PageSize);
}