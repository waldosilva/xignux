namespace Xugnux.Juridico.Inmuebles.API.Models.Response;

public sealed class BaseResponseModel<T>
{
    public int StatusCode { get; init; }
    public string Message { get; init; } = string.Empty;
    public T? Payload { get; init; }


    public static BaseResponseModel<T> Success(
        T? payload,
        string message = "OK",
        int statusCode = StatusCodes.Status200OK,
        int? currentPage = null,
        int? totalRecords = null,
        int? pageSize = null)
    {
        int? totalPages = null;

        if (totalRecords is >= 0 && pageSize is > 0)
        {
            var n = totalRecords.Value;
            var d = pageSize.Value;
            totalPages = (n + d - 1) / d;
        }

        return new BaseResponseModel<T>
        {
            StatusCode = statusCode,
            Message = string.IsNullOrWhiteSpace(message) ? "OK" : message,
            Payload = payload
        };
    }

    public static BaseResponseModel<T> Fail(
        string message,
        int statusCode = StatusCodes.Status400BadRequest)
    {
        return new BaseResponseModel<T>
        {
            StatusCode = statusCode,
            Message = string.IsNullOrWhiteSpace(message) ? "Error" : message,
            Payload = default
        };
    }
}