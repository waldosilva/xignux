namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmueblesEmpleados20231122
{
    public string? EmpCode { get; set; }

    public string? UsuarioId { get; set; }

    public string? UsuarioNt { get; set; }

    public string? Email { get; set; }

    public string? EmpresaId { get; set; }

    public string? ApellidoPaterno { get; set; }

    public string? ApellidoMaterno { get; set; }

    public string? Nombre { get; set; }

    public string? RolId { get; set; }

    public string? CreadoPor { get; set; }

    public string? FechaCreacion { get; set; }

    public string? ModificadoPor { get; set; }

    public string? FechaModificacion { get; set; }

    public string? Activo { get; set; }
}