namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TipoDocumento
{
    public int TipoDocumentoId { get; set; }

    public string Nombre { get; set; } = null!;

    public string Descripcion { get; set; } = null!;

    public string CreadoPor { get; set; } = null!;

    public DateTime FechaCreacion { get; set; }

    public string ModificadoPor { get; set; } = null!;

    public DateTime FechaModificacion { get; set; }

    public bool Activo { get; set; }

    public int? CatTipoDocumentoId { get; set; }

    public virtual CatTipoDocumento? CatTipoDocumento { get; set; }

    public virtual ICollection<Documento> Documentos { get; set; } = new List<Documento>();
}