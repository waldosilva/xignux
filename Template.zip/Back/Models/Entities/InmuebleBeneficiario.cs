namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmuebleBeneficiario
{
    public long InmuebleBeneficiarioId { get; set; }

    public long InmuebleId { get; set; }

    public string NombreBeneficiario { get; set; } = null!;

    public DateTime FechaInsercion { get; set; }
}