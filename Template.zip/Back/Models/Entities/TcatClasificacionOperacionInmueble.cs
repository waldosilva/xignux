namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TcatClasificacionOperacionInmueble
{
    public int IdTcatClasificacionOperacionInmueble { get; set; }

    public int IdTcatOperacionTipoInmueble { get; set; }

    public string? NombreCorto { get; set; }

    public string? Descripcion { get; set; }
}