namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TablaDePaso
{
    public int Id { get; set; }

    public int UsuarioId { get; set; }

    public int ArchivoCargaId { get; set; }

    public string? Col01 { get; set; }

    public string? Col02 { get; set; }

    public string? Col03 { get; set; }

    public string? Col04 { get; set; }

    public string? Col05 { get; set; }

    public string? Col06 { get; set; }

    public string? Col07 { get; set; }

    public string? Col08 { get; set; }

    public string? Col09 { get; set; }

    public string? Col10 { get; set; }

    public string? Col11 { get; set; }

    public string? Col12 { get; set; }

    public string? Col13 { get; set; }

    public string? Col14 { get; set; }

    public string? Col15 { get; set; }

    public string? Col16 { get; set; }

    public string? Col17 { get; set; }

    public string? Col18 { get; set; }

    public string? Col19 { get; set; }

    public string? Col20 { get; set; }

    public string? Col21 { get; set; }

    public string? Col22 { get; set; }

    public string? Col23 { get; set; }

    public string? Col24 { get; set; }

    public string? Col25 { get; set; }

    public string? Col26 { get; set; }

    public string? Col27 { get; set; }

    public string? Col28 { get; set; }

    public string? Col29 { get; set; }

    public string? Col30 { get; set; }

    public string? Col31 { get; set; }

    public string? Col32 { get; set; }

    public string? Col33 { get; set; }

    public string? Col34 { get; set; }

    public string? Col35 { get; set; }

    public string? Col36 { get; set; }

    public string? Col37 { get; set; }

    public string? Col38 { get; set; }

    public string? Col39 { get; set; }

    public string? Col40 { get; set; }

    public string? Col41 { get; set; }

    public string? Col42 { get; set; }

    public string? Col43 { get; set; }

    public string? Col44 { get; set; }

    public string? Col45 { get; set; }

    public string? Col46 { get; set; }

    public string? Col47 { get; set; }

    public string? Col48 { get; set; }

    public string? Col49 { get; set; }

    public string? Col50 { get; set; }
}