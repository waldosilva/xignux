namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class DocumentosExcel
{
    public string? Nombre { get; set; }

    public decimal? Criticidad { get; set; }
}