namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class SeguimientosP
{
    public Guid InmuebleId { get; set; }

    public Guid InmueblePropioSeguimientoId { get; set; }

    public Guid? InmueblePropioId { get; set; }

    public bool? Completado { get; set; }

    public int Estatus { get; set; }

    public DateTime? FechaVigencia { get; set; }

    public string Contrato { get; set; } = null!;

    public decimal Costo { get; set; }

    public string Divisa { get; set; } = null!;

    public string Periodo { get; set; } = null!;

    public string Empresa { get; set; } = null!;
}