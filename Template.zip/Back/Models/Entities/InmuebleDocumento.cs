namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmuebleDocumento
{
    public Guid InmuebleDocumentoId { get; set; }

    public Guid? InmuebleId { get; set; }

    public int? DocumentoId { get; set; }

    public int? NumeroDocumento { get; set; }

    public string? Descripcion { get; set; }

    public DateTime? FechaActualizacion { get; set; }

    public Guid InmuebleComprobanteId { get; set; }

    public bool Completado { get; set; }

    public DateTime? FechaCompletado { get; set; }

    public string? Comentarios { get; set; }

    public string? DacionPago { get; set; }

    public string? JuicioRel { get; set; }

    public string? CreadoPor { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string? ModificadoPor { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public bool? Activo { get; set; }

    public int? MigracionInmuebleId { get; set; }

    public string? MigracionArchivo { get; set; }

    public string? MigracionTablaOrigen { get; set; }

    public string? ResponsableDocumento { get; set; }

    public DateTime? FechaVigencia { get; set; }

    public bool? OmitirVigencia { get; set; }

    public bool Revisado { get; set; }

    public string? Notas { get; set; }

    public int? ResponsableId { get; set; }

    public DateOnly? FechaNotif1 { get; set; }

    public DateOnly? FechaNotif2 { get; set; }

    public DateOnly? FechaNotif3 { get; set; }

    public string? EmitidoPor { get; set; }

    public DateTime? FechaPresentadoPor { get; set; }

    public bool EnTramite { get; set; }

    public bool Condicionantes { get; set; }

    public virtual Documento? Documento { get; set; }

    public virtual ICollection<DocumentoCondicionante> DocumentoCondicionantes { get; set; } = new List<DocumentoCondicionante>();

    public virtual Inmueble1? Inmueble { get; set; }

    public virtual InmuebleDocumentoVigencium? InmuebleDocumentoVigencium { get; set; }

    public virtual Usuario? Responsable { get; set; }
}