namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class Counter
{
    public string Key { get; set; } = null!;

    public int Value { get; set; }

    public DateTime? ExpireAt { get; set; }
}