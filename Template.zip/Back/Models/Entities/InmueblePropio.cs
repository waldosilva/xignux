namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmueblePropio
{
    public Guid InmueblePropioId { get; set; }

    public Guid? InmuebleId { get; set; }

    public string? NumeroEscritura { get; set; }

    public string? EscrituraArchivo { get; set; }

    public DateTime? FechaAdquisicion { get; set; }

    public string? Colindancias { get; set; }

    public string? SuperficieOriginalM2 { get; set; }

    public int? GiroActividadId { get; set; }

    public string? Notario { get; set; }

    public string? NumeroNotaria { get; set; }

    public string? NumeroRegistro { get; set; }

    public DateTime? FechaRegistro { get; set; }

    public string? LugarRegistro { get; set; }

    public string? Vendedor { get; set; }

    public string? ValorInmueble { get; set; }

    public string? CreadoPor { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string? ModificadoPor { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public bool? Activo { get; set; }

    public int? MigracionInmuebleId { get; set; }

    public string? MigracionInmuebleIdunico { get; set; }

    public virtual GiroActividad? GiroActividad { get; set; }

    public virtual Inmueble1? Inmueble { get; set; }

    public virtual ICollection<InmuebleMovimiento> InmuebleMovimientos { get; set; } = new List<InmuebleMovimiento>();

    public virtual ICollection<InmueblePropioSeguimiento> InmueblePropioSeguimientos { get; set; } = new List<InmueblePropioSeguimiento>();
}