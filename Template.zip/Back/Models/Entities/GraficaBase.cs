namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class GraficaBase
{
    public Guid InmuebleId { get; set; }

    public string Area { get; set; } = null!;

    public int Estatus { get; set; }

    public string Tipo { get; set; } = null!;

    public string Documento { get; set; } = null!;

    public bool? Activo { get; set; }
}