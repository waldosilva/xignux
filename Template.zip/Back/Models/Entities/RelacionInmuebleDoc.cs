namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class RelacionInmuebleDoc
{
    public int RelacionInmuebleDocId { get; set; }

    public Guid? InmuebleId { get; set; }

    public int? DocumentoId { get; set; }

    public virtual Documento? Documento { get; set; }

    public virtual Inmueble1? Inmueble { get; set; }
}