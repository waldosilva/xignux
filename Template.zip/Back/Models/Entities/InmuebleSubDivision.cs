namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmuebleSubDivision
{
    public Guid InmuebleSubDivisionId { get; set; }

    public Guid InmuebleId { get; set; }

    public Guid InmuebleNuevoId { get; set; }

    public string? CreadoPor { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string? ModificadoPor { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public long? MigracionInmuebleIdSubDivision { get; set; }

    public long? MigracionInmuebleIdNuevo { get; set; }

    public virtual Inmueble1 Inmueble { get; set; } = null!;

    public virtual Inmueble1 InmuebleNuevo { get; set; } = null!;
}