namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class DivisionAbogado
{
    public int DivisionAbogadoId { get; set; }

    public int? DivisionId { get; set; }

    public int? EmpresaId { get; set; }

    public int? UsuarioId { get; set; }

    public string? CreadoPor { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string? ModificadoPor { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public bool? Activo { get; set; }

    public virtual Division? Division { get; set; }

    public virtual Empresa? Empresa { get; set; }

    public virtual Usuario? Usuario { get; set; }
}