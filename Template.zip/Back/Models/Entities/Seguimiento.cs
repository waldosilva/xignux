namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class Seguimiento
{
    public Guid InmuebleId { get; set; }

    public Guid InmuebleArrendadoSeguimientoId { get; set; }

    public Guid? InmuebleArrendadoId { get; set; }

    public bool? Completado { get; set; }

    public int Estatus { get; set; }

    public DateTime? FechaVigencia { get; set; }

    public string Contrato { get; set; } = null!;

    public decimal Costo { get; set; }

    public string Divisa { get; set; } = null!;

    public string Periodo { get; set; } = null!;

    public string Empresa { get; set; } = null!;

    public int Activo { get; set; }

    public string? EstatusInmueble { get; set; }

    public int? EstatusId { get; set; }
}