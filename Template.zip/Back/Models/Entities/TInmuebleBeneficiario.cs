namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TInmuebleBeneficiario
{
    public int IdTInmuebleBeneficiario { get; set; }

    public int IdTInmueble { get; set; }

    public string NombreBeneficiario { get; set; } = null!;

    public DateTime FechaInsercion { get; set; }
}