namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class Inmueble20240612
{
    public Guid InmuebleId { get; set; }

    public int? EmpresaId { get; set; }

    public int? EstatusId { get; set; }

    public int? TipoInstalacionId { get; set; }

    public string? Folio { get; set; }

    public string? Calle { get; set; }

    public string? NumExterno { get; set; }

    public string? NumInterno { get; set; }

    public int? ColoniaId { get; set; }

    public int? MunicipioId { get; set; }

    public int? EstadoId { get; set; }

    public int? PaisId { get; set; }

    public string? CodigoPostal { get; set; }

    public string? DomicilioEscritura { get; set; }

    public string? Referencia { get; set; }

    public string? Comentarios { get; set; }

    public int? ZonaId { get; set; }

    public string? NumeroExpediente { get; set; }

    public string? ConstruccionM2 { get; set; }

    public string? SuperficieM2 { get; set; }

    public string? Coordenada { get; set; }

    public string? CreadoPor { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string? ModificadoPor { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public bool? Activo { get; set; }

    public int? MigracionInmuebleId { get; set; }

    public string? MigracionInmuebleIdunico { get; set; }

    public string? MigracionTablaOrigen { get; set; }

    public string? MigracionInmuebleDomicilio { get; set; }

    public string? MigracionMapaArchivo { get; set; }

    public string? ResponsableInmueble { get; set; }

    public int? ResponsableId { get; set; }

    public string? Serie { get; set; }

    public int? Numeracion { get; set; }

    public string? FolioAnt { get; set; }
}