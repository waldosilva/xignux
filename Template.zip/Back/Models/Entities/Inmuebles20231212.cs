namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class Inmuebles20231212
{
    
}