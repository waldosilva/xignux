namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TInmuebleSeguro
{
    public int IdTInmuebleSeguro { get; set; }

    public DateTime FechaAltaSeguro { get; set; }

    public string Folio { get; set; } = null!;

    public int IncidentNumber { get; set; }

    public bool SeguroCapturado { get; set; }

    public string NcempresaSeguro { get; set; } = null!;

    public string? CamposFaltantes { get; set; }
}