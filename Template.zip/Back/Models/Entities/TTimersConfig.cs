namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TTimersConfig
{
    public int IdTTimersConfig { get; set; }

    public string NombreCorto { get; set; } = null!;

    public string? Descripcion { get; set; }

    public int Minutos { get; set; }
}