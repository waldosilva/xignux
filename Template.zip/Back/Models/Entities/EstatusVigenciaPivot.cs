namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class EstatusVigenciaPivot
{
    public Guid? InmuebleId { get; set; }

    public int Vencido { get; set; }

    public int? VenceDias { get; set; }

    public int VenceSemana { get; set; }

    public int VenceMes { get; set; }
}