namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class Documento
{
    public int DocumentoId { get; set; }

    public string Codigo { get; set; } = null!;

    public string Nombre { get; set; } = null!;

    public string Descripcion { get; set; } = null!;

    public int TipoDocumentoId { get; set; }

    public bool Vigencia { get; set; }

    public bool Recurrencia { get; set; }

    public string CreadoPor { get; set; } = null!;

    public DateTime FechaCreacion { get; set; }

    public string ModificadoPor { get; set; } = null!;

    public DateTime FechaModificacion { get; set; }

    public bool Activo { get; set; }

    public bool VigenciaOpcional { get; set; }

    public int? CriticidadDocId { get; set; }

    public virtual CriticidadDocumento? CriticidadDoc { get; set; }

    public virtual ICollection<InmuebleDocumento> InmuebleDocumentos { get; set; } = new List<InmuebleDocumento>();

    public virtual ICollection<RelacionInmuebleDoc> RelacionInmuebleDocs { get; set; } = new List<RelacionInmuebleDoc>();

    public virtual TipoDocumento TipoDocumento { get; set; } = null!;

    public virtual ICollection<UsuarioDocumento> UsuarioDocumentos { get; set; } = new List<UsuarioDocumento>();
}