namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class CatTipoDocumento
{
    public int CatTipoDocumentoId { get; set; }

    public string? Nombre { get; set; }

    public string? Descripcion { get; set; }

    public bool? Activo { get; set; }

    public virtual ICollection<TipoDocumento> TipoDocumentos { get; set; } = new List<TipoDocumento>();
}