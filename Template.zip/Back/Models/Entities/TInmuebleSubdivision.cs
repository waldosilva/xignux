namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TInmuebleSubdivision
{
    public int IdTInmuebleSubdivision { get; set; }

    public int IdTInmueble { get; set; }

    public int EmpresaId { get; set; }

    public int IdTcatTipoInmuebleClasificacion { get; set; }

    public int Consecutivo { get; set; }

    public int IdTcatOperacionTipoInmuebleClasificacion { get; set; }

    public DateTime FechaAlta { get; set; }

    public string? Folio { get; set; }

    public int TipoInstalacionId { get; set; }

    public string Referencia { get; set; } = null!;

    public int PaisId { get; set; }

    public int ColoniaId { get; set; }

    public string? CodigoPostal { get; set; }

    public int? IncidentNumber { get; set; }

    public byte IdTInmuebleEstatus { get; set; }

    public string Calle { get; set; } = null!;

    public string NumExterno { get; set; } = null!;

    public string? NumInterno { get; set; }

    public string? Comentarios { get; set; }

    public string? CamposFaltantes { get; set; }

    public string? CamposAsegurado { get; set; }

    public bool? Asegurado { get; set; }
}