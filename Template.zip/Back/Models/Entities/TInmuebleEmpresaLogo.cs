namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TInmuebleEmpresaLogo
{
    public int IdTInmuebleEmpresaLogo { get; set; }

    public string Ncempresa { get; set; } = null!;

    public string Urlimagen { get; set; } = null!;
}