namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TInmuebleUsuarioAtencion
{
    public int IdTInmuebleUsuarioAtencion { get; set; }

    public int IdInmuebleInterno { get; set; }

    public int UsuarioId { get; set; }

    public string Paso { get; set; } = null!;

    public DateTime FechaHora { get; set; }

    public string? Comentario { get; set; }
}