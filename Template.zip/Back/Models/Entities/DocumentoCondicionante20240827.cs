namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class DocumentoCondicionante20240827
{
    public int DocumentoCondicionanteId { get; set; }

    public Guid? InmuebleDocumentoId { get; set; }

    public DateTime? FechaCondicionante { get; set; }

    public string? DescCondicionante { get; set; }

    public bool? EsTerminado { get; set; }

    public string? CreadoPor { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string? ModificadoPor { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public bool? Activo { get; set; }
}