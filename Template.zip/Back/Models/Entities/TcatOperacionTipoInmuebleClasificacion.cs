namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TcatOperacionTipoInmuebleClasificacion
{
    public int IdTcatOperacionTipoInmuebleClasificacion { get; set; }

    public int IdTcatOperacionTipoInmueble { get; set; }

    public int IdTcatOperacion { get; set; }

    public string? NombreCorto { get; set; }

    public string? Descripcion { get; set; }
}