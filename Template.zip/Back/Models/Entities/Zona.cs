namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class Zona
{
    public int ZonaId { get; set; }

    public int? DivisionId { get; set; }

    public string? Descripcion { get; set; }

    public string CreadoPor { get; set; } = null!;

    public DateTime FechaCreacion { get; set; }

    public string ModificadoPor { get; set; } = null!;

    public DateTime FechaModificacion { get; set; }

    public bool Activo { get; set; }

    public virtual Division? Division { get; set; }

    public virtual ICollection<Inmueble1> Inmueble1s { get; set; } = new List<Inmueble1>();
}