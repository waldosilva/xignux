namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TBpmincidenteHistorium
{
    public int IdTBpmincidenteHistoria { get; set; }

    public int IdTInmueble { get; set; }

    public DateTime FechaCreacion { get; set; }

    public string Folio { get; set; } = null!;

    public string ProcessName { get; set; } = null!;

    public int IncidentNumber { get; set; }
}