namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmuebleMovimiento
{
    public Guid InmuebleMovimientoId { get; set; }

    public Guid? InmueblePropioId { get; set; }

    public int? TipoMovimientoId { get; set; }

    public string? NumeroEscritura { get; set; }

    public DateTime? FechaEscritura { get; set; }

    public string? NumeroNotaria { get; set; }

    public string? NumeroRegistro { get; set; }

    public DateTime? FechaRegistro { get; set; }

    public string? NumeroExpediente { get; set; }

    public string? Observaciones { get; set; }

    public string? CompradorVendedor { get; set; }

    public string? SuperficieDe { get; set; }

    public string? SuperficieA { get; set; }

    public string? Colindancias { get; set; }

    public string? CreadoPor { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string? ModificadoPor { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public bool? Activo { get; set; }

    public int? MigracionInmuebleId { get; set; }

    public string? MigracionEscrituraArchivoRectifica { get; set; }

    public virtual InmueblePropio? InmueblePropio { get; set; }

    public virtual TipoMovimiento? TipoMovimiento { get; set; }
}