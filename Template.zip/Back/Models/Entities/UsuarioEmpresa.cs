namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class UsuarioEmpresa
{
    public int UsuarioEmpresaId { get; set; }

    public int UsuarioId { get; set; }

    public int EmpresaId { get; set; }

    public string CreadoPor { get; set; } = null!;

    public DateTime FechaCreacion { get; set; }

    public string ModificadoPor { get; set; } = null!;

    public DateTime FechaModificacion { get; set; }

    public bool Activo { get; set; }
}