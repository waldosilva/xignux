namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TGrupoConfiguracion
{
    public int IdTGrupoConfiguracion { get; set; }

    public int IdTGrupo { get; set; }

    public int IdEmpresa { get; set; }

    public int IdUsuario { get; set; }
}