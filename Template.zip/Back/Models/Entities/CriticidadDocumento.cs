namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class CriticidadDocumento
{
    public int CriticidadDocId { get; set; }

    public string? Nombre { get; set; }

    public string? Descripcion { get; set; }

    public decimal? Valor { get; set; }

    public bool? Activo { get; set; }

    public virtual ICollection<Documento> Documentos { get; set; } = new List<Documento>();
}