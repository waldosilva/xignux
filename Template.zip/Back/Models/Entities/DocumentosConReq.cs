namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class DocumentosConReq
{
    public long? RowNumber { get; set; }

    public Guid? InmuebleId { get; set; }

    public Guid? InmuebleDocumentoId { get; set; }

    public bool Completado { get; set; }

    public int Estatus { get; set; }

    public int? DocumentoId { get; set; }

    public int? NumeroDocumento { get; set; }

    public string? Descripcion { get; set; }

    public string? EstatusInmueble { get; set; }

    public int Activo { get; set; }

    public DateTime? FechaVigencia { get; set; }

    public DateTime? FechaActualizacion { get; set; }

    public bool? OmitirVigencia { get; set; }

    public string? Vencimiento { get; set; }

    public int? TipoDocumentoId { get; set; }

    public string? Tipo { get; set; }

    public string? Documento { get; set; }

    public bool? Vigencia { get; set; }

    public int? Estado { get; set; }

    public bool? Vigencia1 { get; set; }

    public int? Dias1 { get; set; }

    public Guid? InmuebleDocumentoId1 { get; set; }

    public bool Completado1 { get; set; }

    public bool Revisado1 { get; set; }
}