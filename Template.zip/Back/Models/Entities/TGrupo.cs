namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TGrupo
{
    public int IdTGrupo { get; set; }

    public string NombreCorto { get; set; } = null!;

    public string Descripcion { get; set; } = null!;
}