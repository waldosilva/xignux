namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TcatInmuebleTipo
{
    public int IdTcatInmuebleTipo { get; set; }

    public string NombreCorto { get; set; } = null!;

    public string Descripcion { get; set; } = null!;
}