namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmuebleDocumentoVigencium
{
    public Guid InmuebleDocumentoVigenciaId { get; set; }

    public Guid InmuebleDocumentoId { get; set; }

    public long? InmuebleVigenciaParentId { get; set; }

    public DateTime? FechaVigencia { get; set; }

    public bool? Completado { get; set; }

    public string? Comprobante { get; set; }

    public string CreadoPor { get; set; } = null!;

    public DateTime FechaCreacion { get; set; }

    public string ModificadoPor { get; set; } = null!;

    public DateTime FechaModificacion { get; set; }

    public bool Activo { get; set; }

    public virtual InmuebleDocumento InmuebleDocumento { get; set; } = null!;
}