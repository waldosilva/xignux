namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TcatTipoInmuebleClasificacion
{
    public int IdTcatTipoInmuebleClasificacion { get; set; }

    public int IdTcatTipoInmueble { get; set; }

    public string? NombreCorto { get; set; }

    public string? Descripcion { get; set; }

    public string? Detalle { get; set; }
}