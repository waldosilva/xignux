namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TComentario
{
    public int IdTComentarios { get; set; }

    public int IdTInmueble { get; set; }

    public int UsuarioId { get; set; }

    public string Comentario { get; set; } = null!;
}