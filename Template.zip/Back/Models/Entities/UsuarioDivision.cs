namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class UsuarioDivision
{
    public int UsuarioId { get; set; }

    public string? UsuarioNt { get; set; }

    public int DivisionId { get; set; }

    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;
}