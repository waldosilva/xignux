namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class Hash
{
    public string Key { get; set; } = null!;

    public string Field { get; set; } = null!;

    public string? Value { get; set; }

    public DateTime? ExpireAt { get; set; }
}