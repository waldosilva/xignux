namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmuebleArrendadoSeguimiento
{
    public Guid InmuebleArrendadoSeguimientoId { get; set; }

    public Guid? InmuebleArrendadoId { get; set; }

    public string? Contrato { get; set; }

    public decimal? Costo { get; set; }

    public int? DivisaId { get; set; }

    public int? PeriodoId { get; set; }

    public string? TasaInteres { get; set; }

    public decimal? Deposito { get; set; }

    public string? Comentarios { get; set; }

    public DateTime? FechaInicio { get; set; }

    public DateTime? FechaVigencia { get; set; }

    public bool? PlazoForzoso { get; set; }

    public string? TiempoPlazoForzoso { get; set; }

    public DateTime? FechaPrimerPago { get; set; }

    public bool? ProrrogaAutomatica { get; set; }

    public DateTime? FechaFirma { get; set; }

    public string? TerminacionAnticipada { get; set; }

    public string? Penalizacion { get; set; }

    public bool? Mantenimiento { get; set; }

    public decimal? MantenimientoCuota { get; set; }

    public bool? SubArrendar { get; set; }

    public bool? Ceder { get; set; }

    public bool? Fianza { get; set; }

    public bool? Seguro { get; set; }

    public bool? ObligadoSolidario { get; set; }

    public string? Empresa { get; set; }

    public bool? Completo { get; set; }

    public DateTime? FechaCompletado { get; set; }

    public string? ComentariosCompletado { get; set; }

    public string? CreadoPor { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string? ModificadoPor { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public bool? Activo { get; set; }

    public int? MigracionInmuebleArreId { get; set; }

    public int? MigracionInmuebleSeguimientoArreNum { get; set; }

    public string? MigracionInmuebleSeguimientoContrato { get; set; }

    public DateTime? FechaNotif1 { get; set; }

    public DateTime? FechaNotif2 { get; set; }

    public int? ResponsableId { get; set; }

    public virtual Divisa? Divisa { get; set; }

    public virtual InmuebleArrendado? InmuebleArrendado { get; set; }

    public virtual Periodo? Periodo { get; set; }

    public virtual Usuario? Responsable { get; set; }
}