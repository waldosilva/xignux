namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmuebleInstalacion
{
    public int? DivisionId { get; set; }

    public string? DivisionDesc { get; set; }

    public string? ImageSrc { get; set; }

    public string? TipoInstalacion { get; set; }

    public int? Total { get; set; }
}