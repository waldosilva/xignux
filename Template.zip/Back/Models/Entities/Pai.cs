namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class Pai
{
    public int PaisId { get; set; }

    public string Codigo { get; set; } = null!;

    public string Descripcion { get; set; } = null!;

    public string CreadoPor { get; set; } = null!;

    public DateTime FechaCreacion { get; set; }

    public string ModificadoPor { get; set; } = null!;

    public DateTime FechaModificacion { get; set; }

    public bool Activo { get; set; }

    public virtual ICollection<Estado> Estados { get; set; } = new List<Estado>();

    public virtual ICollection<Inmueble1> Inmueble1s { get; set; } = new List<Inmueble1>();

    public virtual ICollection<TInmueble> TInmuebles { get; set; } = new List<TInmueble>();
}