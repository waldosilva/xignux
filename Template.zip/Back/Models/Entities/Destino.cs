namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class Destino
{
    public int DestinoId { get; set; }

    public string Descripcion { get; set; } = null!;

    public string CreadoPor { get; set; } = null!;

    public DateTime FechaCreacion { get; set; }

    public string ModificadoPor { get; set; } = null!;

    public DateTime FechaModificacion { get; set; }

    public bool Activo { get; set; }
}