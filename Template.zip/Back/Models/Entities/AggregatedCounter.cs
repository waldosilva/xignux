namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class AggregatedCounter
{
    public string Key { get; set; } = null!;

    public long Value { get; set; }

    public DateTime? ExpireAt { get; set; }
}