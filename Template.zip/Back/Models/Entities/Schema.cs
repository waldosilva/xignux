namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class Schema
{
    public int Version { get; set; }
}