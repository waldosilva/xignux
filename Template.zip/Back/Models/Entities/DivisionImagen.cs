namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class DivisionImagen
{
    public int? DivisionId { get; set; }

    public string? ImageSrc { get; set; }

    public virtual Division? Division { get; set; }
}