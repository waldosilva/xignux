namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class PermisoRol
{
    public int PermisoRolId { get; set; }

    public int RolId { get; set; }

    public int PantallaId { get; set; }

    public bool? PermisoEscritura { get; set; }

    public bool? PermisoLectura { get; set; }

    public string CreadoPor { get; set; } = null!;

    public DateTime FechaCreacion { get; set; }

    public string ModificadoPor { get; set; } = null!;

    public DateTime FechaModificacion { get; set; }

    public bool Activo { get; set; }

    public virtual Pantalla Pantalla { get; set; } = null!;

    public virtual Rol Rol { get; set; } = null!;
}