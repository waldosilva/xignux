namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmueblesDocumentosView
{
    public Guid? InmuebleId { get; set; }

    public Guid? InmuebleDocumentoId { get; set; }

    public string Documento { get; set; } = null!;

    public string TipoDocumento { get; set; } = null!;

    public int? CriticidadDocId { get; set; }

    public string? Criticidad { get; set; }

    public bool Condicionantes { get; set; }

    public DateTime? FechaVigencia { get; set; }

    public int? Estado { get; set; }
}