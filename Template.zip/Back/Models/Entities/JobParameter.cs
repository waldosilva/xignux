namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class JobParameter
{
    public long JobId { get; set; }

    public string Name { get; set; } = null!;

    public string? Value { get; set; }

    public virtual Job Job { get; set; } = null!;
}