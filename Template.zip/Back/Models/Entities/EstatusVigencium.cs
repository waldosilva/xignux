namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class EstatusVigencium
{
    public Guid? InmuebleId { get; set; }

    public int Estatus { get; set; }

    public int? Conteo { get; set; }
}