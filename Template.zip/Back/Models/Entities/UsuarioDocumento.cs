namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class UsuarioDocumento
{
    public int UsuarioDocumentoId { get; set; }

    public int? UsuarioId { get; set; }

    public int? DocumentoId { get; set; }
}