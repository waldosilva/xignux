namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmublesEmpleado
{
    public string? EmpCode { get; set; }

    public string? Email { get; set; }

    public string? Nombre { get; set; }

    public string Apaterno { get; set; } = null!;

    public string? Amaterno { get; set; }

    public int Activo { get; set; }
}