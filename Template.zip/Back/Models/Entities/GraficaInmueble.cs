namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class GraficaInmueble
{
    public Guid InmuebleId { get; set; }

    public string TipoInmueble { get; set; } = null!;

    public string? TipoInstalacion { get; set; }

    public string? Division { get; set; }

    public string? Empresa { get; set; }

    public string Area { get; set; } = null!;

    public string? Estatus { get; set; }

    public int Completo { get; set; }

    public string Tipo { get; set; } = null!;

    public string Documento { get; set; } = null!;

    public string Colonia { get; set; } = null!;

    public string Municipio { get; set; } = null!;

    public string Estado { get; set; } = null!;

    public string Pais { get; set; } = null!;

    public string CodigoPostal { get; set; } = null!;

    public string Zona { get; set; } = null!;
}