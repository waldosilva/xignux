namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TInmuebleCorreoNotifica
{
    public int IdTInmuebleCorreoNotifica { get; set; }

    public string Sistema { get; set; } = null!;

    public string Notificacion { get; set; } = null!;

    public DateTime FechaHoraEnvio { get; set; }

    public int IdInmuebleInterno { get; set; }
}