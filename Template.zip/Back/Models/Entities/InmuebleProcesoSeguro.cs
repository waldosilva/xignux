namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmuebleProcesoSeguro
{
    public Guid InmuebleProcesoSeguroId { get; set; }

    public Guid InmuebleId { get; set; }

    public int? IncidentNumber { get; set; }

    public bool? ProcesoInmuebleCompleto { get; set; }

    public bool? ProcesoSeguroCompleto { get; set; }

    public int? IncidentNumberDespachador { get; set; }

    public string? CamposFaltantes { get; set; }

    public string? CamposAsegurado { get; set; }

    public bool? Asegurado { get; set; }

    public bool? ProcesoAseguramientoCompleto { get; set; }

    public string? Ncplanta { get; set; }

    public string? Aduser { get; set; }

    public string? ComentarioBeneficiario { get; set; }

    public bool? OcupaEndoso { get; set; }

    public string CreadoPor { get; set; } = null!;

    public DateTime FechaCreacion { get; set; }

    public string ModificadoPor { get; set; } = null!;

    public DateTime FechaModificacion { get; set; }

    public bool Activo { get; set; }

    public virtual Inmueble1 Inmueble { get; set; } = null!;

    public virtual ICollection<InmuebleSeguro> InmuebleSeguros { get; set; } = new List<InmuebleSeguro>();
}