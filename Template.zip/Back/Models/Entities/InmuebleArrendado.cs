namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmuebleArrendado
{
    public Guid InmuebleArrendadoId { get; set; }

    public Guid? InmuebleId { get; set; }

    public int? TipoArrendamientoId { get; set; }

    public int? DestinoId { get; set; }

    public string? Arrendador { get; set; }

    public string? Rcfarrendador { get; set; }

    public int? CajonesEstacionamiento { get; set; }

    public int? DivisionId { get; set; }

    public string? CreadoPor { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string? ModificadoPor { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public bool? Activo { get; set; }

    public int? MigracionInmuebleArreId { get; set; }

    public string? MigracionInmuebleIdunico { get; set; }

    public virtual Destino? Destino { get; set; }

    public virtual Inmueble1? Inmueble { get; set; }

    public virtual ICollection<InmuebleArrendadoSeguimiento> InmuebleArrendadoSeguimientos { get; set; } = new List<InmuebleArrendadoSeguimiento>();

    public virtual TipoArrendamiento? TipoArrendamiento { get; set; }
}