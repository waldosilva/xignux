namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class Divisa
{
    public int DivisaId { get; set; }

    public string? Descripcion { get; set; }

    public string CreadoPor { get; set; } = null!;

    public DateTime FechaCreacion { get; set; }

    public string ModificadoPor { get; set; } = null!;

    public DateTime FechaModificacion { get; set; }

    public bool Activo { get; set; }
}