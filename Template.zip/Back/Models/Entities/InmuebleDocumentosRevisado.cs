namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmuebleDocumentosRevisado
{
    public Guid InmuebleDocumentoId { get; set; }

    public int UsuarioId { get; set; }

    public string? UsuarioNt { get; set; }

    public Guid InmuebleId { get; set; }

    public string Empresa { get; set; } = null!;

    public string? Referencia { get; set; }

    public string? Folio { get; set; }

    public string? Descripcion { get; set; }

    public string Nombre { get; set; } = null!;

    public bool Completado { get; set; }

    public bool Revisado { get; set; }

    public DateTime? FechaVigencia { get; set; }

    public string? ResponsableDoc { get; set; }

    public string? ResponsableUsuarioNt { get; set; }
}