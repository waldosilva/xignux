namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class EmpresaBloqueo
{
    public int EmpresaBloqueoId { get; set; }

    public bool Bloqueo { get; set; }
}