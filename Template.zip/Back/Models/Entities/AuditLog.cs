namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class AuditLog
{
    public Guid AuditLogId { get; set; }

    public string UserId { get; set; } = null!;

    public DateTime EventDateUtc { get; set; }

    public string EventType { get; set; } = null!;

    public string TableName { get; set; } = null!;

    public string RecordId { get; set; } = null!;

    public string ColumnName { get; set; } = null!;

    public string? OriginalValue { get; set; }

    public string? NewValue { get; set; }
}