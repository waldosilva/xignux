namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmuebleSeguro
{
    public Guid InmuebleSeguroId { get; set; }

    public Guid InmuebleProcesoSeguroId { get; set; }

    public DateTime? FechaAltaSeguro { get; set; }

    public string? Folio { get; set; }

    public int? IncidentNumber { get; set; }

    public bool? SeguroCapturado { get; set; }

    public string? NcempresaSeguro { get; set; }

    public string? CamposFaltantes { get; set; }

    public bool Activo { get; set; }

    public string CreadoPor { get; set; } = null!;

    public DateTime FechaCreacion { get; set; }

    public string ModificadoPor { get; set; } = null!;

    public DateTime FechaModificacion { get; set; }

    public virtual InmuebleProcesoSeguro InmuebleProcesoSeguro { get; set; } = null!;
}