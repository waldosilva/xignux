namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmuebleEmpresaLogo
{
    public int InmuebleEmpresaLogoId { get; set; }

    public string Ncempresa { get; set; } = null!;

    public string Urlimagen { get; set; } = null!;
}