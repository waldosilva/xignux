namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class InmuebleCorreoTipo
{
    public int InmuebleCorreoTipoId { get; set; }

    public string NombreCorto { get; set; } = null!;

    public string Descripcion { get; set; } = null!;

    public string Html { get; set; } = null!;
}