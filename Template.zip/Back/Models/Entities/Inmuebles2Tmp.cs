namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class Inmuebles2Tmp
{
    public string? EmpCode { get; set; }

    public string? Email { get; set; }
}