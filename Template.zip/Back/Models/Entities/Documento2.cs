namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class Documento2
{
    public Guid DocumentoId { get; set; }

    public int SeccionId { get; set; }

    public Guid UnicoId { get; set; }

    public string Nombre { get; set; } = null!;

    public byte[]? Archivo { get; set; }

    public string CreadoPor { get; set; } = null!;

    public DateTime FechaCreacion { get; set; }

    public string ModificadoPor { get; set; } = null!;

    public DateTime FechaModificacion { get; set; }

    public bool Activo { get; set; }

    public string? MigracionRuta { get; set; }
}