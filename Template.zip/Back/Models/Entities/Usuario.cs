namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class Usuario
{
    public int UsuarioId { get; set; }

    public string? UsuarioNt { get; set; }

    public string Email { get; set; } = null!;

    public int EmpresaId { get; set; }

    public string ApellidoPaterno { get; set; } = null!;

    public string? ApellidoMaterno { get; set; }

    public string Nombre { get; set; } = null!;

    public int RolId { get; set; }

    public string CreadoPor { get; set; } = null!;

    public DateTime FechaCreacion { get; set; }

    public string ModificadoPor { get; set; } = null!;

    public DateTime FechaModificacion { get; set; }

    public bool Activo { get; set; }

    public string? EmpCode { get; set; }
}