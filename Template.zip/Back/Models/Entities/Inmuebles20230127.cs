namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class Inmuebles20230127
{
    public Guid InmuebleId { get; set; }

    public string Tipo { get; set; } = null!;

    public string? Folio { get; set; }

    public string? Referencia { get; set; }

    public string? Expediente { get; set; }

    public int? DivisionId { get; set; }

    public int? EmpresaId { get; set; }

    public string? Empresa { get; set; }

    public string? Escritura { get; set; }

    public string? Domicilio { get; set; }

    public string? CodigoPostal { get; set; }

    public int Vencido { get; set; }

    public int VenceDias { get; set; }

    public int VenceSemana { get; set; }

    public int VenceMes { get; set; }

    public string? EstatusInmueble { get; set; }

    public int Activo { get; set; }

    public int? PaisId { get; set; }

    public int? EstadoId { get; set; }

    public int? MunicipioId { get; set; }

    public int? ColoniaId { get; set; }
}