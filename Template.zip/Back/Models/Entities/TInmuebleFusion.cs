namespace Xugnux.Juridico.Inmuebles.API.Models.Entities;

public class TInmuebleFusion
{
    public int IdTInmuebleFusion { get; set; }

    public int IdTInmuebleFusionado { get; set; }

    public DateTime FechaBajaXfusion { get; set; }

    public string? Folio { get; set; }

    public byte? IdTInmuebleEstatus { get; set; }
}