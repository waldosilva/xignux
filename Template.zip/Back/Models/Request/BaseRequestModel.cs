namespace Xugnux.Juridico.Inmuebles.API.Models.Request;

public class BaseRequestModel
{
    public string? CreadoPor { get; set; }

    public DateTime FechaCreacion { get; set; }

    public string? ModificadoPor { get; set; }

    public DateTime FechaModificacion { get; set; }

    public bool Activo { get; set; }
}